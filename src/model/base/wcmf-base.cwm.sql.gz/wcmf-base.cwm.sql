-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Erstellungszeit: 25. Feb 2014 um 00:12
-- Server Version: 5.5.27
-- PHP-Version: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Datenbank: `cwm`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `Activity`
--

DROP TABLE IF EXISTS `Activity`;
CREATE TABLE IF NOT EXISTS `Activity` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_productionruleset_id` int(11) DEFAULT NULL,
  `fk_activityset_id` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_productionruleset_id` (`fk_productionruleset_id`),
  KEY `fk_activityset_id` (`fk_activityset_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `ActivityDecision`
--

DROP TABLE IF EXISTS `ActivityDecision`;
CREATE TABLE IF NOT EXISTS `ActivityDecision` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_productionruleset_id` int(11) DEFAULT NULL,
  `fk_activityset_id` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_productionruleset_id` (`fk_productionruleset_id`),
  KEY `fk_activityset_id` (`fk_activityset_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `ActivityFinal`
--

DROP TABLE IF EXISTS `ActivityFinal`;
CREATE TABLE IF NOT EXISTS `ActivityFinal` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_productionruleset_id` int(11) DEFAULT NULL,
  `fk_activityset_id` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_productionruleset_id` (`fk_productionruleset_id`),
  KEY `fk_activityset_id` (`fk_activityset_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `ActivityInitial`
--

DROP TABLE IF EXISTS `ActivityInitial`;
CREATE TABLE IF NOT EXISTS `ActivityInitial` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_productionruleset_id` int(11) DEFAULT NULL,
  `fk_activityset_id` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_productionruleset_id` (`fk_productionruleset_id`),
  KEY `fk_activityset_id` (`fk_activityset_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `ActivityReceive`
--

DROP TABLE IF EXISTS `ActivityReceive`;
CREATE TABLE IF NOT EXISTS `ActivityReceive` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_productionruleset_id` int(11) DEFAULT NULL,
  `fk_activityset_id` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_productionruleset_id` (`fk_productionruleset_id`),
  KEY `fk_activityset_id` (`fk_activityset_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `ActivitySend`
--

DROP TABLE IF EXISTS `ActivitySend`;
CREATE TABLE IF NOT EXISTS `ActivitySend` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_productionruleset_id` int(11) DEFAULT NULL,
  `fk_activityset_id` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_productionruleset_id` (`fk_productionruleset_id`),
  KEY `fk_activityset_id` (`fk_activityset_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `ActivitySet`
--

DROP TABLE IF EXISTS `ActivitySet`;
CREATE TABLE IF NOT EXISTS `ActivitySet` (
  `id` int(11) NOT NULL,
  `fk_chibusinessusecasecore_id` int(11) DEFAULT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_chibusinessusecase_id` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chibusinessusecasecore_id` (`fk_chibusinessusecasecore_id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_chibusinessusecase_id` (`fk_chibusinessusecase_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `Actor`
--

DROP TABLE IF EXISTS `Actor`;
CREATE TABLE IF NOT EXISTS `Actor` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `adodbseq`
--

DROP TABLE IF EXISTS `adodbseq`;
CREATE TABLE IF NOT EXISTS `adodbseq` (
  `id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `adodbseq`
--

INSERT INTO `adodbseq` (`id`) VALUES(7947);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `ChiActionKey`
--

DROP TABLE IF EXISTS `ChiActionKey`;
CREATE TABLE IF NOT EXISTS `ChiActionKey` (
  `id` int(11) NOT NULL,
  `action` varchar(255) DEFAULT NULL,
  `config` varchar(255) DEFAULT NULL,
  `context` varchar(255) DEFAULT NULL,
  `sourcename` varchar(255) DEFAULT NULL,
  `sourcemultiplicity` varchar(255) DEFAULT NULL,
  `sourcenavigability` varchar(255) DEFAULT NULL,
  `targetname` varchar(255) DEFAULT NULL,
  `targetmultiplicity` varchar(255) DEFAULT NULL,
  `targetnavigability` varchar(255) DEFAULT NULL,
  `relationtype` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `ChiAssociation`
--

DROP TABLE IF EXISTS `ChiAssociation`;
CREATE TABLE IF NOT EXISTS `ChiAssociation` (
  `id` int(11) NOT NULL,
  `fk_chinodetarget_id` int(11) DEFAULT NULL,
  `fk_chinodesource_id` int(11) DEFAULT NULL,
  `fk_chinodemanytomanytarget_id` int(11) DEFAULT NULL,
  `fk_chinodemanytomanysource_id` int(11) DEFAULT NULL,
  `fk_name` varchar(255) DEFAULT NULL,
  `sourcename` varchar(255) DEFAULT NULL,
  `sourcemultiplicity` varchar(255) DEFAULT NULL,
  `sourcenavigability` varchar(255) DEFAULT NULL,
  `targetname` varchar(255) DEFAULT NULL,
  `targetmultiplicity` varchar(255) DEFAULT NULL,
  `targetnavigability` varchar(255) DEFAULT NULL,
  `relationtype` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chinodetarget_id` (`fk_chinodetarget_id`),
  KEY `fk_chinodesource_id` (`fk_chinodesource_id`),
  KEY `fk_chinodemanytomanytarget_id` (`fk_chinodemanytomanytarget_id`),
  KEY `fk_chinodemanytomanysource_id` (`fk_chinodemanytomanysource_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `ChiAssociation`
--

INSERT INTO `ChiAssociation` (`id`, `fk_chinodetarget_id`, `fk_chinodesource_id`, `fk_chinodemanytomanytarget_id`, `fk_chinodemanytomanysource_id`, `fk_name`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(529, 255, 278, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'generalization', NULL, '?', '2012-05-11 08:50:57', 'admin', 'admin', '2012-06-24 00:16:32', NULL);
INSERT INTO `ChiAssociation` (`id`, `fk_chinodetarget_id`, `fk_chinodesource_id`, `fk_chinodemanytomanytarget_id`, `fk_chinodemanytomanysource_id`, `fk_name`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(558, 255, 311, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'generalization', NULL, NULL, '2012-05-11 08:51:08', 'admin', 'admin', '2012-05-11 08:51:08', NULL);
INSERT INTO `ChiAssociation` (`id`, `fk_chinodetarget_id`, `fk_chinodesource_id`, `fk_chinodemanytomanytarget_id`, `fk_chinodemanytomanysource_id`, `fk_name`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(559, 255, 313, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'generalization', NULL, NULL, '2012-05-11 08:51:10', 'admin', 'admin', '2012-05-11 08:51:10', NULL);
INSERT INTO `ChiAssociation` (`id`, `fk_chinodetarget_id`, `fk_chinodesource_id`, `fk_chinodemanytomanytarget_id`, `fk_chinodemanytomanysource_id`, `fk_name`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(562, 255, 317, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'generalization', NULL, NULL, '2012-05-11 08:51:11', 'admin', 'admin', '2012-05-11 08:51:11', NULL);
INSERT INTO `ChiAssociation` (`id`, `fk_chinodetarget_id`, `fk_chinodesource_id`, `fk_chinodemanytomanytarget_id`, `fk_chinodemanytomanysource_id`, `fk_name`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(4418, 4398, 323, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'generalization', 'Generalization', NULL, '2012-06-26 23:53:22', 'admin', 'admin', '2012-06-26 23:53:23', NULL);
INSERT INTO `ChiAssociation` (`id`, `fk_chinodetarget_id`, `fk_chinodesource_id`, `fk_chinodemanytomanytarget_id`, `fk_chinodemanytomanysource_id`, `fk_name`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(568, 255, 326, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'generalization', NULL, NULL, '2012-05-11 08:51:13', 'admin', 'admin', '2012-05-11 08:51:13', NULL);
INSERT INTO `ChiAssociation` (`id`, `fk_chinodetarget_id`, `fk_chinodesource_id`, `fk_chinodemanytomanytarget_id`, `fk_chinodemanytomanysource_id`, `fk_name`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(573, 255, 332, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'generalization', NULL, NULL, '2012-05-11 08:51:15', 'admin', 'admin', '2012-05-11 08:51:15', NULL);
INSERT INTO `ChiAssociation` (`id`, `fk_chinodetarget_id`, `fk_chinodesource_id`, `fk_chinodemanytomanytarget_id`, `fk_chinodemanytomanysource_id`, `fk_name`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(576, 317, 337, NULL, NULL, 'fk_user_id', NULL, '513', 'Navigable', NULL, '522', 'Navigable', 'composition', NULL, '?', '2012-05-11 08:51:17', 'admin', 'admin', '2012-06-23 00:37:23', NULL);
INSERT INTO `ChiAssociation` (`id`, `fk_chinodetarget_id`, `fk_chinodesource_id`, `fk_chinodemanytomanytarget_id`, `fk_chinodemanytomanysource_id`, `fk_name`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(4416, 4384, 337, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'generalization', 'Generalization', NULL, '2012-06-26 23:53:15', 'admin', 'admin', '2012-06-26 23:53:15', NULL);
INSERT INTO `ChiAssociation` (`id`, `fk_chinodetarget_id`, `fk_chinodesource_id`, `fk_chinodemanytomanytarget_id`, `fk_chinodemanytomanysource_id`, `fk_name`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(578, 332, 337, NULL, NULL, 'fk_user_id', NULL, '513', 'Navigable', NULL, '522', 'Navigable', 'composition', NULL, '?', '2012-05-11 08:51:17', 'admin', 'admin', '2012-06-23 00:37:36', NULL);
INSERT INTO `ChiAssociation` (`id`, `fk_chinodetarget_id`, `fk_chinodesource_id`, `fk_chinodemanytomanytarget_id`, `fk_chinodemanytomanysource_id`, `fk_name`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(3558, 255, 337, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'generalization', 'Generalization', NULL, '2012-06-23 23:50:08', 'admin', 'admin', '2012-06-23 23:50:09', NULL);
INSERT INTO `ChiAssociation` (`id`, `fk_chinodetarget_id`, `fk_chinodesource_id`, `fk_chinodemanytomanytarget_id`, `fk_chinodemanytomanysource_id`, `fk_name`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(3562, 255, 323, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'generalization', 'Generalization', NULL, '2012-06-23 23:50:31', 'admin', 'admin', '2012-06-23 23:50:31', NULL);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `ChiAuthors`
--

DROP TABLE IF EXISTS `ChiAuthors`;
CREATE TABLE IF NOT EXISTS `ChiAuthors` (
  `id` int(11) NOT NULL,
  `role` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `ChiBaseStatus`
--

DROP TABLE IF EXISTS `ChiBaseStatus`;
CREATE TABLE IF NOT EXISTS `ChiBaseStatus` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `ChiBusinessPartner`
--

DROP TABLE IF EXISTS `ChiBusinessPartner`;
CREATE TABLE IF NOT EXISTS `ChiBusinessPartner` (
  `id` int(11) NOT NULL,
  `fk_chibusinesspartneractive_id` int(11) DEFAULT NULL,
  `fk_chibusinesspartnerpassive_id` int(11) DEFAULT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_chibusinesspartner_id` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chibusinesspartneractive_id` (`fk_chibusinesspartneractive_id`),
  KEY `fk_chibusinesspartnerpassive_id` (`fk_chibusinesspartnerpassive_id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_chibusinesspartner_id` (`fk_chibusinesspartner_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `ChiBusinessPartnerActive`
--

DROP TABLE IF EXISTS `ChiBusinessPartnerActive`;
CREATE TABLE IF NOT EXISTS `ChiBusinessPartnerActive` (
  `id` int(11) NOT NULL,
  `fk_chibusinesspartnerpassive_id` int(11) DEFAULT NULL,
  `fk_chibusinesspartner_id` int(11) DEFAULT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_chibusinesspartneractive_id` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chibusinesspartnerpassive_id` (`fk_chibusinesspartnerpassive_id`),
  KEY `fk_chibusinesspartner_id` (`fk_chibusinesspartner_id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_chibusinesspartneractive_id` (`fk_chibusinesspartneractive_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `ChiBusinessPartnerPassive`
--

DROP TABLE IF EXISTS `ChiBusinessPartnerPassive`;
CREATE TABLE IF NOT EXISTS `ChiBusinessPartnerPassive` (
  `id` int(11) NOT NULL,
  `fk_chibusinesspartneractive_id` int(11) DEFAULT NULL,
  `fk_chibusinesspartner_id` int(11) DEFAULT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_chibusinesspartnerpassive_id` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chibusinesspartneractive_id` (`fk_chibusinesspartneractive_id`),
  KEY `fk_chibusinesspartner_id` (`fk_chibusinesspartner_id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_chibusinesspartnerpassive_id` (`fk_chibusinesspartnerpassive_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `ChiBusinessProcess`
--

DROP TABLE IF EXISTS `ChiBusinessProcess`;
CREATE TABLE IF NOT EXISTS `ChiBusinessProcess` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `ChiBusinessUseCase`
--

DROP TABLE IF EXISTS `ChiBusinessUseCase`;
CREATE TABLE IF NOT EXISTS `ChiBusinessUseCase` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_chifeature_id` int(11) DEFAULT NULL,
  `fk_chibusinessprocess_id` int(11) DEFAULT NULL,
  `primaryactor` varchar(255) DEFAULT NULL,
  `otheractors` varchar(255) DEFAULT NULL,
  `goalincontext` varchar(255) DEFAULT NULL,
  `scope` varchar(255) DEFAULT NULL,
  `level` varchar(255) DEFAULT NULL,
  `stakeholders` varchar(255) DEFAULT NULL,
  `precondition` varchar(255) DEFAULT NULL,
  `trigger` varchar(255) DEFAULT NULL,
  `mainsuccessscenario` varchar(255) DEFAULT NULL,
  `extensions` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_chifeature_id` (`fk_chifeature_id`),
  KEY `fk_chibusinessprocess_id` (`fk_chibusinessprocess_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `ChiBusinessUseCaseCore`
--

DROP TABLE IF EXISTS `ChiBusinessUseCaseCore`;
CREATE TABLE IF NOT EXISTS `ChiBusinessUseCaseCore` (
  `id` int(11) NOT NULL,
  `fk_chibusinessprocess_id` int(11) DEFAULT NULL,
  `fk_chifeature_id` int(11) DEFAULT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `primaryactor` varchar(255) DEFAULT NULL,
  `otheractors` varchar(255) DEFAULT NULL,
  `goalincontext` varchar(255) DEFAULT NULL,
  `scope` varchar(255) DEFAULT NULL,
  `level` varchar(255) DEFAULT NULL,
  `stakeholders` varchar(255) DEFAULT NULL,
  `precondition` varchar(255) DEFAULT NULL,
  `trigger` varchar(255) DEFAULT NULL,
  `mainsuccessscenario` varchar(255) DEFAULT NULL,
  `extensions` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chibusinessprocess_id` (`fk_chibusinessprocess_id`),
  KEY `fk_chifeature_id` (`fk_chifeature_id`),
  KEY `fk_package_id` (`fk_package_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `ChiClass`
--

DROP TABLE IF EXISTS `ChiClass`;
CREATE TABLE IF NOT EXISTS `ChiClass` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `visibility` varchar(255) DEFAULT NULL,
  `isabstract` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `ChiController`
--

DROP TABLE IF EXISTS `ChiController`;
CREATE TABLE IF NOT EXISTS `ChiController` (
  `id` int(11) NOT NULL,
  `fk_chibusinessusecasecore_id` int(11) DEFAULT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_chibusinessusecase_id` int(11) DEFAULT NULL,
  `visibility` varchar(255) DEFAULT NULL,
  `isabstract` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chibusinessusecasecore_id` (`fk_chibusinessusecasecore_id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_chibusinessusecase_id` (`fk_chibusinessusecase_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `ChiController`
--

INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(191, NULL, 190, NULL, NULL, 'false', '350', 'Chi043Contr', '349', 'null', 'MultipleActionController', '?', 'null', 'null', 'admin', '2013-07-12 18:51:50', NULL, 18);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(192, NULL, 190, NULL, NULL, 'false', '350', 'Chi044Contr', '349', 'null', 'AssociateController', '?', 'null', 'null', 'admin', '2013-07-12 18:51:50', NULL, 1);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(193, NULL, 190, NULL, NULL, 'false', '350', 'Chi045Contr', '349', 'null', 'BatchController', NULL, 'null', 'null', 'admin', '2013-07-12 18:51:50', NULL, 2);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(194, NULL, 190, NULL, NULL, 'false', '350', 'Chi046Contr', '349', 'null', 'BatchDisplayController', NULL, 'null', 'null', 'admin', '2013-07-12 18:51:50', NULL, 3);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(195, NULL, 190, NULL, NULL, 'false', '350', 'Chi047Contr', '349', 'null', 'ConcurrencyController', '?', 'null', 'null', 'admin', '2014-02-10 14:07:55', NULL, 4);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(196, NULL, 190, NULL, NULL, 'false', '350', 'Chi048Contr', '349', 'null', 'CopyController', '?', 'null', 'null', 'admin', '2014-02-10 14:05:22', NULL, 5);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(197, NULL, 190, NULL, NULL, 'false', '350', 'Chi049Contr', '349', 'null', 'DeleteController', '?', 'null', 'null', 'admin', '2013-07-12 18:51:50', NULL, 6);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(198, NULL, 190, NULL, NULL, 'false', '350', 'Chi050Contr', '349', 'null', 'DisplayController', '?', 'null', 'null', 'admin', '2013-07-12 18:51:50', NULL, 7);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(200, NULL, 190, NULL, NULL, 'false', '350', 'Chi052Contr', '349', 'null', 'ExitController', NULL, 'null', 'null', 'admin', '2013-07-12 18:51:50', NULL, 8);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(201, NULL, 190, NULL, NULL, 'false', '350', 'Chi053Contr', '349', 'null', 'FailureController', NULL, 'null', 'null', 'admin', '2013-07-12 18:51:50', NULL, 9);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(203, NULL, 190, NULL, NULL, 'false', '350', 'Chi055Contr', '349', 'null', 'MediaController', '?', 'null', 'null', 'admin', '2013-07-12 18:51:50', NULL, 15);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(204, NULL, 190, NULL, NULL, 'false', '350', 'Chi056Contr', '349', 'null', 'ListController', '?', 'null', 'null', 'admin', '2013-07-12 18:51:50', NULL, 11);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(205, NULL, 190, NULL, NULL, 'false', '350', 'Chi057Contr', '349', 'null', 'LoggingController', NULL, 'null', 'null', 'admin', '2013-07-12 18:51:50', NULL, 12);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(206, NULL, 190, NULL, NULL, 'false', '350', 'Chi058Contr', '349', 'null', 'LoginController', '?', 'null', 'null', 'admin', '2013-07-12 18:51:50', NULL, 13);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(210, NULL, 190, NULL, NULL, 'false', '350', 'Chi062Contr', '349', 'null', 'RESTController', '?', 'null', 'null', 'admin', '2014-02-10 14:04:16', NULL, 19);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(211, NULL, 190, NULL, NULL, 'false', '350', 'Chi063Contr', '349', 'null', 'SaveController', '?', 'null', 'null', 'admin', '2013-07-12 18:51:50', NULL, 21);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(212, NULL, 190, NULL, NULL, 'false', '350', 'Chi064Contr', '349', 'null', 'SearchController', '?', 'null', 'null', 'admin', '2014-02-10 14:10:29', NULL, 22);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(216, NULL, 190, NULL, NULL, 'false', '350', 'Chi068Contr', '349', 'null', 'SortController', '?', 'null', 'null', 'admin', '2013-07-12 18:51:51', NULL, 25);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(217, NULL, 190, NULL, NULL, 'false', '350', 'Chi069Contr', '349', 'null', 'TerminateController', NULL, 'null', 'null', 'admin', '2013-07-12 18:51:51', NULL, 26);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(219, NULL, 190, NULL, NULL, 'false', '350', 'Chi071Contr', '349', 'null', 'TreeController', '?', 'null', 'null', 'admin', '2013-07-12 18:51:51', NULL, 28);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(220, NULL, 190, NULL, NULL, 'false', '350', 'Chi072Contr', '349', 'null', 'UserController', '?', 'null', 'null', 'admin', '2013-07-12 18:51:51', NULL, 29);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(221, NULL, 190, NULL, NULL, 'false', '350', 'Chi073Contr', '349', 'null', 'ValueListController', '?', 'null', 'null', 'admin', '2013-07-12 18:51:51', NULL, 30);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(222, NULL, 190, NULL, NULL, 'false', '350', 'Chi074Contr', '349', 'null', 'MessageController', NULL, 'null', 'null', 'admin', '2013-07-12 18:51:50', NULL, 16);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(223, NULL, 190, NULL, NULL, 'false', '350', 'Chi075Contr', '349', 'null', 'XMLExportController', '?', 'null', 'null', 'admin', '2014-02-10 15:04:13', NULL, 31);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(229, NULL, 224, NULL, NULL, 'false', '350', 'Chi080Contr', '349', 'null', 'EditRightsController', '?', 'null', 'null', 'admin', '2014-02-10 14:24:02', NULL, 229);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(232, NULL, 224, NULL, NULL, 'false', '350', 'Chi083Contr', '349', 'null', 'SearchIndexController', '?', 'null', 'null', 'admin', '2014-02-10 14:24:13', NULL, 232);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(257, NULL, 256, NULL, NULL, 'false', '350', 'Chi084Contr', '349', 'null', 'Controller', '?', 'null', 'null', 'admin', '2012-06-26 23:52:37', NULL, 257);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `ChiFeature`
--

DROP TABLE IF EXISTS `ChiFeature`;
CREATE TABLE IF NOT EXISTS `ChiFeature` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `proofreader` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `ChiFeatureStatus`
--

DROP TABLE IF EXISTS `ChiFeatureStatus`;
CREATE TABLE IF NOT EXISTS `ChiFeatureStatus` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `ChiGoal`
--

DROP TABLE IF EXISTS `ChiGoal`;
CREATE TABLE IF NOT EXISTS `ChiGoal` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_chigoal_id` int(11) DEFAULT NULL,
  `goaltype` varchar(255) DEFAULT NULL,
  `priority` varchar(255) DEFAULT NULL,
  `value_ammount` varchar(255) DEFAULT NULL,
  `value_goal` varchar(255) DEFAULT NULL,
  `value_name` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_chigoal_id` (`fk_chigoal_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `ChiGoalType`
--

DROP TABLE IF EXISTS `ChiGoalType`;
CREATE TABLE IF NOT EXISTS `ChiGoalType` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `ChiIssue`
--

DROP TABLE IF EXISTS `ChiIssue`;
CREATE TABLE IF NOT EXISTS `ChiIssue` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_chirequirement_id` int(11) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `responsible` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_chirequirement_id` (`fk_chirequirement_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `ChiNode`
--

DROP TABLE IF EXISTS `ChiNode`;
CREATE TABLE IF NOT EXISTS `ChiNode` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_chicontroller_id` int(11) DEFAULT NULL,
  `display_value` varchar(255) DEFAULT NULL,
  `table_name` varchar(255) DEFAULT NULL,
  `is_ordered` varchar(255) DEFAULT NULL,
  `parent_order` varchar(255) DEFAULT NULL,
  `child_order` varchar(255) DEFAULT NULL,
  `pk_name` varchar(255) DEFAULT NULL,
  `is_searchable` varchar(255) DEFAULT NULL,
  `orderby` varchar(255) DEFAULT NULL,
  `is_soap` varchar(255) DEFAULT NULL,
  `initparams` varchar(255) DEFAULT NULL,
  `visibility` varchar(255) DEFAULT NULL,
  `isabstract` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_chicontroller_id` (`fk_chicontroller_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `ChiNode`
--

INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(255, 254, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'false', 'none', 'false', 'database', '511', 'true', NULL, 'Chi040Nod', NULL, '1.0', 'Node', '?', '2012-05-11 08:49:22', 'admin', 'admin', '2012-06-23 23:49:00', NULL, 255);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(278, 263, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'false', 'none', 'false', 'database', '511', 'true', NULL, 'Chi043Nod', NULL, '1.0', 'EntityBase', '?', '2012-05-11 08:49:25', 'admin', 'admin', '2013-02-21 22:13:33', NULL, 9);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(311, 310, NULL, NULL, 'dbsequence', NULL, NULL, NULL, NULL, 'false', 'none', 'false', 'database', '511', 'false', NULL, 'Chi046Nod', NULL, '1.0', 'DBSequence', '?', '2012-05-11 08:49:30', 'admin', 'admin', '2013-02-21 22:39:01', NULL, 311);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(313, 310, NULL, 'name', 'language', NULL, NULL, NULL, NULL, 'false', 'name', 'false', 'database', '511', 'false', NULL, 'Chi047Nod', NULL, '1.0', 'Language', 'A llanguage for which a translation of the model can be created. The code is arbitrary but it is recommended to use the ISO language codes (en, de, it, ...).', '2012-05-11 08:49:30', 'admin', 'admin', '2012-05-11 08:51:09', NULL, 313);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(317, 310, NULL, NULL, 'locktable', NULL, NULL, NULL, NULL, 'false', 'none', 'false', 'database', '511', 'false', NULL, 'Chi048Nod', NULL, '1.0', 'Locktable', '?', '2012-05-11 08:49:30', 'admin', 'admin', '2012-06-23 00:37:59', NULL, 317);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(323, 310, NULL, 'name', 'role', NULL, NULL, NULL, NULL, 'false', 'name', 'false', 'database', '511', 'false', NULL, 'Chi049Nod', NULL, '1.0', 'Role', '?', '2012-05-11 08:49:31', 'admin', 'admin', '2012-06-23 00:26:03', NULL, 323);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(326, 310, NULL, 'objectid|attribute|language', 'translation', NULL, NULL, NULL, NULL, 'false', 'none', 'false', 'database', '511', 'false', NULL, 'Chi050Nod', NULL, '1.0', 'Translation', 'Instances of this class are used to localize entity attributes. Each instance defines a translation of one attribute of one entity into one language.', '2012-05-11 08:49:32', 'admin', 'admin', '2012-05-11 08:51:13', NULL, 326);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(332, 310, NULL, 'key', 'user_config', NULL, NULL, NULL, NULL, 'false', 'none', 'false', 'database', '511', 'false', NULL, 'Chi051Nod', NULL, '1.0', 'UserConfig', '?', '2012-05-11 08:49:33', 'admin', 'admin', '2012-06-23 00:40:08', NULL, 332);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(337, 310, NULL, 'login', 'user', NULL, NULL, NULL, NULL, 'false', 'name', 'false', 'database', '511', 'false', NULL, 'Chi052Nod', NULL, '1.0', 'User', '?', '2012-05-11 08:49:33', 'admin', 'admin', '2012-06-23 00:34:01', NULL, 337);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(530, 4, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi182Nod', NULL, '1.0', 'Date', '?', '2012-05-11 08:50:57', 'admin', 'admin', '2013-02-20 00:36:44', NULL, 530);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(531, 4, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi183Nod', NULL, '1.0', 'String', NULL, '2012-05-11 08:50:57', 'admin', 'admin', '2012-05-11 08:50:57', NULL, 531);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(4384, 5641, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'false', 'none', NULL, 'database', NULL, 'false', NULL, 'Chi220Nod', NULL, '1.0', 'AbstractUser', '?', '2012-06-26 23:51:50', 'admin', 'admin', '2013-03-01 15:59:12', NULL, 2);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(4398, 5641, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'false', 'none', NULL, 'database', NULL, 'false', NULL, 'Chi221Nod', NULL, '1.0', 'AbstractRole', '?', '2012-06-26 23:52:41', 'admin', 'admin', '2013-03-01 15:59:29', NULL, 3);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(3476, 4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi219Nod', NULL, '1.0', 'Boolean', '?', '2012-06-23 02:18:19', 'admin', 'admin', '2012-06-23 02:18:54', NULL, 3476);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(3463, 4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi218Nod', NULL, '1.0', 'Integer', '?', '2012-06-23 02:17:25', 'admin', 'admin', '2012-06-23 02:18:00', NULL, 3463);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `ChiNodeManyToMany`
--

DROP TABLE IF EXISTS `ChiNodeManyToMany`;
CREATE TABLE IF NOT EXISTS `ChiNodeManyToMany` (
  `id` int(11) NOT NULL,
  `fk_chicontroller_id` int(11) DEFAULT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `display_value` varchar(255) DEFAULT NULL,
  `table_name` varchar(255) DEFAULT NULL,
  `is_ordered` varchar(255) DEFAULT NULL,
  `parent_order` varchar(255) DEFAULT NULL,
  `child_order` varchar(255) DEFAULT NULL,
  `pk_name` varchar(255) DEFAULT NULL,
  `is_searchable` varchar(255) DEFAULT NULL,
  `orderby` varchar(255) DEFAULT NULL,
  `is_soap` varchar(255) DEFAULT NULL,
  `initparams` varchar(255) DEFAULT NULL,
  `visibility` varchar(255) DEFAULT NULL,
  `isabstract` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chicontroller_id` (`fk_chicontroller_id`),
  KEY `fk_package_id` (`fk_package_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `ChiNodeManyToMany`
--

INSERT INTO `ChiNodeManyToMany` (`id`, `fk_chicontroller_id`, `fk_package_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(4268, NULL, 310, NULL, 'nm_user_role', NULL, NULL, NULL, 'fk_user_id|fk_role_id', 'false', 'none', NULL, 'database', NULL, 'false', NULL, 'Chi001', NULL, '1.0', 'NMUserRole', '?', '2012-06-26 23:29:14', 'admin', 'admin', '2012-06-26 23:30:11', NULL, 4268);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `ChiObject`
--

DROP TABLE IF EXISTS `ChiObject`;
CREATE TABLE IF NOT EXISTS `ChiObject` (
  `id` int(11) NOT NULL,
  `fk_chinodemanytomany_id` int(11) DEFAULT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_chinode_id` int(11) DEFAULT NULL,
  `fk_productionruleset_id` int(11) DEFAULT NULL,
  `fk_activityset_id` int(11) DEFAULT NULL,
  `object_status` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chinodemanytomany_id` (`fk_chinodemanytomany_id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_chinode_id` (`fk_chinode_id`),
  KEY `fk_productionruleset_id` (`fk_productionruleset_id`),
  KEY `fk_activityset_id` (`fk_activityset_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `ChiRequirement`
--

DROP TABLE IF EXISTS `ChiRequirement`;
CREATE TABLE IF NOT EXISTS `ChiRequirement` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_chirequirement_id` int(11) DEFAULT NULL,
  `fk_chigoal_id` int(11) DEFAULT NULL,
  `reqtype` varchar(255) DEFAULT NULL,
  `priority` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `proofreader` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_chirequirement_id` (`fk_chirequirement_id`),
  KEY `fk_chigoal_id` (`fk_chigoal_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `ChiRequirementStatus`
--

DROP TABLE IF EXISTS `ChiRequirementStatus`;
CREATE TABLE IF NOT EXISTS `ChiRequirementStatus` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `ChiRequirementType`
--

DROP TABLE IF EXISTS `ChiRequirementType`;
CREATE TABLE IF NOT EXISTS `ChiRequirementType` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `ChiSystem`
--

DROP TABLE IF EXISTS `ChiSystem`;
CREATE TABLE IF NOT EXISTS `ChiSystem` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `config` varchar(255) DEFAULT NULL,
  `plattform` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `ChiSystem`
--

INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(9, 8, 'config.ini', 'wcmf', NULL, 'Chi057Syst', NULL, 'null', 'Config', '?', '2012-06-23 00:49:00', 'admin', 'admin', '2013-10-11 23:58:53', NULL, 2);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(11, 8, 'config.ini', 'wcmf', NULL, 'Chi058Syst', NULL, 'null', 'ActionMapping', '?', '2012-06-23 00:49:06', 'admin', 'admin', '2013-10-11 23:58:53', NULL, 4);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(13, 8, 'config.ini', 'wcmf', NULL, 'Chi059Syst', NULL, 'null', 'Views', '?', '2012-06-23 00:49:16', 'admin', 'admin', '2013-10-11 23:58:53', NULL, 5);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(14, 8, 'config.ini', 'wcmf', NULL, 'Chi060Syst', NULL, 'null', 'TypeMapping', '?', '2012-06-23 00:49:22', 'admin', 'admin', '2013-10-11 23:58:53', NULL, 3);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(15, 8, 'config.ini', 'wcmf', NULL, 'Chi061Syst', NULL, 'null', 'Application', '?', '2012-06-23 00:49:27', 'admin', 'admin', '2013-10-11 23:58:53', NULL, 6);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(23, 8, 'config.ini', 'wcmf', NULL, 'Chi062Syst', NULL, 'null', 'Media', '?', '2012-06-23 00:49:33', 'admin', 'admin', '2013-10-11 23:58:53', NULL, 7);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(25, 8, 'config.ini', 'wcmf', NULL, 'Chi063Syst', NULL, 'null', 'RoleConfig', '?', '2012-05-11 08:49:41', 'admin', 'admin', '2013-10-11 23:58:53', NULL, 8);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(27, 8, 'config.ini', 'wcmf', NULL, 'Chi064Syst', NULL, 'null', 'Authorization', '?', '2012-05-11 08:49:42', 'admin', 'admin', '2013-10-11 23:58:53', NULL, 9);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(28, 8, 'config.ini', 'wcmf', NULL, 'Chi065Syst', NULL, 'null', 'Localization', '?', '2012-05-11 08:49:42', 'admin', 'admin', '2013-10-11 23:58:53', NULL, 10);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(34, 8, 'config.ini', 'wcmf', NULL, 'Chi066Syst', NULL, 'null', 'Search', '?', '2012-06-23 00:49:39', 'admin', 'admin', '2013-10-11 23:58:53', NULL, 11);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(36, 8, 'config.ini', 'wcmf', NULL, 'Chi067Syst', NULL, 'null', 'Boolean', '?', '2012-06-23 00:49:44', 'admin', 'admin', '2013-10-11 23:58:53', NULL, 12);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(43, 42, 'server.ini', 'wcmf', NULL, 'Chi069Syst', NULL, 'null', 'Database', '?', '2012-06-23 01:20:11', 'admin', 'admin', '2012-06-23 01:20:11', NULL, 43);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(49, 42, 'server.ini', 'wcmf', NULL, 'Chi070Syst', NULL, 'null', 'Localization', '?', '2012-06-23 01:20:15', 'admin', 'admin', '2013-02-28 17:42:39', NULL, 49);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(51, 42, 'server.ini', 'wcmf', NULL, 'Chi071Syst', NULL, 'null', 'Languages', '?', '2012-06-23 01:20:18', 'admin', 'admin', '2012-06-23 01:20:18', NULL, 51);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(54, 42, 'server.ini', 'wcmf', NULL, 'Chi072Syst', NULL, 'null', 'NewInstance', '?', '2012-06-23 01:20:23', 'admin', 'admin', '2012-06-23 01:20:23', NULL, 54);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(57, 42, 'server.ini', 'wcmf', NULL, 'Chi073Syst', NULL, 'null', 'RemoteServer', '?', '2012-06-23 01:20:29', 'admin', 'admin', '2012-06-23 01:20:29', NULL, 57);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(58, 42, 'server.ini', 'wcmf', NULL, 'Chi074Syst', NULL, 'null', 'RemoteUser', '?', '2012-06-23 01:20:35', 'admin', 'admin', '2012-06-23 01:20:35', NULL, 58);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(60, 59, 'persistence.ini', 'wcmf', NULL, 'Chi075Syst', NULL, 'null', 'PersistenceFacade', 'PersistenceFacade implementation', '2012-05-11 08:49:51', 'admin', 'admin', '2012-05-11 08:49:51', NULL, 60);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(65, 59, 'persistence.ini', 'wcmf', NULL, 'Chi076Syst', NULL, 'null', 'AuditingLogStragegy', '?', '2012-06-23 01:25:16', 'admin', 'admin', '2012-06-23 01:25:16', NULL, 65);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(67, 59, 'persistence.ini', 'wcmf', NULL, 'Chi077Syst', NULL, 'null', 'Transaction', 'Transaction implementation', '2012-05-11 08:49:53', 'admin', 'admin', '2012-05-11 08:49:53', NULL, 67);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(69, 59, 'persistence.ini', 'wcmf', NULL, 'Chi078Syst', NULL, 'null', 'Converter', '?', '2012-06-23 01:25:25', 'admin', 'admin', '2012-06-23 01:25:25', NULL, 69);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(70, 59, 'persistence.ini', 'wcmf', NULL, 'Chi079Syst', NULL, 'null', 'LockHandler', 'LockHandler implementation', '2012-05-11 08:49:54', 'admin', 'admin', '2012-05-11 08:49:54', NULL, 70);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(72, 8, 'config.ini', 'wcmf', NULL, 'Chi080Syst', NULL, 'null', 'User', 'User implementation', '2012-05-11 08:49:55', 'admin', 'admin', '2013-10-11 23:58:53', NULL, 13);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(75, 74, 'presentation.ini', 'wcmf', NULL, 'Chi081Syst', NULL, 'null', 'View', '?', '2012-06-23 01:31:39', 'admin', 'admin', '2012-06-23 01:31:39', NULL, 75);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(83, 74, 'presentation.ini', 'wcmf', NULL, 'Chi082Syst', NULL, 'null', 'Formats', '?', '2012-06-23 01:31:45', 'admin', 'admin', '2012-06-23 01:31:45', NULL, 83);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(88, 74, 'presentation.ini', 'wcmf', NULL, 'Chi083Syst', NULL, 'null', 'HtmlFormat', '?', '2012-06-23 01:33:20', 'admin', 'admin', '2012-06-23 01:33:20', NULL, 88);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(90, 74, 'presentation.ini', 'wcmf', NULL, 'Chi084Syst', NULL, 'null', 'JsonFormat', '?', '2012-06-23 01:33:53', 'admin', 'admin', '2012-06-23 01:33:53', NULL, 90);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(92, 74, 'presentation.ini', 'wcmf', NULL, 'Chi085Syst', NULL, 'null', 'SoapFormat', '?', '2012-06-23 01:34:00', 'admin', 'admin', '2012-06-23 01:34:00', NULL, 92);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(94, 74, 'presentation.ini', 'wcmf', NULL, 'Chi086Syst', NULL, 'null', 'NullFormat', '?', '2012-06-23 01:34:06', 'admin', 'admin', '2012-06-23 01:34:06', NULL, 94);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(96, 74, 'presentation.ini', 'wcmf', NULL, 'Chi087Syst', NULL, 'null', 'ListStrategies', '?', '2012-06-23 01:35:20', 'admin', 'admin', '2012-06-23 01:35:20', NULL, 96);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(102, 74, 'presentation.ini', 'wcmf', NULL, 'Chi088Syst', NULL, 'null', 'FixedListStrategy', '?', '2012-06-23 01:35:24', 'admin', 'admin', '2012-06-23 01:35:24', NULL, 102);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(104, 74, 'presentation.ini', 'wcmf', NULL, 'Chi089Syst', NULL, 'null', 'FunctionListStrategy', '?', '2012-06-23 01:35:32', 'admin', 'admin', '2012-06-23 01:35:32', NULL, 104);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(106, 74, 'presentation.ini', 'wcmf', NULL, 'Chi090Syst', NULL, 'null', 'ConfigListStrategy', '?', '2012-06-23 01:31:49', 'admin', 'admin', '2012-06-23 01:31:49', NULL, 106);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(108, 74, 'presentation.ini', 'wcmf', NULL, 'Chi091Syst', NULL, 'null', 'NodeListStrategy', '?', '2012-06-23 01:34:19', 'admin', 'admin', '2013-07-12 15:41:03', NULL, 108);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(115, 74, 'presentation.ini', 'wcmf', NULL, 'Chi094Syst', NULL, 'null', 'DisplayTypes', '?', '2012-06-23 01:34:45', 'admin', 'admin', '2012-06-23 01:34:45', NULL, 115);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(132, 74, 'presentation.ini', 'wcmf', NULL, 'Chi099Syst', NULL, 'null', 'InputTypes', '?', '2012-06-23 01:37:58', 'admin', 'admin', '2013-07-12 15:44:41', NULL, 132);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(4683, 59, 'persistence.ini', 'wcmf', NULL, 'Chi113Syst', NULL, '1.0', 'ConcurrencyManager', '?', '2013-02-19 19:14:54', 'admin', 'admin', '2013-02-19 19:39:15', NULL, 4683);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(5366, 8, 'config.ini', 'wcmf', NULL, 'Chi114Syst', NULL, '1.0', 'Session', '?', '2013-02-28 17:49:22', 'admin', 'admin', '2013-10-11 23:58:53', NULL, 15);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(5374, 8, 'config.ini', 'wcmf', NULL, 'Chi115Syst', NULL, '1.0', 'EventManager', '?', '2013-02-28 17:51:04', 'admin', 'admin', '2013-10-11 23:58:53', NULL, 16);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(5402, 8, 'config.ini', 'wcmf', NULL, 'Chi116Syst', NULL, '1.0', 'ActionMapper', '?', '2013-02-28 17:56:26', 'admin', 'admin', '2013-10-11 23:58:53', NULL, 17);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(5470, 8, 'config.ini', 'wcmf', NULL, 'Chi117Syst', NULL, '1.0', 'PermissionManager', '?', '2013-02-28 18:07:56', 'admin', 'admin', '2013-10-11 23:58:53', NULL, 18);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(5840, 8, 'config.ini', 'wcmf', NULL, 'Chi118Syst', NULL, '1.0', 'AuthUser', '?', '2013-03-01 16:37:40', 'admin', 'admin', '2013-10-11 23:58:53', NULL, 19);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(5992, 74, 'presentation.ini', 'wcmf', NULL, 'Chi119Syst', NULL, '1.0', 'DionysosSerializer', '?', '2013-04-25 19:15:33', 'admin', 'admin', '2013-04-26 12:56:26', NULL, 5992);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(6049, 74, 'presentation.ini', 'wcmf', NULL, 'Chi120Syst', NULL, '1.0', 'DojoSerializer', '?', '2013-04-25 19:35:56', 'admin', 'admin', '2013-04-26 12:56:52', NULL, 6049);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(7088, 8, 'config.ini', 'wcmf', NULL, 'Chi121Syst', NULL, 'null', 'Role', 'Role implementation', '2013-10-11 23:57:32', 'admin', 'admin', '2013-10-12 00:01:05', NULL, 14);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(7165, 74, 'presentation.ini', 'wcmf', NULL, 'Chi122Syst', NULL, 'null', 'FileListStrategy', '?', '2013-10-12 00:11:27', 'admin', 'admin', '2013-10-12 00:15:49', NULL, 7165);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `ChiValue`
--

DROP TABLE IF EXISTS `ChiValue`;
CREATE TABLE IF NOT EXISTS `ChiValue` (
  `id` int(11) NOT NULL,
  `fk_chicontroller_id` int(11) DEFAULT NULL,
  `fk_chisystem_id` int(11) DEFAULT NULL,
  `fk_chinodemanytomany_id` int(11) DEFAULT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_chinode_id` int(11) DEFAULT NULL,
  `column_name` varchar(255) DEFAULT NULL,
  `display_type` varchar(255) DEFAULT NULL,
  `restrictions_description` varchar(255) DEFAULT NULL,
  `restrictions_match` varchar(255) DEFAULT NULL,
  `restrictions_not_match` varchar(255) DEFAULT NULL,
  `input_type` varchar(255) DEFAULT NULL,
  `app_data_type` varchar(255) DEFAULT NULL,
  `db_data_type` varchar(255) DEFAULT NULL,
  `is_editable` varchar(255) DEFAULT NULL,
  `default` varchar(255) DEFAULT NULL,
  `propertytype` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chicontroller_id` (`fk_chicontroller_id`),
  KEY `fk_chisystem_id` (`fk_chisystem_id`),
  KEY `fk_chinodemanytomany_id` (`fk_chinodemanytomany_id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_chinode_id` (`fk_chinode_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `ChiValue`
--

INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(10, NULL, 9, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', '{server.ini, persistence.ini, presentation.ini}', '531', NULL, 'Chi027Val', NULL, '1.0', 'include', '?', '2012-05-11 08:48:46', 'admin', 'admin', '2012-06-23 00:53:10', NULL, 10);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(12, NULL, 11, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf\\application\\controller\\FailureController', '531', NULL, 'Chi028Val', NULL, '1.0', '??failure', NULL, '2012-05-11 08:48:46', 'admin', 'admin', '2013-04-26 12:53:53', NULL, 12);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(16, NULL, 15, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'WCMF DEFAULT', '531', NULL, 'Chi029Val', NULL, '1.0', 'applicationTitle', '?', '2012-05-11 08:48:47', 'admin', 'admin', '2014-02-25 00:12:05', NULL, 16);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(17, NULL, 15, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', '../wcmf/', '531', NULL, 'Chi030Val', NULL, '1.0', 'libDir', '?', '2012-05-11 08:48:47', 'admin', 'admin', '2012-06-23 00:56:36', NULL, 17);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(21, NULL, 15, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'false', '531', NULL, 'Chi034Val', NULL, '1.0', 'anonymous', '?', '2012-05-11 08:48:47', 'admin', 'admin', '2012-06-23 02:19:17', NULL, 30);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(22, NULL, 15, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', '{}', '531', NULL, 'Chi035Val', NULL, '1.0', 'rootTypes', '?', '2012-05-11 08:48:47', 'admin', 'admin', '2014-02-25 00:11:50', NULL, 22);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(24, NULL, 23, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'media/', '531', NULL, 'Chi036Val', NULL, '1.0', 'uploadDir', '?', '2012-05-11 08:48:48', 'admin', 'admin', '2013-07-12 19:07:22', NULL, 24);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(26, NULL, 25, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'admin.ini', '531', NULL, 'Chi037Val', NULL, '1.0', 'administrators', '?', '2012-05-11 08:48:48', 'admin', 'admin', '2012-06-24 02:24:36', NULL, 26);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(29, NULL, 15, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', '../locale/', '531', NULL, 'Chi038Val', NULL, '1.0', 'localeDir', '?', '2012-05-11 08:48:48', 'admin', 'admin', '2013-07-12 19:06:23', NULL, 21);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(30, NULL, 15, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'en', '531', NULL, 'Chi039Val', NULL, '1.0', 'language', '?', '2012-05-11 08:48:49', 'admin', 'admin', '2013-07-12 19:07:01', NULL, 29);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(31, NULL, 28, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', '{text, textarea, filebrowser, linkbrowser, ckeditor}', '531', NULL, 'Chi040Val', NULL, '1.0', 'inputTypes', '?', '2012-05-11 08:48:49', 'admin', 'admin', '2012-06-24 02:26:27', NULL, 31);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(32, NULL, 28, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'Language', '531', NULL, 'Chi041Val', NULL, '1.0', 'languageType', '?', '2012-05-11 08:48:49', 'admin', 'admin', '2012-06-24 02:26:39', NULL, 32);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(33, NULL, 28, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'Translation', '531', NULL, 'Chi042Val', NULL, '1.0', 'translationType', '?', '2012-05-11 08:48:49', 'admin', 'admin', '2012-06-24 02:27:02', NULL, 33);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(35, NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf\\lib\\search\\impl\\LuceneSearch', '531', NULL, 'Chi043Val', NULL, '1.0', '__class', '?', '2012-05-11 08:48:50', 'admin', 'admin', '2014-02-10 14:56:57', NULL, 35);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(37, NULL, 36, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'no', '531', NULL, 'Chi044Val', NULL, '1.0', '0', '?', '2012-05-11 08:48:50', 'admin', 'admin', '2012-06-23 00:54:55', NULL, 37);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(38, NULL, 36, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'yes', '531', NULL, 'Chi045Val', NULL, '1.0', '1', '?', '2012-05-11 08:48:50', 'admin', 'admin', '2012-06-23 00:55:14', NULL, 38);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(44, NULL, 43, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'mysql', '531', NULL, 'Chi047Val', NULL, '1.0', 'dbType', '?', '2012-05-11 08:48:51', 'admin', 'admin', '2012-06-23 01:23:03', NULL, 44);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(45, NULL, 43, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'localhost', '531', NULL, 'Chi048Val', NULL, '1.0', 'dbHostName', '?', '2012-05-11 08:48:51', 'admin', 'admin', '2012-06-23 01:23:23', NULL, 45);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(46, NULL, 43, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf_testapp', '531', NULL, 'Chi049Val', NULL, '1.0', 'dbName', '?', '2012-05-11 08:48:51', 'admin', 'admin', '2013-02-19 15:48:23', NULL, 46);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(47, NULL, 43, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'root', '531', NULL, 'Chi050Val', NULL, '1.0', 'dbUserName', '?', '2012-05-11 08:48:51', 'admin', 'admin', '2013-10-12 00:32:48', NULL, 47);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(48, NULL, 43, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '531', NULL, 'Chi051Val', NULL, '1.0', 'dbPassword', '?', '2012-05-11 08:48:51', 'admin', 'admin', '2013-10-12 00:33:05', NULL, 48);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(50, NULL, 49, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'en', '531', NULL, 'Chi052Val', NULL, '1.0', 'defaultLanguage', '?', '2012-05-11 08:48:51', 'admin', 'admin', '2012-06-23 01:25:01', NULL, 50);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(52, NULL, 51, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'Deutsch', '531', NULL, 'Chi053Val', NULL, '1.0', 'de', '?', '2012-05-11 08:48:52', 'admin', 'admin', '2012-06-23 01:21:16', NULL, 52);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(53, NULL, 51, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'English', '531', NULL, 'Chi054Val', NULL, '1.0', 'en', '?', '2012-05-11 08:48:52', 'admin', 'admin', '2012-06-23 01:21:37', NULL, 53);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(55, NULL, 54, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf_', '531', NULL, 'Chi055Val', NULL, '1.0', 'dbPrefix', '?', '2012-05-11 08:48:52', 'admin', 'admin', '2012-06-23 01:22:11', NULL, 55);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(56, NULL, 54, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', '../../', '531', NULL, 'Chi056Val', NULL, '1.0', 'targetDir', '?', '2012-05-11 08:48:52', 'admin', 'admin', '2012-06-23 01:22:37', NULL, 56);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(61, NULL, 60, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf\\lib\\persistence\\impl\\DefaultPersistenceFacade', '531', NULL, 'Chi057Val', NULL, '1.0', '__class', '?', '2012-05-11 08:48:53', 'admin', 'admin', '2013-03-01 16:07:10', NULL, 61);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(62, NULL, 60, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', '$typeMapping', '531', NULL, 'Chi058Val', NULL, '1.0', 'mappers', '?', '2012-05-11 08:48:53', 'admin', 'admin', '2012-06-23 01:27:23', NULL, 62);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(63, NULL, 60, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'false', '531', NULL, 'Chi059Val', NULL, '1.0', 'logging', '?', '2012-05-11 08:48:53', 'admin', 'admin', '2012-06-23 01:27:40', NULL, 63);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(64, NULL, 60, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', '$auditingLogStragegy', '531', NULL, 'Chi060Val', NULL, '1.0', 'logStrategy', '?', '2012-05-11 08:48:54', 'admin', 'admin', '2012-06-23 01:28:05', NULL, 64);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(66, NULL, 65, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf\\lib\\persistence\\output\\impl\\AuditingOutputStrategy', '531', NULL, 'Chi061Val', NULL, '1.0', '__class', '?', '2012-05-11 08:48:54', 'admin', 'admin', '2013-03-01 16:07:24', NULL, 66);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(68, NULL, 67, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf\\lib\\persistence\\impl\\DefaultTransaction', '531', NULL, 'Chi062Val', NULL, '1.0', '__class', '?', '2012-05-11 08:48:54', 'admin', 'admin', '2013-03-01 16:06:56', NULL, 68);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(71, NULL, 70, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf\\lib\\persistence\\concurrency\\impl\\DefaultLockHandler', '531', NULL, 'Chi063Val', NULL, '1.0', '__class', '?', '2012-05-11 08:48:55', 'admin', 'admin', '2013-03-01 16:07:37', NULL, 71);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(73, NULL, 72, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'app\\src\\model\\wcmf\\User', '531', NULL, 'Chi064Val', NULL, '1.0', '__class', '?', '2012-05-11 08:48:55', 'admin', 'admin', '2013-10-12 00:02:58', NULL, 73);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(76, NULL, 75, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf\\lib\\presentation\\view\\impl\\SmartyView', '531', NULL, 'Chi065Val', NULL, '1.0', '__class', '?', '2012-05-11 08:48:55', 'admin', 'admin', '2013-03-01 16:20:54', NULL, 76);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(77, NULL, 75, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'false', '531', NULL, 'Chi066Val', NULL, '1.0', '__shared', '?', '2012-05-11 08:48:55', 'admin', 'admin', '2012-06-23 02:15:31', NULL, 77);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(78, NULL, 75, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', '../cache/smarty/', '531', NULL, 'Chi067Val', NULL, '1.0', 'smartyDir', '?', '2012-05-11 08:48:56', 'admin', 'admin', '2014-02-10 14:58:41', NULL, 78);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(79, NULL, 75, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'true', '531', NULL, 'Chi068Val', NULL, '1.0', 'compileCheck', '?', '2012-05-11 08:48:56', 'admin', 'admin', '2012-06-23 02:16:12', NULL, 79);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(81, NULL, 75, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'false', '531', NULL, 'Chi070Val', NULL, '1.0', 'caching', '?', '2012-05-11 08:48:56', 'admin', 'admin', '2012-06-23 02:16:36', NULL, 81);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(82, NULL, 75, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', '3600', '3463', NULL, 'Chi071Val', NULL, '1.0', 'cacheLifetime', '?', '2012-05-11 08:48:56', 'admin', 'admin', '2012-06-23 02:18:08', NULL, 82);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(84, NULL, 83, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', '$htmlFormat', '531', NULL, 'Chi072Val', NULL, '1.0', 'html', '?', '2012-05-11 08:48:56', 'admin', 'admin', '2012-06-23 02:14:05', NULL, 84);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(85, NULL, 83, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', '$jsonFormat', '531', NULL, 'Chi073Val', NULL, '1.0', 'json', '?', '2012-05-11 08:48:57', 'admin', 'admin', '2012-06-23 02:14:21', NULL, 85);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(86, NULL, 83, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', '$soapFormat', '531', NULL, 'Chi074Val', NULL, '1.0', 'soap', '?', '2012-05-11 08:48:57', 'admin', 'admin', '2012-06-23 02:14:37', NULL, 86);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(87, NULL, 83, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', '$nullFormat', '531', NULL, 'Chi075Val', NULL, '1.0', 'null', '?', '2012-05-11 08:48:57', 'admin', 'admin', '2012-06-23 02:14:53', NULL, 87);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(89, NULL, 88, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf\\lib\\presentation\\format\\impl\\HtmlFormat', '531', NULL, 'Chi076Val', NULL, '1.0', '__class', '?', '2012-05-11 08:48:57', 'admin', 'admin', '2013-03-01 16:14:32', NULL, 89);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(91, NULL, 90, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf\\lib\\presentation\\format\\impl\\JsonFormat', '531', NULL, 'Chi077Val', NULL, '1.0', '__class', '?', '2012-05-11 08:48:58', 'admin', 'admin', '2013-03-01 16:14:55', NULL, 91);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(93, NULL, 92, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf\\lib\\presentation\\format\\impl\\SoapFormat', '531', NULL, 'Chi078Val', NULL, '1.0', '__class', '?', '2012-05-11 08:48:58', 'admin', 'admin', '2013-03-01 16:18:30', NULL, 93);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(95, NULL, 94, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf\\lib\\presentation\\format\\impl\\NullFormat', '531', NULL, 'Chi079Val', NULL, '1.0', '__class', '?', '2012-05-11 08:48:58', 'admin', 'admin', '2013-03-01 16:18:43', NULL, 95);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(97, NULL, 96, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', '$fixedListStrategy', '531', NULL, 'Chi080Val', NULL, '1.0', 'fix', '?', '2012-05-11 08:48:59', 'admin', 'admin', '2012-06-23 02:11:27', NULL, 97);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(98, NULL, 96, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', '$functionListStrategy', '531', NULL, 'Chi081Val', NULL, '1.0', 'function', '?', '2012-05-11 08:48:59', 'admin', 'admin', '2012-06-23 02:11:42', NULL, 98);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(99, NULL, 96, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', '$configListStrategy', '531', NULL, 'Chi082Val', NULL, '1.0', 'config', '?', '2012-05-11 08:48:59', 'admin', 'admin', '2012-06-23 02:11:57', NULL, 99);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(100, NULL, 96, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', '$nodeListStrategy', '531', NULL, 'Chi083Val', NULL, '1.0', 'node', '?', '2012-05-11 08:48:59', 'admin', 'admin', '2013-07-12 15:39:53', NULL, 100);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(103, NULL, 102, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf\\lib\\presentation\\control\\lists\\impl\\FixedListStrategy', '531', NULL, 'Chi085Val', NULL, '1.0', '__class', '?', '2012-05-11 08:49:00', 'admin', 'admin', '2013-03-01 16:19:28', NULL, 103);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(105, NULL, 104, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf\\lib\\presentation\\control\\lists\\impl\\FunctionListStrategy', '531', NULL, 'Chi086Val', NULL, '1.0', '__class', '?', '2012-05-11 08:49:00', 'admin', 'admin', '2013-03-01 16:19:48', NULL, 105);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(107, NULL, 106, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf\\lib\\presentation\\control\\lists\\impl\\ConfigListStrategy', '531', NULL, 'Chi087Val', NULL, '1.0', '__class', '?', '2012-05-11 08:49:00', 'admin', 'admin', '2013-03-01 16:20:03', NULL, 107);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(109, NULL, 108, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf\\lib\\presentation\\control\\lists\\impl\\NodeListStrategy', '531', NULL, 'Chi088Val', NULL, '1.0', '__class', '?', '2012-05-11 08:49:00', 'admin', 'admin', '2013-07-12 15:41:31', NULL, 109);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(116, NULL, 115, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'app/js/ui/data/display/renderer/Text', '531', NULL, 'Chi092Val', NULL, '1.0', 'text', '?', '2012-05-11 08:49:02', 'admin', 'admin', '2013-10-12 00:21:50', NULL, 116);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(117, NULL, 115, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'app/js/ui/data/display/renderer/Image', '531', NULL, 'Chi093Val', NULL, '1.0', 'image', '?', '2012-05-11 08:49:02', 'admin', 'admin', '2013-10-12 00:27:56', NULL, 117);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(133, NULL, 132, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'app/js/ui/data/input/widget/CheckBox', '531', NULL, 'Chi104Val', NULL, '1.0', 'checkbox', '?', '2012-05-11 08:49:05', 'admin', 'admin', '2013-10-12 00:28:29', NULL, 133);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(134, NULL, 132, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'app/js/ui/data/input/widget/CKEditor', '531', NULL, 'Chi105Val', NULL, '1.0', 'ckeditor', '?', '2012-05-11 08:49:05', 'admin', 'admin', '2013-10-12 00:28:36', NULL, 134);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(135, NULL, 132, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'app/js/ui/data/input/widget/Date', '531', NULL, 'Chi106Val', NULL, '1.0', 'date', '?', '2012-05-11 08:49:05', 'admin', 'admin', '2013-10-12 00:28:47', NULL, 135);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(136, NULL, 132, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'app/js/ui/data/input/widget/FileBrowser', '531', NULL, 'Chi107Val', NULL, '1.0', 'filebrowser', '?', '2012-05-11 08:49:05', 'admin', 'admin', '2013-10-12 00:28:54', NULL, 136);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(137, NULL, 132, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'app/js/ui/data/input/widget/LinkBrowser', '531', NULL, 'Chi108Val', NULL, '1.0', 'linkbrowser', '?', '2012-05-11 08:49:05', 'admin', 'admin', '2013-10-12 00:29:02', NULL, 137);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(138, NULL, 132, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'app/js/ui/data/input/widget/PasswordBox', '531', NULL, 'Chi109Val', NULL, '1.0', 'password', '?', '2012-05-11 08:49:05', 'admin', 'admin', '2013-10-12 00:29:57', NULL, 138);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(139, NULL, 132, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'app/js/ui/data/input/widget/RadioButton', '531', NULL, 'Chi110Val', NULL, '1.0', 'radio', '?', '2012-05-11 08:49:05', 'admin', 'admin', '2013-10-12 00:30:16', NULL, 139);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(140, NULL, 132, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'app/js/ui/data/input/widget/SelectBox', '531', NULL, 'Chi111Val', NULL, '1.0', 'select', '?', '2012-05-11 08:49:06', 'admin', 'admin', '2013-10-12 00:30:25', NULL, 140);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(142, NULL, 132, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'app/js/ui/data/input/widget/TextBox', '531', NULL, 'Chi113Val', NULL, '1.0', 'text', '?', '2012-05-11 08:49:06', 'admin', 'admin', '2013-10-12 00:30:32', NULL, 142);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(143, NULL, 132, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'app/js/ui/data/input/widget/TextArea', '531', NULL, 'Chi114Val', NULL, '1.0', 'textarea', '?', '2012-05-11 08:49:06', 'admin', 'admin', '2013-10-12 00:30:39', NULL, 143);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(145, NULL, 132, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'app/js/ui/data/input/widget/BinaryCheckBox', '531', NULL, 'Chi116Val', NULL, '1.0', 'binarycheckbox', '?', '2012-05-11 08:49:06', 'admin', 'admin', '2013-10-12 00:30:46', NULL, 145);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(280, NULL, NULL, NULL, NULL, 278, NULL, '1041', NULL, NULL, NULL, 'text', 'DATATYPE_ATTRIBUTE', 'DATETIME', 'false', NULL, '530', NULL, 'Chi159Val', NULL, '1.0', 'created', NULL, '2012-05-11 08:49:25', 'admin', 'admin', '2012-06-22 23:56:21', NULL, 280);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(281, NULL, NULL, NULL, NULL, 278, NULL, '1041', NULL, NULL, NULL, 'text', 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '531', NULL, 'Chi160Val', NULL, '1.0', 'creator', '?', '2012-05-11 08:49:25', 'admin', 'admin', '2012-06-22 23:56:13', NULL, 281);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(282, NULL, NULL, NULL, NULL, 278, NULL, '1041', NULL, NULL, NULL, 'text', 'DATATYPE_ATTRIBUTE', 'DATETIME', 'false', NULL, '530', NULL, 'Chi161Val', NULL, '1.0', 'modified', '?', '2012-05-11 08:49:25', 'admin', 'admin', '2012-06-22 23:56:14', NULL, 282);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(283, NULL, NULL, NULL, NULL, 278, NULL, '1041', NULL, NULL, NULL, 'text', 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '531', NULL, 'Chi162Val', NULL, '1.0', 'last_editor', '?', '2012-05-11 08:49:25', 'admin', 'admin', '2012-06-22 23:56:10', NULL, 283);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(315, NULL, NULL, NULL, NULL, 313, NULL, '1041', NULL, NULL, NULL, 'text', 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '531', NULL, 'Chi188Val', NULL, '1.0', 'name', '?', '2012-05-11 08:49:30', 'admin', 'admin', '2012-06-23 00:43:30', NULL, 315);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(316, NULL, NULL, NULL, NULL, 313, NULL, NULL, NULL, NULL, NULL, 'text', 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '531', NULL, 'Chi189Val', NULL, '1.0', 'code', '?', '2012-05-11 08:49:30', 'admin', 'admin', '2012-06-23 00:43:56', NULL, 316);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(320, NULL, NULL, NULL, NULL, 317, NULL, '1041', NULL, NULL, NULL, 'text', 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '531', NULL, 'Chi192Val', NULL, '1.0', 'objectid', '?', '2012-05-11 08:49:31', 'admin', 'admin', '2012-06-23 00:38:45', NULL, 320);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(321, NULL, NULL, NULL, NULL, 317, NULL, '1041', NULL, NULL, NULL, 'text', 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '531', NULL, 'Chi193Val', NULL, '1.0', 'sessionid', '?', '2012-05-11 08:49:31', 'admin', 'admin', '2012-06-23 00:39:15', NULL, 321);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(322, NULL, NULL, NULL, NULL, 317, NULL, '1041', NULL, NULL, NULL, 'text', 'DATATYPE_ATTRIBUTE', 'DATETIME', 'false', NULL, '530', NULL, 'Chi194Val', NULL, '1.0', 'since', '?', '2012-05-11 08:49:31', 'admin', 'admin', '2012-06-23 00:39:50', NULL, 322);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(325, NULL, NULL, NULL, NULL, 323, NULL, '1041', NULL, NULL, NULL, 'text', 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'true', NULL, '531', NULL, 'Chi196Val', NULL, '1.0', 'name', '?', '2012-05-11 08:49:32', 'admin', 'admin', '2012-06-23 00:33:01', NULL, 325);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(328, NULL, NULL, NULL, NULL, 326, NULL, '1041', NULL, NULL, NULL, 'text', 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '531', NULL, 'Chi198Val', NULL, '1.0', 'objectid', 'The object id of the object to which the translation belongs', '2012-05-11 08:49:32', 'admin', 'admin', '2012-06-23 00:45:07', NULL, 328);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(329, NULL, NULL, NULL, NULL, 326, NULL, '1041', NULL, NULL, NULL, 'text', 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '531', NULL, 'Chi199Val', NULL, '1.0', 'attribute', 'The attribute of the object that is translated', '2012-05-11 08:49:32', 'admin', 'admin', '2012-06-23 00:46:19', NULL, 329);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(330, NULL, NULL, NULL, NULL, 326, NULL, '1041', NULL, NULL, NULL, 'textarea', 'DATATYPE_ATTRIBUTE', 'TEXT', 'false', NULL, '531', NULL, 'Chi200Val', NULL, '1.0', 'translation', 'The translation', '2012-05-11 08:49:32', 'admin', 'admin', '2012-06-23 00:47:08', NULL, 330);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(331, NULL, NULL, NULL, NULL, 326, NULL, '1041', NULL, NULL, NULL, 'text', 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '531', NULL, 'Chi201Val', NULL, '1.0', 'language', 'The language of the translation', '2012-05-11 08:49:32', 'admin', 'admin', '2012-06-23 00:47:27', NULL, 331);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(335, NULL, NULL, NULL, NULL, 332, NULL, '1041', NULL, NULL, NULL, 'text', 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '531', NULL, 'Chi204Val', NULL, '1.0', 'key', '?', '2012-05-11 08:49:33', 'admin', 'admin', '2012-06-23 00:41:04', NULL, 335);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(336, NULL, NULL, NULL, NULL, 332, NULL, '1041', NULL, NULL, NULL, 'text', 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'true', NULL, '531', NULL, 'Chi205Val', NULL, '1.0', 'val', '?', '2012-05-11 08:49:33', 'admin', 'admin', '2012-06-23 00:42:01', NULL, 336);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(339, NULL, NULL, NULL, NULL, 337, NULL, '1041', NULL, NULL, NULL, 'text', 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'true', NULL, '531', NULL, 'Chi207Val', NULL, '1.0', 'login', '?', '2012-05-11 08:49:34', 'admin', 'admin', '2012-06-23 00:34:45', NULL, 339);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(340, NULL, NULL, NULL, NULL, 337, NULL, '1041', NULL, NULL, NULL, 'password', 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'true', NULL, '531', NULL, 'Chi208Val', NULL, '1.0', 'password', '?', '2012-05-11 08:49:34', 'admin', 'admin', '2012-06-23 00:35:30', NULL, 340);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(341, NULL, NULL, NULL, NULL, 337, NULL, '1041', NULL, NULL, NULL, 'text', 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'true', NULL, '531', NULL, 'Chi209Val', NULL, '1.0', 'name', '?', '2012-05-11 08:49:34', 'admin', 'admin', '2012-06-23 00:36:07', NULL, 341);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(342, NULL, NULL, NULL, NULL, 337, NULL, '1041', NULL, NULL, NULL, 'text', 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'true', NULL, '531', NULL, 'Chi210Val', NULL, '1.0', 'firstname', '?', '2012-05-11 08:49:34', 'admin', 'admin', '2012-06-23 00:36:36', NULL, 342);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(343, NULL, NULL, NULL, NULL, 337, NULL, '1041', NULL, NULL, NULL, 'select#file:../config/|/\\..ini$/', 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'true', NULL, '531', NULL, 'Chi211Val', NULL, '1.0', 'config', '?', '2012-05-11 08:49:34', 'admin', 'admin', '2013-10-11 23:02:08', NULL, 343);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(3909, NULL, 43, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', NULL, 'utf8', '531', NULL, 'Chi216Val', NULL, '1.0', 'dbCharSet', '?', '2012-06-26 00:00:15', 'admin', 'admin', '2012-06-26 00:00:48', NULL, 3909);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(7130, NULL, 96, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', NULL, '$fileListStrategy', NULL, NULL, 'Chi236Val', NULL, '1.0', 'file', '?', '2013-10-12 00:03:52', 'admin', 'admin', '2013-10-12 00:11:21', NULL, 7130);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(7099, NULL, 7088, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', NULL, 'app\\src\\model\\wcmf\\Role', NULL, NULL, 'Chi235Val', NULL, '1.0', '__class', '?', '2013-10-12 00:00:43', 'admin', 'admin', '2013-10-12 00:02:42', NULL, 7099);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(4690, NULL, 4683, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', NULL, 'wcmf\\lib\\persistence\\concurrency\\impl\\DefaultConcurrencyManager', NULL, NULL, 'Chi219Val', NULL, '1.0', '__class', '?', '2013-02-19 19:15:09', 'admin', 'admin', '2013-03-01 16:13:39', NULL, 4690);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(4698, NULL, 4683, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', NULL, '$lockHandler', NULL, NULL, 'Chi220Val', NULL, '1.0', 'lockHandler', '?', '2013-02-19 19:15:31', 'admin', 'admin', '2013-02-19 19:19:58', NULL, 4698);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(5357, NULL, 28, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', NULL, 'wcmf\\lib\\i18n\\impl\\DefaultLocalization', NULL, NULL, 'Chi224Val', NULL, '1.0', '__class', '?', '2013-02-28 17:45:40', 'admin', 'admin', '2013-03-01 16:04:39', NULL, 29);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(5377, NULL, 5366, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', NULL, 'wcmf\\lib\\core\\impl\\DefaultSession', NULL, NULL, 'Chi225Val', NULL, '1.0', '__class', '?', '2013-02-28 17:51:11', 'admin', 'admin', '2013-03-01 16:04:21', NULL, 5377);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(5394, NULL, 5374, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', NULL, 'wcmf\\lib\\core\\impl\\DefaultEventManager', NULL, NULL, 'Chi226Val', NULL, '1.0', '__class', '?', '2013-02-28 17:54:23', 'admin', 'admin', '2013-03-01 16:05:23', NULL, 5394);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(5421, NULL, 5402, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', NULL, 'wcmf\\lib\\presentation\\impl\\DefaultActionMapper', NULL, NULL, 'Chi227Val', NULL, '1.0', '__class', '?', '2013-02-28 17:58:56', 'admin', 'admin', '2013-03-01 16:04:05', NULL, 5421);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(5479, NULL, 5470, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', NULL, 'wcmf\\lib\\security\\impl\\DefaultPermissionManager', NULL, NULL, 'Chi228Val', NULL, '1.0', '__class', '?', '2013-02-28 18:10:15', 'admin', 'admin', '2013-03-01 16:05:09', NULL, 5479);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(5849, NULL, 5840, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', NULL, 'wcmf\\lib\\security\\principal\\impl\\DefaultAuthUser', NULL, NULL, 'Chi229Val', NULL, '1.0', '__class', '?', '2013-03-01 16:39:22', 'admin', 'admin', '2013-03-01 16:44:33', NULL, 5849);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(6001, NULL, 5992, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', NULL, 'wcmf\\lib\\model\\impl\\DionysosNodeSerializer', NULL, NULL, 'Chi231Val', NULL, '1.0', '__class', '?', '2013-04-25 19:21:42', 'admin', 'admin', '2013-04-25 19:29:47', NULL, 6001);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(6014, NULL, 90, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', NULL, '$dojoSerializer', NULL, NULL, 'Chi232Val', NULL, '1.0', 'serializer', '?', '2013-04-25 19:29:51', 'admin', 'admin', '2013-04-25 19:31:33', NULL, 6014);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(6025, NULL, 92, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', NULL, '$dojoSerializer', NULL, NULL, 'Chi233Val', NULL, '1.0', 'serializer', '?', '2013-04-25 19:31:33', 'admin', 'admin', '2013-04-25 19:33:32', NULL, 6025);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(6058, NULL, 6049, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', NULL, 'wcmf\\lib\\model\\impl\\DojoNodeSerializer', NULL, NULL, 'Chi234Val', NULL, '1.0', '__class', NULL, '2013-04-25 19:37:38', 'admin', 'admin', '2013-04-25 19:39:00', NULL, 6058);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(7174, NULL, 7165, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', NULL, 'wcmf\\lib\\presentation\\control\\lists\\impl\\FileListStrategy', NULL, NULL, 'Chi237Val', NULL, '1.0', '__class', '?', '2013-10-12 00:17:41', 'admin', 'admin', '2013-10-12 00:19:28', NULL, 7174);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(7395, NULL, 132, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', NULL, 'app/js/ui/data/input/widget/Color', '531', NULL, 'Chi238Val', NULL, '1.0', 'color', '?', '2013-11-12 17:45:51', 'admin', 'admin', '2013-11-12 18:00:33', NULL, 7395);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(7717, NULL, 15, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', NULL, '../cache/', NULL, NULL, 'Chi239Val', NULL, '1.0', 'cacheDir', '?', '2014-02-10 14:28:53', 'admin', 'admin', '2014-02-10 14:37:59', NULL, 7717);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(7721, NULL, 15, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', NULL, '{Search}', NULL, NULL, 'Chi240Val', NULL, '1.0', 'listeners', '?', '2014-02-10 14:37:39', 'admin', 'admin', '2014-02-10 14:39:04', NULL, 7721);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(7730, NULL, 27, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', NULL, '+*', NULL, NULL, 'Chi241Val', NULL, '1.0', '??fatal', '?', '2014-02-10 14:39:04', 'admin', 'admin', '2014-02-10 14:45:52', NULL, 7730);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(7736, NULL, 27, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', NULL, '+*', NULL, NULL, 'Chi242Val', NULL, '1.0', '??login', '?', '2014-02-10 14:45:33', 'admin', 'admin', '2014-02-10 14:46:30', NULL, 7736);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(7743, NULL, 27, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', NULL, '+*', NULL, NULL, 'Chi243Val', NULL, '1.0', '??logout', '?', '2014-02-10 14:46:10', 'admin', 'admin', '2014-02-10 14:46:57', NULL, 7743);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(7754, NULL, 27, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', NULL, '+*', NULL, NULL, 'Chi244Val', NULL, '1.0', '??messages', '?', '2014-02-10 14:46:54', 'admin', 'admin', '2014-02-10 14:47:47', NULL, 7754);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(7760, NULL, 27, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', NULL, '+administrators', NULL, NULL, 'Chi245Val', NULL, '1.0', '??exportAll', '?', '2014-02-10 14:47:28', 'admin', 'admin', '2014-02-10 14:48:06', NULL, 7760);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(7767, NULL, 27, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', NULL, '+administrators', NULL, NULL, 'Chi246Val', NULL, '1.0', '??indexAll', '?', '2014-02-10 14:48:00', 'admin', 'admin', '2014-02-10 14:48:47', NULL, 7767);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(7774, NULL, 27, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', NULL, '+administrators', NULL, NULL, 'Chi247Val', NULL, '1.0', 'app.src.model.wcmf.User??read', '?', '2014-02-10 14:48:49', 'admin', 'admin', '2014-02-10 14:49:50', NULL, 7774);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(7780, NULL, 27, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', NULL, '+administrators', NULL, NULL, 'Chi248Val', NULL, '1.0', 'app.src.model.wcmf.User??modify', '?', '2014-02-10 14:49:40', 'admin', 'admin', '2014-02-10 14:50:19', NULL, 7780);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(7789, NULL, 27, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', NULL, '+administrators', NULL, NULL, 'Chi249Val', NULL, '1.0', 'app.src.model.wcmf.User??delete', '?', '2014-02-10 14:50:26', 'admin', 'admin', '2014-02-10 14:51:17', NULL, 7789);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(7795, NULL, 27, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', NULL, '+administrators', NULL, NULL, 'Chi250Val', NULL, '1.0', 'app.src.model.wcmf.User??create', '?', '2014-02-10 14:50:57', 'admin', 'admin', '2014-02-10 14:51:37', NULL, 7795);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(7803, NULL, 27, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', NULL, '+administrators', NULL, NULL, 'Chi251Val', NULL, '1.0', 'app.src.model.wcmf.Role??read', '?', '2014-02-10 14:51:36', 'admin', 'admin', '2014-02-10 14:52:24', NULL, 7803);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(7808, NULL, 27, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', NULL, '+administrators', NULL, NULL, 'Chi252Val', NULL, '1.0', 'app.src.model.wcmf.Role??modify', '?', '2014-02-10 14:52:04', 'admin', 'admin', '2014-02-10 14:53:03', NULL, 7808);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(7816, NULL, 27, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', NULL, '+administrators', NULL, NULL, 'Chi253Val', NULL, '1.0', 'app.src.model.wcmf.Role??delete', '?', '2014-02-10 14:52:44', 'admin', 'admin', '2014-02-10 14:53:35', NULL, 7816);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(7823, NULL, 27, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', NULL, '+administrators', NULL, NULL, 'Chi254Val', NULL, '1.0', 'app.src.model.wcmf.Role??create', '?', '2014-02-10 14:53:15', 'admin', 'admin', '2014-02-10 14:54:26', NULL, 7823);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(7824, NULL, 27, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', NULL, '+administrators', NULL, NULL, 'Chi255Val', NULL, '1.0', 'app.src.model.wcmf.NMUserRole??read', '?', '2014-02-10 14:53:20', 'admin', 'admin', '2014-02-10 14:54:43', NULL, 7824);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(7825, NULL, 27, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', NULL, '+administrators', NULL, NULL, 'Chi256Val', NULL, '1.0', 'app.src.model.wcmf.NMUserRole??modify', '?', '2014-02-10 14:53:22', 'admin', 'admin', '2014-02-10 14:54:57', NULL, 7825);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(7845, NULL, 27, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', NULL, '+administrators', NULL, NULL, 'Chi257Val', NULL, '1.0', 'app.src.model.wcmf.NMUserRole??delete', '?', '2014-02-10 14:54:53', 'admin', 'admin', '2014-02-10 14:55:32', NULL, 7845);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(7846, NULL, 27, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', NULL, '+administrators', NULL, NULL, 'Chi258Val', NULL, '1.0', 'app.src.model.wcmf.NMUserRole??create', '?', '2014-02-10 14:54:54', 'admin', 'admin', '2014-02-10 14:55:41', NULL, 7846);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(7858, NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', NULL, '../searchIndex/', NULL, NULL, 'Chi259Val', NULL, '1.0', 'indexPath', '?', '2014-02-10 14:55:57', 'admin', 'admin', '2014-02-10 14:56:46', NULL, 7858);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(7888, NULL, 27, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', NULL, '+*', NULL, NULL, 'Chi260Val', NULL, '1.0', '??actionSet', NULL, '2014-02-24 19:04:35', 'admin', 'admin', '2014-02-24 19:05:34', NULL, 7755);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `ChiValueRef`
--

DROP TABLE IF EXISTS `ChiValueRef`;
CREATE TABLE IF NOT EXISTS `ChiValueRef` (
  `id` int(11) NOT NULL,
  `fk_chinodemanytomany_id` int(11) DEFAULT NULL,
  `fk_chivalue_id` int(11) DEFAULT NULL,
  `fk_chinode_id` int(11) DEFAULT NULL,
  `reference_type` varchar(255) DEFAULT NULL,
  `reference_value` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chinodemanytomany_id` (`fk_chinodemanytomany_id`),
  KEY `fk_chivalue_id` (`fk_chivalue_id`),
  KEY `fk_chinode_id` (`fk_chinode_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `ChiView`
--

DROP TABLE IF EXISTS `ChiView`;
CREATE TABLE IF NOT EXISTS `ChiView` (
  `id` int(11) NOT NULL,
  `fk_chinodemanytomany_id` int(11) DEFAULT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_chinode_id` int(11) DEFAULT NULL,
  `visibility` varchar(255) DEFAULT NULL,
  `isabstract` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chinodemanytomany_id` (`fk_chinodemanytomany_id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_chinode_id` (`fk_chinode_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `ChiWorker`
--

DROP TABLE IF EXISTS `ChiWorker`;
CREATE TABLE IF NOT EXISTS `ChiWorker` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `ChiWorkerExternal`
--

DROP TABLE IF EXISTS `ChiWorkerExternal`;
CREATE TABLE IF NOT EXISTS `ChiWorkerExternal` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_chiworkerexternal_id` int(11) DEFAULT NULL,
  `is_offlineuser` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_chiworkerexternal_id` (`fk_chiworkerexternal_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `ChiWorkerInternal`
--

DROP TABLE IF EXISTS `ChiWorkerInternal`;
CREATE TABLE IF NOT EXISTS `ChiWorkerInternal` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_chiworkerinternal_id` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_chiworkerinternal_id` (`fk_chiworkerinternal_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `ControlFlow`
--

DROP TABLE IF EXISTS `ControlFlow`;
CREATE TABLE IF NOT EXISTS `ControlFlow` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fk_activityfinal_id` int(11) DEFAULT NULL,
  `fk_activityinitial_id` int(11) DEFAULT NULL,
  `fk_ascontrolflowsource_id` int(11) DEFAULT NULL,
  `fk_ascontrolflowtarget_id` int(11) DEFAULT NULL,
  `fk_arcontrolflowsource_id` int(11) DEFAULT NULL,
  `fk_arcontrolflowtarget_id` int(11) DEFAULT NULL,
  `fk_adcontrolflowtarget_id` int(11) DEFAULT NULL,
  `fk_adcontrolflowsource_id` int(11) DEFAULT NULL,
  `fk_acontrolflowsource_id` int(11) DEFAULT NULL,
  `fk_acontrolflowtarget_id` int(11) DEFAULT NULL,
  `guard` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_activityfinal_id` (`fk_activityfinal_id`),
  KEY `fk_activityinitial_id` (`fk_activityinitial_id`),
  KEY `fk_ascontrolflowsource_id` (`fk_ascontrolflowsource_id`),
  KEY `fk_ascontrolflowtarget_id` (`fk_ascontrolflowtarget_id`),
  KEY `fk_arcontrolflowsource_id` (`fk_arcontrolflowsource_id`),
  KEY `fk_arcontrolflowtarget_id` (`fk_arcontrolflowtarget_id`),
  KEY `fk_adcontrolflowtarget_id` (`fk_adcontrolflowtarget_id`),
  KEY `fk_adcontrolflowsource_id` (`fk_adcontrolflowsource_id`),
  KEY `fk_acontrolflowsource_id` (`fk_acontrolflowsource_id`),
  KEY `fk_acontrolflowtarget_id` (`fk_acontrolflowtarget_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `Counter`
--

DROP TABLE IF EXISTS `Counter`;
CREATE TABLE IF NOT EXISTS `Counter` (
  `id` int(11) NOT NULL,
  `activity` varchar(255) DEFAULT NULL,
  `activitydecision` varchar(255) DEFAULT NULL,
  `activityfinal` varchar(255) DEFAULT NULL,
  `activityinitial` varchar(255) DEFAULT NULL,
  `activityreceive` varchar(255) DEFAULT NULL,
  `activitysend` varchar(255) DEFAULT NULL,
  `chibusinesspartner` varchar(255) DEFAULT NULL,
  `chibusinesspartneractive` varchar(255) DEFAULT NULL,
  `chibusinesspartnerpassive` varchar(255) DEFAULT NULL,
  `chibusinessprocess` varchar(255) DEFAULT NULL,
  `chibusinessusecase` varchar(255) DEFAULT NULL,
  `chibusinessusecasecore` varchar(255) DEFAULT NULL,
  `chicontroller` varchar(255) DEFAULT NULL,
  `chifeature` varchar(255) DEFAULT NULL,
  `chigoal` varchar(255) DEFAULT NULL,
  `chiissue` varchar(255) DEFAULT NULL,
  `chinode` varchar(255) DEFAULT NULL,
  `chirequirement` varchar(255) DEFAULT NULL,
  `chisystem` varchar(255) DEFAULT NULL,
  `chivalue` varchar(255) DEFAULT NULL,
  `chiview` varchar(255) DEFAULT NULL,
  `chiworker` varchar(255) DEFAULT NULL,
  `chiworkerexternal` varchar(255) DEFAULT NULL,
  `chiworkerinternal` varchar(255) DEFAULT NULL,
  `operation` varchar(255) DEFAULT NULL,
  `diagram` varchar(255) DEFAULT NULL,
  `activityset` varchar(255) DEFAULT NULL,
  `productionruleset` varchar(255) DEFAULT NULL,
  `productionrule` varchar(255) DEFAULT NULL,
  `rulesetvariable` varchar(255) DEFAULT NULL,
  `rulevariable` varchar(255) DEFAULT NULL,
  `rulecondition` varchar(255) DEFAULT NULL,
  `ruleaction` varchar(255) DEFAULT NULL,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `Counter`
--

INSERT INTO `Counter` (`id`, `activity`, `activitydecision`, `activityfinal`, `activityinitial`, `activityreceive`, `activitysend`, `chibusinesspartner`, `chibusinesspartneractive`, `chibusinesspartnerpassive`, `chibusinessprocess`, `chibusinessusecase`, `chibusinessusecasecore`, `chicontroller`, `chifeature`, `chigoal`, `chiissue`, `chinode`, `chirequirement`, `chisystem`, `chivalue`, `chiview`, `chiworker`, `chiworkerexternal`, `chiworkerinternal`, `operation`, `diagram`, `activityset`, `productionruleset`, `productionrule`, `rulesetvariable`, `rulevariable`, `rulecondition`, `ruleaction`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '85', NULL, NULL, NULL, '223', NULL, '122', '260', '34', NULL, NULL, NULL, NULL, '9', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'admin', '2014-02-24 19:04:36', NULL);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `dbupdate`
--

DROP TABLE IF EXISTS `dbupdate`;
CREATE TABLE IF NOT EXISTS `dbupdate` (
  `table_id` varchar(100) NOT NULL,
  `column_id` varchar(100) NOT NULL,
  `type` varchar(100) NOT NULL,
  `table` varchar(255) DEFAULT NULL,
  `column` varchar(255) DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`table_id`,`column_id`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `Diagram`
--

DROP TABLE IF EXISTS `Diagram`;
CREATE TABLE IF NOT EXISTS `Diagram` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `width` varchar(255) DEFAULT NULL,
  `height` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `Diagram`
--

INSERT INTO `Diagram` (`id`, `fk_package_id`, `width`, `height`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(586, 8, NULL, NULL, NULL, 'Chi002Dia', NULL, '1.0', 'config.ini', '?', NULL, NULL, 'admin', '2013-10-11 23:58:53', NULL, 1);
INSERT INTO `Diagram` (`id`, `fk_package_id`, `width`, `height`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(701, 263, NULL, NULL, NULL, 'Chi003Dia', NULL, '1.0', 'model', '?', NULL, NULL, 'admin', '2013-02-21 22:13:33', NULL, 1);
INSERT INTO `Diagram` (`id`, `fk_package_id`, `width`, `height`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(1708, 310, NULL, NULL, NULL, 'Chi004Dia', NULL, '1.0', 'wcmf', '?', NULL, NULL, 'admin', '2012-06-23 23:49:53', NULL, NULL);
INSERT INTO `Diagram` (`id`, `fk_package_id`, `width`, `height`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(2407, 39, NULL, NULL, NULL, 'Chi005Dia', NULL, '1.0', 'admin.ini', '?', NULL, NULL, 'admin', '2012-06-25 23:59:50', NULL, NULL);
INSERT INTO `Diagram` (`id`, `fk_package_id`, `width`, `height`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(2424, 42, NULL, NULL, NULL, 'Chi006Dia', NULL, '1.0', 'server.ini', '?', NULL, NULL, 'admin', '2012-06-25 23:59:59', NULL, NULL);
INSERT INTO `Diagram` (`id`, `fk_package_id`, `width`, `height`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(2539, 59, NULL, NULL, NULL, 'Chi007Dia', NULL, '1.0', 'persistence.ini', '?', NULL, NULL, 'admin', '2012-06-26 00:01:07', NULL, NULL);
INSERT INTO `Diagram` (`id`, `fk_package_id`, `width`, `height`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(2637, 74, NULL, NULL, NULL, 'Chi008Dia', NULL, '1.0', 'presentation.ini', '?', NULL, NULL, 'admin', '2012-06-23 01:54:02', NULL, NULL);
INSERT INTO `Diagram` (`id`, `fk_package_id`, `width`, `height`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(4733, 260, NULL, NULL, NULL, 'Chi009Dia', NULL, '1.0', 'backend', '?', '2013-02-20 13:54:43', 'admin', 'admin', '2013-02-20 13:55:14', NULL, 4733);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `DisplayType`
--

DROP TABLE IF EXISTS `DisplayType`;
CREATE TABLE IF NOT EXISTS `DisplayType` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `DisplayType`
--

INSERT INTO `DisplayType` (`id`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(1041, 'text', '?', '2012-06-19 00:41:32', 'admin', 'admin', '2012-06-19 00:41:50', NULL);
INSERT INTO `DisplayType` (`id`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(1046, 'image', '?', '2012-06-19 00:41:47', 'admin', 'admin', '2012-06-19 00:42:02', NULL);
INSERT INTO `DisplayType` (`id`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(1052, 'link', '?', '2012-06-19 00:41:56', 'admin', 'admin', '2012-06-19 00:42:20', NULL);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `Figure`
--

DROP TABLE IF EXISTS `Figure`;
CREATE TABLE IF NOT EXISTS `Figure` (
  `id` int(11) NOT NULL,
  `fk_chiobject_id` int(11) DEFAULT NULL,
  `fk_activity_id` int(11) DEFAULT NULL,
  `fk_activitydecision_id` int(11) DEFAULT NULL,
  `fk_activityreceive_id` int(11) DEFAULT NULL,
  `fk_activitysend_id` int(11) DEFAULT NULL,
  `fk_activityinitial_id` int(11) DEFAULT NULL,
  `fk_activityfinal_id` int(11) DEFAULT NULL,
  `fk_chisystem_id` int(11) DEFAULT NULL,
  `fk_productionrule_id` int(11) DEFAULT NULL,
  `fk_productionruleset_id` int(11) DEFAULT NULL,
  `fk_ruleaction_id` int(11) DEFAULT NULL,
  `fk_rulecondition_id` int(11) DEFAULT NULL,
  `fk_rulesetvariable_id` int(11) DEFAULT NULL,
  `fk_rulevariable_id` int(11) DEFAULT NULL,
  `fk_chiworkerexternal_id` int(11) DEFAULT NULL,
  `fk_chiworkerinternal_id` int(11) DEFAULT NULL,
  `fk_chiworker_id` int(11) DEFAULT NULL,
  `fk_chibusinesspartneractive_id` int(11) DEFAULT NULL,
  `fk_chibusinesspartnerpassive_id` int(11) DEFAULT NULL,
  `fk_chibusinesspartner_id` int(11) DEFAULT NULL,
  `fk_actor_id` int(11) DEFAULT NULL,
  `fk_chibusinessprocess_id` int(11) DEFAULT NULL,
  `fk_chibusinessusecasecore_id` int(11) DEFAULT NULL,
  `fk_chibusinessusecase_id` int(11) DEFAULT NULL,
  `fk_chigoal_id` int(11) DEFAULT NULL,
  `fk_chirequirement_id` int(11) DEFAULT NULL,
  `fk_chifeature_id` int(11) DEFAULT NULL,
  `fk_chiissue_id` int(11) DEFAULT NULL,
  `fk_operation_id` int(11) DEFAULT NULL,
  `fk_chinodemanytomany_id` int(11) DEFAULT NULL,
  `fk_chinode_id` int(11) DEFAULT NULL,
  `fk_chicontroller_id` int(11) DEFAULT NULL,
  `fk_chiview_id` int(11) DEFAULT NULL,
  `fk_chiclass_id` int(11) DEFAULT NULL,
  `fk_feature_id` int(11) DEFAULT NULL,
  `fk_chivalue_id` int(11) DEFAULT NULL,
  `fk_property_id` int(11) DEFAULT NULL,
  `fk_glossary_id` int(11) DEFAULT NULL,
  `fk_diagram_id` int(11) DEFAULT NULL,
  `fk_chibase_id` int(11) DEFAULT NULL,
  `fk_activityset_id` int(11) DEFAULT NULL,
  `backgroundcolor` varchar(255) DEFAULT NULL,
  `foregroundcolor` varchar(255) DEFAULT NULL,
  `gid` varchar(255) DEFAULT NULL,
  `height` varchar(255) DEFAULT NULL,
  `positionx` varchar(255) DEFAULT NULL,
  `positiony` varchar(255) DEFAULT NULL,
  `showinheritedattributes` varchar(255) DEFAULT NULL,
  `width` varchar(255) DEFAULT NULL,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chiobject_id` (`fk_chiobject_id`),
  KEY `fk_activity_id` (`fk_activity_id`),
  KEY `fk_activitydecision_id` (`fk_activitydecision_id`),
  KEY `fk_activityreceive_id` (`fk_activityreceive_id`),
  KEY `fk_activitysend_id` (`fk_activitysend_id`),
  KEY `fk_activityinitial_id` (`fk_activityinitial_id`),
  KEY `fk_activityfinal_id` (`fk_activityfinal_id`),
  KEY `fk_chisystem_id` (`fk_chisystem_id`),
  KEY `fk_productionrule_id` (`fk_productionrule_id`),
  KEY `fk_productionruleset_id` (`fk_productionruleset_id`),
  KEY `fk_ruleaction_id` (`fk_ruleaction_id`),
  KEY `fk_rulecondition_id` (`fk_rulecondition_id`),
  KEY `fk_rulesetvariable_id` (`fk_rulesetvariable_id`),
  KEY `fk_rulevariable_id` (`fk_rulevariable_id`),
  KEY `fk_chiworkerexternal_id` (`fk_chiworkerexternal_id`),
  KEY `fk_chiworkerinternal_id` (`fk_chiworkerinternal_id`),
  KEY `fk_chiworker_id` (`fk_chiworker_id`),
  KEY `fk_chibusinesspartneractive_id` (`fk_chibusinesspartneractive_id`),
  KEY `fk_chibusinesspartnerpassive_id` (`fk_chibusinesspartnerpassive_id`),
  KEY `fk_chibusinesspartner_id` (`fk_chibusinesspartner_id`),
  KEY `fk_actor_id` (`fk_actor_id`),
  KEY `fk_chibusinessprocess_id` (`fk_chibusinessprocess_id`),
  KEY `fk_chibusinessusecasecore_id` (`fk_chibusinessusecasecore_id`),
  KEY `fk_chibusinessusecase_id` (`fk_chibusinessusecase_id`),
  KEY `fk_chigoal_id` (`fk_chigoal_id`),
  KEY `fk_chirequirement_id` (`fk_chirequirement_id`),
  KEY `fk_chifeature_id` (`fk_chifeature_id`),
  KEY `fk_chiissue_id` (`fk_chiissue_id`),
  KEY `fk_operation_id` (`fk_operation_id`),
  KEY `fk_chinodemanytomany_id` (`fk_chinodemanytomany_id`),
  KEY `fk_chinode_id` (`fk_chinode_id`),
  KEY `fk_chicontroller_id` (`fk_chicontroller_id`),
  KEY `fk_chiview_id` (`fk_chiview_id`),
  KEY `fk_chiclass_id` (`fk_chiclass_id`),
  KEY `fk_feature_id` (`fk_feature_id`),
  KEY `fk_chivalue_id` (`fk_chivalue_id`),
  KEY `fk_property_id` (`fk_property_id`),
  KEY `fk_glossary_id` (`fk_glossary_id`),
  KEY `fk_diagram_id` (`fk_diagram_id`),
  KEY `fk_chibase_id` (`fk_chibase_id`),
  KEY `fk_activityset_id` (`fk_activityset_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `Figure`
--

INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(587, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 9, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 586, NULL, NULL, NULL, NULL, NULL, '50', '5024', '5023', NULL, '50', NULL, NULL, 'admin', '2012-06-23 00:48:48', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(588, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 11, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 586, NULL, NULL, NULL, NULL, NULL, '50', '5192', '5021', NULL, '50', NULL, NULL, 'admin', '2012-06-23 00:48:41', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(589, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 13, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 586, NULL, NULL, NULL, NULL, NULL, '50', '5364', '5022', NULL, '50', NULL, NULL, 'admin', '2012-05-11 08:52:06', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(590, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 14, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 586, NULL, NULL, NULL, NULL, NULL, '50', '5363', '5101', NULL, '50', NULL, NULL, 'admin', '2012-05-11 08:52:10', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(591, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 15, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 586, NULL, NULL, NULL, NULL, NULL, '197', '5024', '5234', NULL, '150', NULL, NULL, 'admin', '2014-02-24 19:05:24', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(592, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 23, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 586, NULL, NULL, NULL, NULL, NULL, '50', '5363', '5349', NULL, '50', NULL, NULL, 'admin', '2012-06-23 01:03:18', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(593, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 25, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 586, NULL, NULL, NULL, NULL, NULL, '50', '5529', '5022', NULL, '50', NULL, NULL, 'admin', '2012-06-24 02:23:58', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(594, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 27, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 586, NULL, NULL, NULL, NULL, NULL, '394', '5192', '5475', NULL, '253', NULL, NULL, 'admin', '2014-02-24 19:05:37', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(595, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 28, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 586, NULL, NULL, NULL, NULL, NULL, '131', '5528', '5187', NULL, '150', NULL, NULL, 'admin', '2014-02-24 19:05:28', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(596, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 586, NULL, NULL, NULL, NULL, NULL, '97', '5363', '5243', NULL, '150', NULL, NULL, 'admin', '2014-02-10 14:57:03', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(597, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 36, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 586, NULL, NULL, NULL, NULL, NULL, '50', '5024', '5130', NULL, '50', NULL, NULL, 'admin', '2012-06-23 00:54:30', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(702, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 701, NULL, NULL, NULL, NULL, NULL, '50', '5150', '5050', NULL, '50', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(705, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 278, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 701, NULL, NULL, NULL, NULL, NULL, '140', '5312', '4955', NULL, '150', NULL, NULL, 'admin', '2012-06-23 00:21:23', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(1709, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 311, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1708, NULL, NULL, NULL, NULL, NULL, '65', '5513', '5388', NULL, '150', NULL, NULL, 'admin', '2012-06-23 00:44:23', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(1710, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 313, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1708, NULL, NULL, NULL, NULL, NULL, '97', '5515', '5468', NULL, '150', NULL, NULL, 'admin', '2012-06-23 00:42:53', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(1711, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 317, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1708, NULL, NULL, NULL, NULL, NULL, '50', '5291', '5213', NULL, '50', NULL, NULL, 'admin', '2012-06-23 00:37:23', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(1712, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 323, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1708, NULL, NULL, NULL, NULL, NULL, '81', '5523', '5060', NULL, '150', NULL, NULL, 'admin', '2012-06-23 00:31:57', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(1713, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 326, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1708, NULL, NULL, NULL, NULL, NULL, '129', '5516', '5581', NULL, '150', NULL, NULL, 'admin', '2012-06-23 00:44:29', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(1714, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 332, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1708, NULL, NULL, NULL, NULL, NULL, '50', '5210', '5367', NULL, '50', NULL, NULL, 'admin', '2012-06-23 00:30:08', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(1715, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 337, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1708, NULL, NULL, NULL, NULL, NULL, '50', '5009', '5050', NULL, '50', NULL, NULL, 'admin', '2012-06-23 00:29:55', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(4269, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4268, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1708, NULL, NULL, NULL, NULL, NULL, '95', '5284', '5033', NULL, '96', '2012-06-26 23:29:17', 'admin', 'admin', '2012-06-26 23:29:22', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(6570, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 216, NULL, NULL, NULL, NULL, NULL, NULL, 4733, NULL, NULL, NULL, NULL, NULL, '95', '5885', '5567', NULL, '96', '2013-07-12 16:21:26', 'admin', 'admin', '2014-02-10 14:20:55', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2425, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 43, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2424, NULL, NULL, NULL, NULL, NULL, '161', '5055', '5052', NULL, '150', NULL, NULL, 'admin', '2012-06-26 00:00:16', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2426, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 49, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2424, NULL, NULL, NULL, NULL, NULL, '50', '5223', '5158', NULL, '50', NULL, NULL, 'admin', '2013-03-01 00:57:42', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2427, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 51, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2424, NULL, NULL, NULL, NULL, NULL, '50', '5222', '5054', NULL, '50', NULL, NULL, 'admin', '2012-06-23 01:20:17', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2428, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 54, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2424, NULL, NULL, NULL, NULL, NULL, '50', '5422', '5206', NULL, '50', NULL, NULL, 'admin', '2013-03-01 00:56:15', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2429, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 57, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2424, NULL, NULL, NULL, NULL, NULL, '50', '5421', '5054', NULL, '50', NULL, NULL, 'admin', '2012-06-23 01:20:35', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2430, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 58, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2424, NULL, NULL, NULL, NULL, NULL, '50', '5422', '5132', NULL, '50', NULL, NULL, 'admin', '2012-06-23 01:20:39', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2540, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 60, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2539, NULL, NULL, NULL, NULL, NULL, '50', '5034', '5034', NULL, '50', NULL, NULL, 'admin', '2012-06-23 01:25:10', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2541, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 65, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2539, NULL, NULL, NULL, NULL, NULL, '50', '5036', '5177', NULL, '50', NULL, NULL, 'admin', '2012-06-23 01:25:15', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2542, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2539, NULL, NULL, NULL, NULL, NULL, '50', '5208', '5035', NULL, '50', NULL, NULL, 'admin', '2012-06-23 01:25:19', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2543, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 69, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2539, NULL, NULL, NULL, NULL, NULL, '50', '5209', '5130', NULL, '50', NULL, NULL, 'admin', '2012-06-23 01:25:24', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2544, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 70, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2539, NULL, NULL, NULL, NULL, NULL, '50', '5210', '5209', NULL, '50', NULL, NULL, 'admin', '2012-06-23 01:25:28', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(5471, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 5470, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 586, NULL, NULL, NULL, NULL, NULL, '81', '5692', '5300', NULL, '150', '2013-02-28 18:08:00', 'admin', 'admin', '2013-10-11 23:54:40', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2638, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 75, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2637, NULL, NULL, NULL, NULL, NULL, '161', '5027', '5026', NULL, '150', NULL, NULL, 'admin', '2014-02-10 14:59:29', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2639, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 83, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2637, NULL, NULL, NULL, NULL, NULL, '50', '5029', '5216', NULL, '50', NULL, NULL, 'admin', '2012-06-23 01:32:54', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2640, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 88, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2637, NULL, NULL, NULL, NULL, NULL, '50', '5031', '5357', NULL, '50', NULL, NULL, 'admin', '2012-06-23 01:33:43', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2641, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 90, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2637, NULL, NULL, NULL, NULL, NULL, '97', '5032', '5449', NULL, '150', NULL, NULL, 'admin', '2013-04-25 19:30:51', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2642, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 92, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2637, NULL, NULL, NULL, NULL, NULL, '97', '5032', '5584', NULL, '150', NULL, NULL, 'admin', '2013-04-26 12:14:40', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2643, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 94, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2637, NULL, NULL, NULL, NULL, NULL, '50', '5032', '5719', NULL, '50', NULL, NULL, 'admin', '2013-04-26 12:15:25', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2644, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 96, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2637, NULL, NULL, NULL, NULL, NULL, '150', '5371', '5074', NULL, '150', NULL, NULL, 'admin', '2013-10-12 00:10:49', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2645, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 102, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2637, NULL, NULL, NULL, NULL, NULL, '50', '5371', '5234', NULL, '50', NULL, NULL, 'admin', '2013-10-12 00:07:12', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2646, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 104, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2637, NULL, NULL, NULL, NULL, NULL, '50', '5369', '5325', NULL, '50', NULL, NULL, 'admin', '2013-10-12 00:06:27', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2647, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 106, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2637, NULL, NULL, NULL, NULL, NULL, '50', '5369', '5418', NULL, '50', NULL, NULL, 'admin', '2013-10-12 00:05:42', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2648, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 108, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2637, NULL, NULL, NULL, NULL, NULL, '50', '5368', '5511', NULL, '50', NULL, NULL, 'admin', '2013-10-12 00:04:55', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2651, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 115, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2637, NULL, NULL, NULL, NULL, NULL, '99', '5198', '5293', NULL, '150', NULL, NULL, 'admin', '2013-11-12 17:50:22', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2656, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 132, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2637, NULL, NULL, NULL, NULL, NULL, '257', '5198', '5026', NULL, '150', NULL, NULL, 'admin', '2013-11-12 17:48:53', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(6657, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 222, NULL, NULL, NULL, NULL, NULL, NULL, 4733, NULL, NULL, NULL, NULL, NULL, '95', '5625', '5719', NULL, '96', '2013-07-12 18:11:12', 'admin', 'admin', '2014-02-10 14:20:44', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(6640, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 220, NULL, NULL, NULL, NULL, NULL, NULL, 4733, NULL, NULL, NULL, NULL, NULL, '95', '5816', '5678', NULL, '96', '2013-07-12 18:03:10', 'admin', 'admin', '2013-07-12 18:06:52', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(6637, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 219, NULL, NULL, NULL, NULL, NULL, NULL, 4733, NULL, NULL, NULL, NULL, NULL, '95', '5437', '5719', NULL, '96', '2013-07-12 18:03:01', 'admin', 'admin', '2014-02-10 14:20:19', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(6629, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 203, NULL, NULL, NULL, NULL, NULL, NULL, 4733, NULL, NULL, NULL, NULL, NULL, '95', '5211', '5720', NULL, '96', '2013-07-12 18:01:22', 'admin', 'admin', '2014-02-10 14:20:07', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(6611, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 221, NULL, NULL, NULL, NULL, NULL, NULL, 4733, NULL, NULL, NULL, NULL, NULL, '95', '5028', '5716', NULL, '96', '2013-07-12 17:59:09', 'admin', 'admin', '2014-02-10 14:20:05', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(4406, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4384, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1708, NULL, NULL, NULL, NULL, NULL, '95', '5048', '4932', NULL, '96', '2012-06-26 23:53:01', 'admin', 'admin', '2012-06-26 23:53:05', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(4412, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4398, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1708, NULL, NULL, NULL, NULL, NULL, '95', '5547', '4931', NULL, '96', '2012-06-26 23:53:08', 'admin', 'admin', '2012-06-26 23:53:25', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(4684, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4683, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2539, NULL, NULL, NULL, NULL, NULL, '97', '5036', '5276', NULL, '150', '2013-02-19 19:14:55', 'admin', 'admin', '2013-02-19 19:15:34', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(4861, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 206, NULL, NULL, NULL, NULL, NULL, NULL, 4733, NULL, NULL, NULL, NULL, NULL, '95', '5029', '5291', NULL, '96', '2013-02-20 14:55:26', 'admin', 'admin', '2014-02-10 14:23:35', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(4750, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 257, NULL, NULL, NULL, NULL, NULL, NULL, 4733, NULL, NULL, NULL, NULL, NULL, '272', '5267', '5061', NULL, '279', '2013-02-20 13:55:37', 'admin', 'admin', '2014-02-10 14:18:51', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(5367, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 5366, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 586, NULL, NULL, NULL, NULL, NULL, '81', '5193', '5218', NULL, '150', '2013-02-28 17:49:25', 'admin', 'admin', '2013-03-01 01:02:59', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(5375, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 5374, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 586, NULL, NULL, NULL, NULL, NULL, '81', '5691', '5407', NULL, '150', '2013-02-28 17:51:08', 'admin', 'admin', '2013-10-11 23:53:55', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(5403, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 5402, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 586, NULL, NULL, NULL, NULL, NULL, '81', '5192', '5111', NULL, '150', '2013-02-28 17:56:30', 'admin', 'admin', '2013-02-28 17:59:57', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(5435, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 72, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 586, NULL, NULL, NULL, NULL, NULL, '85', '5694', '5023', NULL, '150', '2013-02-28 18:02:16', 'admin', 'admin', '2013-10-11 23:57:32', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(5841, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 5840, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 586, NULL, NULL, NULL, NULL, NULL, '81', '5193', '5323', NULL, '150', '2013-03-01 16:37:44', 'admin', 'admin', '2013-03-01 16:42:30', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(5905, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 210, NULL, NULL, NULL, NULL, NULL, NULL, 4733, NULL, NULL, NULL, NULL, NULL, '95', '5027', '5045', NULL, '96', '2013-03-26 17:56:03', 'admin', 'admin', '2014-02-10 14:19:17', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(5993, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 5992, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2637, NULL, NULL, NULL, NULL, NULL, '81', '5033', '5805', NULL, '150', '2013-04-25 19:15:38', 'admin', 'admin', '2013-04-26 12:16:10', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(6050, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 6049, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2637, NULL, NULL, NULL, NULL, NULL, '81', '5033', '5907', NULL, '150', '2013-04-25 19:36:00', 'admin', 'admin', '2013-04-26 12:16:56', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(6168, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 204, NULL, NULL, NULL, NULL, NULL, NULL, 4733, NULL, NULL, NULL, NULL, NULL, '95', '5798', '5012', NULL, '96', '2013-04-26 12:53:44', 'admin', 'admin', '2014-02-10 14:19:24', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(6205, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 198, NULL, NULL, NULL, NULL, NULL, NULL, 4733, NULL, NULL, NULL, NULL, NULL, '95', '5027', '5545', NULL, '96', '2013-05-16 18:26:29', 'admin', 'admin', '2014-02-10 14:20:01', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(7871, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 223, NULL, NULL, NULL, NULL, NULL, NULL, 4733, NULL, NULL, NULL, NULL, NULL, '95', '5335', '4844', NULL, '96', '2014-02-10 15:03:28', 'admin', 'admin', '2014-02-10 15:06:15', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(6215, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 211, NULL, NULL, NULL, NULL, NULL, NULL, 4733, NULL, NULL, NULL, NULL, NULL, '95', '5321', '5577', NULL, '96', '2013-05-16 18:27:40', 'admin', 'admin', '2014-02-10 14:20:27', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(6221, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 197, NULL, NULL, NULL, NULL, NULL, NULL, 4733, NULL, NULL, NULL, NULL, NULL, '95', '5603', '5575', NULL, '96', '2013-05-16 18:29:17', 'admin', 'admin', '2014-02-10 14:20:48', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(6310, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 192, NULL, NULL, NULL, NULL, NULL, NULL, 4733, NULL, NULL, NULL, NULL, NULL, '95', '5881', '5448', NULL, '96', '2013-05-24 18:15:16', 'admin', 'admin', '2014-02-10 14:21:06', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(7096, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 7088, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 586, NULL, NULL, NULL, NULL, NULL, '81', '5695', '5153', NULL, '150', '2013-10-11 23:58:08', 'admin', 'admin', '2013-10-12 00:01:49', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(7171, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 7165, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2637, NULL, NULL, NULL, NULL, NULL, '81', '5368', '5601', NULL, '150', '2013-10-12 00:16:17', 'admin', 'admin', '2013-10-12 00:18:40', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(7501, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 196, NULL, NULL, NULL, NULL, NULL, NULL, 4733, NULL, NULL, NULL, NULL, NULL, '95', '5878', '5244', NULL, '96', '2014-02-10 14:04:42', 'admin', 'admin', '2014-02-10 14:10:01', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(7537, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 195, NULL, NULL, NULL, NULL, NULL, NULL, 4733, NULL, NULL, NULL, NULL, NULL, '95', '5877', '5141', NULL, '96', '2014-02-10 14:07:35', 'admin', 'admin', '2014-02-10 14:23:43', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(7578, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 212, NULL, NULL, NULL, NULL, NULL, NULL, 4733, NULL, NULL, NULL, NULL, NULL, '95', '5797', '4899', NULL, '96', '2014-02-10 14:10:07', 'admin', 'admin', '2014-02-10 14:23:41', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(7660, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 205, NULL, NULL, NULL, NULL, NULL, NULL, 4733, NULL, NULL, NULL, NULL, NULL, '95', '5026', '5172', NULL, '96', '2014-02-10 14:20:34', 'admin', 'admin', '2014-02-10 14:21:25', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(7679, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 232, NULL, NULL, NULL, NULL, NULL, NULL, 4733, NULL, NULL, NULL, NULL, NULL, '95', '5159', '4840', NULL, '96', '2014-02-10 14:23:46', 'admin', 'admin', '2014-02-10 14:24:40', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(7708, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 191, NULL, NULL, NULL, NULL, NULL, NULL, 4733, NULL, NULL, NULL, NULL, NULL, '95', '5549', '4784', NULL, '96', '2014-02-10 14:25:58', 'admin', 'admin', '2014-02-10 14:26:44', NULL);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `Glossary`
--

DROP TABLE IF EXISTS `Glossary`;
CREATE TABLE IF NOT EXISTS `Glossary` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `entrytype` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `History`
--

DROP TABLE IF EXISTS `History`;
CREATE TABLE IF NOT EXISTS `History` (
  `id` int(11) NOT NULL,
  `data` text,
  `duplicate` tinyint(1) DEFAULT NULL,
  `eventtype` enum('create','delete','changeProperty','associate','disassociate') DEFAULT NULL,
  `affectedoid` varchar(255) DEFAULT NULL,
  `otheroid` varchar(255) DEFAULT NULL,
  `timestamp` bigint(20) DEFAULT NULL,
  `user` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `InputType`
--

DROP TABLE IF EXISTS `InputType`;
CREATE TABLE IF NOT EXISTS `InputType` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `InputType`
--

INSERT INTO `InputType` (`id`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(1058, 'text', '?', '2012-06-19 00:42:16', 'admin', 'admin', '2012-06-19 00:48:45', NULL);
INSERT INTO `InputType` (`id`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(1064, 'checkbox', '?', '2012-06-19 00:48:43', 'admin', 'admin', '2012-06-19 00:49:01', NULL);
INSERT INTO `InputType` (`id`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(1070, 'ckeditor', '?', '2012-06-19 00:48:54', 'admin', 'admin', '2012-06-19 00:49:07', NULL);
INSERT INTO `InputType` (`id`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(1076, 'date', '?', '2012-06-19 00:49:06', 'admin', 'admin', '2012-06-19 00:49:20', NULL);
INSERT INTO `InputType` (`id`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(1082, 'filebrowser', '?', '2012-06-19 00:49:18', 'admin', 'admin', '2012-06-19 00:49:30', NULL);
INSERT INTO `InputType` (`id`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(1088, 'linkbrowser', '?', '2012-06-19 00:49:29', 'admin', 'admin', '2012-06-19 00:49:41', NULL);
INSERT INTO `InputType` (`id`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(1094, 'password', '?', '2012-06-19 00:49:40', 'admin', 'admin', '2012-06-19 00:49:52', NULL);
INSERT INTO `InputType` (`id`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(1100, 'radio', '?', '2012-06-19 00:49:51', 'admin', 'admin', '2012-06-19 00:50:08', NULL);
INSERT INTO `InputType` (`id`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(1106, 'select', '?', '2012-06-19 00:50:07', 'admin', 'admin', '2012-06-19 00:50:20', NULL);
INSERT INTO `InputType` (`id`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(1112, 'select#async', '?', '2012-06-19 00:50:18', 'admin', 'admin', '2012-06-19 00:50:31', NULL);
INSERT INTO `InputType` (`id`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(1118, 'textarea', '?', '2012-06-19 00:50:30', 'admin', 'admin', '2012-06-19 00:50:44', NULL);
INSERT INTO `InputType` (`id`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(1124, 'textile', '?', '2012-06-19 00:50:41', 'admin', 'admin', '2012-06-19 00:50:56', NULL);
INSERT INTO `InputType` (`id`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(1130, 'binarycheckbox', NULL, '2012-06-19 00:50:54', 'admin', 'admin', '2012-06-19 00:51:03', NULL);
INSERT INTO `InputType` (`id`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(6972, 'select#file:../config/|/\\..ini$/', NULL, '2013-10-11 23:22:57', 'admin', 'admin', '2013-10-11 23:23:10', NULL);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `Language`
--

DROP TABLE IF EXISTS `Language`;
CREATE TABLE IF NOT EXISTS `Language` (
  `id` int(11) NOT NULL,
  `code` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `Language`
--

INSERT INTO `Language` (`id`, `code`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(1, 'en', 'English', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Language` (`id`, `code`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2, 'de', 'Deutsch', NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `locktable`
--

DROP TABLE IF EXISTS `locktable`;
CREATE TABLE IF NOT EXISTS `locktable` (
  `id` int(11) NOT NULL,
  `fk_user_id` int(11) DEFAULT NULL,
  `objectid` varchar(255) DEFAULT NULL,
  `sessionid` varchar(255) DEFAULT NULL,
  `since` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_user_id` (`fk_user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `locktable`
--

INSERT INTO `locktable` (`id`, `fk_user_id`, `objectid`, `sessionid`, `since`) VALUES(7946, 2, 'Model:3', NULL, '2014-02-25 00:12:15');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `Model`
--

DROP TABLE IF EXISTS `Model`;
CREATE TABLE IF NOT EXISTS `Model` (
  `id` int(11) NOT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `Model`
--

INSERT INTO `Model` (`id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(3, NULL, 'wcmf test', '?', '2012-05-11 08:48:45', 'admin', 'admin', '2013-02-21 22:36:23', 3);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `NMChiControllerActionKeyChiController`
--

DROP TABLE IF EXISTS `NMChiControllerActionKeyChiController`;
CREATE TABLE IF NOT EXISTS `NMChiControllerActionKeyChiController` (
  `id` int(11) NOT NULL,
  `fk_chicontrolleractionkeysource_id` int(11) DEFAULT NULL,
  `fk_chicontrolleractionkeytarget_id` int(11) DEFAULT NULL,
  `action` varchar(255) DEFAULT NULL,
  `config` varchar(255) DEFAULT NULL,
  `context` varchar(255) DEFAULT NULL,
  `sourcename` varchar(255) DEFAULT NULL,
  `sourcemultiplicity` varchar(255) DEFAULT NULL,
  `sourcenavigability` varchar(255) DEFAULT NULL,
  `targetname` varchar(255) DEFAULT NULL,
  `targetmultiplicity` varchar(255) DEFAULT NULL,
  `targetnavigability` varchar(255) DEFAULT NULL,
  `relationtype` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chicontrolleractionkeysource_id` (`fk_chicontrolleractionkeysource_id`),
  KEY `fk_chicontrolleractionkeytarget_id` (`fk_chicontrolleractionkeytarget_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `NMChiControllerActionKeyChiController`
--

INSERT INTO `NMChiControllerActionKeyChiController` (`id`, `fk_chicontrolleractionkeysource_id`, `fk_chicontrolleractionkeytarget_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(4901, 206, 206, 'failure', 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'association', 'failure', '?', '2013-02-20 14:57:34', 'admin', 'admin', '2013-02-20 14:57:59', NULL);
INSERT INTO `NMChiControllerActionKeyChiController` (`id`, `fk_chicontrolleractionkeysource_id`, `fk_chicontrolleractionkeytarget_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(4873, 257, 206, 'logout', 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'association', 'logout', '?', '2013-02-20 14:55:52', 'admin', 'admin', '2013-02-20 14:56:42', NULL);
INSERT INTO `NMChiControllerActionKeyChiController` (`id`, `fk_chicontrolleractionkeysource_id`, `fk_chicontrolleractionkeytarget_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(4866, 257, 206, 'login', 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'association', 'login', '?', '2013-02-20 14:55:35', 'admin', 'admin', '2013-02-20 14:55:52', NULL);
INSERT INTO `NMChiControllerActionKeyChiController` (`id`, `fk_chicontrolleractionkeysource_id`, `fk_chicontrolleractionkeytarget_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(5912, 257, 210, 'restAction', 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'association', 'restAction', '?', '2013-03-26 17:57:37', 'admin', 'admin', '2013-03-26 17:58:22', NULL);
INSERT INTO `NMChiControllerActionKeyChiController` (`id`, `fk_chicontrolleractionkeysource_id`, `fk_chicontrolleractionkeytarget_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(6173, 257, 204, 'list', 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'association', 'list', '?', '2013-04-26 12:54:42', 'admin', 'admin', '2013-04-26 12:56:15', NULL);
INSERT INTO `NMChiControllerActionKeyChiController` (`id`, `fk_chicontrolleractionkeysource_id`, `fk_chicontrolleractionkeytarget_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(6251, 257, 198, 'read', 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'association', 'read', '?', '2013-05-16 18:35:51', 'admin', 'admin', '2013-05-16 18:36:55', NULL);
INSERT INTO `NMChiControllerActionKeyChiController` (`id`, `fk_chicontrolleractionkeysource_id`, `fk_chicontrolleractionkeytarget_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(7000, 257, 211, 'create', 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'association', 'create', '?', '2013-10-11 23:46:25', 'admin', 'admin', '2013-10-11 23:48:01', NULL);
INSERT INTO `NMChiControllerActionKeyChiController` (`id`, `fk_chicontrolleractionkeysource_id`, `fk_chicontrolleractionkeytarget_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(6270, 257, 211, 'update', 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'association', 'update', '?', '2013-05-16 18:38:53', 'admin', 'admin', '2013-05-16 18:39:39', NULL);
INSERT INTO `NMChiControllerActionKeyChiController` (`id`, `fk_chicontrolleractionkeysource_id`, `fk_chicontrolleractionkeytarget_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(6277, 257, 197, 'delete', 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'association', 'delete', '?', '2013-05-16 18:39:30', 'admin', 'admin', '2013-05-16 18:40:04', NULL);
INSERT INTO `NMChiControllerActionKeyChiController` (`id`, `fk_chicontrolleractionkeysource_id`, `fk_chicontrolleractionkeytarget_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(6314, 257, 192, 'associate', 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'association', 'associate', '?', '2013-05-24 18:16:05', 'admin', 'admin', '2013-05-24 18:17:29', NULL);
INSERT INTO `NMChiControllerActionKeyChiController` (`id`, `fk_chicontrolleractionkeysource_id`, `fk_chicontrolleractionkeytarget_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(6322, 257, 192, 'disassociate', 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'association', 'disassociate', '?', '2013-05-24 18:17:20', 'admin', 'admin', '2013-05-24 18:18:28', NULL);
INSERT INTO `NMChiControllerActionKeyChiController` (`id`, `fk_chicontrolleractionkeysource_id`, `fk_chicontrolleractionkeytarget_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(6576, 257, 216, 'insertBefore', 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'association', 'insertBefore', '?', '2013-07-12 16:23:04', 'admin', 'admin', '2013-07-12 17:39:05', NULL);
INSERT INTO `NMChiControllerActionKeyChiController` (`id`, `fk_chicontrolleractionkeysource_id`, `fk_chicontrolleractionkeytarget_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(6599, 257, 216, 'moveBefore', 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'association', 'moveBefore', '?', '2013-07-12 17:38:56', 'admin', 'admin', '2013-07-12 17:58:39', NULL);
INSERT INTO `NMChiControllerActionKeyChiController` (`id`, `fk_chicontrolleractionkeysource_id`, `fk_chicontrolleractionkeytarget_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(6614, 257, 221, 'listValues', 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'association', 'listValues', '?', '2013-07-12 18:00:38', 'admin', 'admin', '2013-07-12 18:33:35', NULL);
INSERT INTO `NMChiControllerActionKeyChiController` (`id`, `fk_chicontrolleractionkeysource_id`, `fk_chicontrolleractionkeytarget_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(6647, 257, 203, 'browseMedia', 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'association', 'browseMedia', '?', '2013-07-12 18:05:29', 'admin', 'admin', '2013-07-12 18:33:57', NULL);
INSERT INTO `NMChiControllerActionKeyChiController` (`id`, `fk_chicontrolleractionkeysource_id`, `fk_chicontrolleractionkeytarget_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(6648, 257, 219, 'browseTree', 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'association', 'browseTree', '?', '2013-07-12 18:05:32', 'admin', 'admin', '2013-07-12 18:34:17', NULL);
INSERT INTO `NMChiControllerActionKeyChiController` (`id`, `fk_chicontrolleractionkeysource_id`, `fk_chicontrolleractionkeytarget_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(6818, 257, 220, 'changePassword', 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'association', 'changePassword', '?', '2013-07-12 18:47:38', 'admin', 'admin', '2013-07-12 18:56:06', NULL);
INSERT INTO `NMChiControllerActionKeyChiController` (`id`, `fk_chicontrolleractionkeysource_id`, `fk_chicontrolleractionkeytarget_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(6816, 257, 222, 'messages', 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'association', 'messages', '?', '2013-07-12 18:47:27', 'admin', 'admin', '2013-07-12 18:55:47', NULL);
INSERT INTO `NMChiControllerActionKeyChiController` (`id`, `fk_chicontrolleractionkeysource_id`, `fk_chicontrolleractionkeytarget_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(7505, 257, 196, 'move', 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'association', 'move', '?', '2014-02-10 14:05:00', 'admin', 'admin', '2014-02-10 14:06:03', NULL);
INSERT INTO `NMChiControllerActionKeyChiController` (`id`, `fk_chicontrolleractionkeysource_id`, `fk_chicontrolleractionkeytarget_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(7512, 257, 196, 'copy', 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'association', 'copy', '?', '2014-02-10 14:05:42', 'admin', 'admin', '2014-02-10 14:06:39', NULL);
INSERT INTO `NMChiControllerActionKeyChiController` (`id`, `fk_chicontrolleractionkeysource_id`, `fk_chicontrolleractionkeytarget_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(7529, 196, 196, 'continue', 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'association', 'continue', '?', '2014-02-10 14:06:49', 'admin', 'admin', '2014-02-10 14:07:40', NULL);
INSERT INTO `NMChiControllerActionKeyChiController` (`id`, `fk_chicontrolleractionkeysource_id`, `fk_chicontrolleractionkeytarget_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(7542, 257, 195, 'lock', 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'association', 'lock', '?', '2014-02-10 14:07:47', 'admin', 'admin', '2014-02-10 14:08:33', NULL);
INSERT INTO `NMChiControllerActionKeyChiController` (`id`, `fk_chicontrolleractionkeysource_id`, `fk_chicontrolleractionkeytarget_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(7549, 257, 195, 'unlock', 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'association', 'unlock', '?', '2014-02-10 14:08:28', 'admin', 'admin', '2014-02-10 14:09:07', NULL);
INSERT INTO `NMChiControllerActionKeyChiController` (`id`, `fk_chicontrolleractionkeysource_id`, `fk_chicontrolleractionkeytarget_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(7582, 257, 212, 'search', 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'association', 'search', '?', '2014-02-10 14:10:19', 'admin', 'admin', '2014-02-10 14:16:26', NULL);
INSERT INTO `NMChiControllerActionKeyChiController` (`id`, `fk_chicontrolleractionkeysource_id`, `fk_chicontrolleractionkeytarget_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(7670, 257, 205, 'log', 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'association', 'log', NULL, '2014-02-10 14:20:52', 'admin', 'admin', '2014-02-10 14:21:11', NULL);
INSERT INTO `NMChiControllerActionKeyChiController` (`id`, `fk_chicontrolleractionkeysource_id`, `fk_chicontrolleractionkeytarget_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(7686, 257, 232, 'indexAll', 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'association', 'indexAll', '?', '2014-02-10 14:24:05', 'admin', 'admin', '2014-02-10 14:24:52', NULL);
INSERT INTO `NMChiControllerActionKeyChiController` (`id`, `fk_chicontrolleractionkeysource_id`, `fk_chicontrolleractionkeytarget_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(7691, 232, 232, 'continue', 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'association', 'continue', '?', '2014-02-10 14:24:39', 'admin', 'admin', '2014-02-10 14:25:12', NULL);
INSERT INTO `NMChiControllerActionKeyChiController` (`id`, `fk_chicontrolleractionkeysource_id`, `fk_chicontrolleractionkeytarget_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(7875, 223, 223, 'continue', 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'association', 'continue', NULL, '2014-02-10 15:04:21', 'admin', 'admin', '2014-02-10 15:04:41', NULL);
INSERT INTO `NMChiControllerActionKeyChiController` (`id`, `fk_chicontrolleractionkeysource_id`, `fk_chicontrolleractionkeytarget_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(7712, 257, 191, 'actionSet', 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'association', 'actionSet', '?', '2014-02-10 14:26:12', 'admin', 'admin', '2014-02-10 14:26:46', NULL);
INSERT INTO `NMChiControllerActionKeyChiController` (`id`, `fk_chicontrolleractionkeysource_id`, `fk_chicontrolleractionkeytarget_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(7881, 257, 223, 'exportAll', 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'association', 'exportAll', '?', '2014-02-10 15:05:41', 'admin', 'admin', '2014-02-10 15:10:27', NULL);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `NMChiControllerActionKeyChiView`
--

DROP TABLE IF EXISTS `NMChiControllerActionKeyChiView`;
CREATE TABLE IF NOT EXISTS `NMChiControllerActionKeyChiView` (
  `id` int(11) NOT NULL,
  `fk_chiview_id` int(11) DEFAULT NULL,
  `fk_chicontroller_id` int(11) DEFAULT NULL,
  `action` varchar(255) DEFAULT NULL,
  `config` varchar(255) DEFAULT NULL,
  `context` varchar(255) DEFAULT NULL,
  `sourcename` varchar(255) DEFAULT NULL,
  `sourcemultiplicity` varchar(255) DEFAULT NULL,
  `sourcenavigability` varchar(255) DEFAULT NULL,
  `targetname` varchar(255) DEFAULT NULL,
  `targetmultiplicity` varchar(255) DEFAULT NULL,
  `targetnavigability` varchar(255) DEFAULT NULL,
  `relationtype` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chiview_id` (`fk_chiview_id`),
  KEY `fk_chicontroller_id` (`fk_chicontroller_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `NMChiControllerChiController`
--

DROP TABLE IF EXISTS `NMChiControllerChiController`;
CREATE TABLE IF NOT EXISTS `NMChiControllerChiController` (
  `id` int(11) NOT NULL,
  `fk_chicontrollersource_id` int(11) DEFAULT NULL,
  `fk_chicontrollertarget_id` int(11) DEFAULT NULL,
  `sourcename` varchar(255) DEFAULT NULL,
  `sourcemultiplicity` varchar(255) DEFAULT NULL,
  `sourcenavigability` varchar(255) DEFAULT NULL,
  `targetname` varchar(255) DEFAULT NULL,
  `targetmultiplicity` varchar(255) DEFAULT NULL,
  `targetnavigability` varchar(255) DEFAULT NULL,
  `relationtype` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chicontrollersource_id` (`fk_chicontrollersource_id`),
  KEY `fk_chicontrollertarget_id` (`fk_chicontrollertarget_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `NMChiNodeChiMany2Many`
--

DROP TABLE IF EXISTS `NMChiNodeChiMany2Many`;
CREATE TABLE IF NOT EXISTS `NMChiNodeChiMany2Many` (
  `id` int(11) NOT NULL,
  `fk_chinode_id` int(11) DEFAULT NULL,
  `fk_chinodemanytomany_id` int(11) DEFAULT NULL,
  `sourcename` varchar(255) DEFAULT NULL,
  `sourcemultiplicity` varchar(255) DEFAULT NULL,
  `sourcenavigability` varchar(255) DEFAULT NULL,
  `targetname` varchar(255) DEFAULT NULL,
  `targetmultiplicity` varchar(255) DEFAULT NULL,
  `targetnavigability` varchar(255) DEFAULT NULL,
  `relationtype` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `fk_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chinode_id` (`fk_chinode_id`),
  KEY `fk_chinodemanytomany_id` (`fk_chinodemanytomany_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `NMChiNodeChiMany2Many`
--

INSERT INTO `NMChiNodeChiMany2Many` (`id`, `fk_chinode_id`, `fk_chinodemanytomany_id`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `fk_name`) VALUES(4281, 323, 4268, NULL, '513', 'Navigable', NULL, '522', 'Navigable', 'composition', 'Composition', '?', '2012-06-26 23:30:10', 'admin', 'admin', '2012-06-26 23:31:43', NULL, 'fk_role_id');
INSERT INTO `NMChiNodeChiMany2Many` (`id`, `fk_chinode_id`, `fk_chinodemanytomany_id`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `fk_name`) VALUES(4287, 337, 4268, NULL, '513', 'Navigable', NULL, '522', 'Navigable', 'composition', 'Composition', '?', '2012-06-26 23:30:48', 'admin', 'admin', '2012-06-26 23:31:29', NULL, 'fk_user_id');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `NMChiUseCaseChiUseCase`
--

DROP TABLE IF EXISTS `NMChiUseCaseChiUseCase`;
CREATE TABLE IF NOT EXISTS `NMChiUseCaseChiUseCase` (
  `id` int(11) NOT NULL,
  `fk_chiusecasecoresource_id` int(11) DEFAULT NULL,
  `fk_chiusecasecoretarget_id` int(11) DEFAULT NULL,
  `fk_chiusecasetarget_id` int(11) DEFAULT NULL,
  `fk_chiusecasesource_id` int(11) DEFAULT NULL,
  `sourcename` varchar(255) DEFAULT NULL,
  `sourcemultiplicity` varchar(255) DEFAULT NULL,
  `sourcenavigability` varchar(255) DEFAULT NULL,
  `targetname` varchar(255) DEFAULT NULL,
  `targetmultiplicity` varchar(255) DEFAULT NULL,
  `targetnavigability` varchar(255) DEFAULT NULL,
  `relationtype` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chiusecasecoresource_id` (`fk_chiusecasecoresource_id`),
  KEY `fk_chiusecasecoretarget_id` (`fk_chiusecasecoretarget_id`),
  KEY `fk_chiusecasetarget_id` (`fk_chiusecasetarget_id`),
  KEY `fk_chiusecasesource_id` (`fk_chiusecasesource_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `NMFeatureRequirements`
--

DROP TABLE IF EXISTS `NMFeatureRequirements`;
CREATE TABLE IF NOT EXISTS `NMFeatureRequirements` (
  `id` int(11) NOT NULL,
  `fk_chifeature_id` int(11) DEFAULT NULL,
  `fk_chirequirement_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chifeature_id` (`fk_chifeature_id`),
  KEY `fk_chirequirement_id` (`fk_chirequirement_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `NMFiguresDiagram`
--

DROP TABLE IF EXISTS `NMFiguresDiagram`;
CREATE TABLE IF NOT EXISTS `NMFiguresDiagram` (
  `id` int(11) NOT NULL,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `NMUCActor`
--

DROP TABLE IF EXISTS `NMUCActor`;
CREATE TABLE IF NOT EXISTS `NMUCActor` (
  `id` int(11) NOT NULL,
  `fk_chiworkerexternal_id` int(11) DEFAULT NULL,
  `fk_chiworkerinternal_id` int(11) DEFAULT NULL,
  `fk_chiworker_id` int(11) DEFAULT NULL,
  `fk_chibusinesspartneractive_id` int(11) DEFAULT NULL,
  `fk_chibusinesspartnerpassive_id` int(11) DEFAULT NULL,
  `fk_chibusinesspartner_id` int(11) DEFAULT NULL,
  `fk_chibusinessusecasecore_id` int(11) DEFAULT NULL,
  `fk_chibusinessusecase_id` int(11) DEFAULT NULL,
  `fk_actor_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chiworkerexternal_id` (`fk_chiworkerexternal_id`),
  KEY `fk_chiworkerinternal_id` (`fk_chiworkerinternal_id`),
  KEY `fk_chiworker_id` (`fk_chiworker_id`),
  KEY `fk_chibusinesspartneractive_id` (`fk_chibusinesspartneractive_id`),
  KEY `fk_chibusinesspartnerpassive_id` (`fk_chibusinesspartnerpassive_id`),
  KEY `fk_chibusinesspartner_id` (`fk_chibusinesspartner_id`),
  KEY `fk_chibusinessusecasecore_id` (`fk_chibusinessusecasecore_id`),
  KEY `fk_chibusinessusecase_id` (`fk_chibusinessusecase_id`),
  KEY `fk_actor_id` (`fk_actor_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `nm_user_role`
--

DROP TABLE IF EXISTS `nm_user_role`;
CREATE TABLE IF NOT EXISTS `nm_user_role` (
  `fk_user_id` int(11) NOT NULL DEFAULT '0',
  `fk_role_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`fk_user_id`,`fk_role_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `nm_user_role`
--

INSERT INTO `nm_user_role` (`fk_user_id`, `fk_role_id`) VALUES(2, 1);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `ObjectFlow`
--

DROP TABLE IF EXISTS `ObjectFlow`;
CREATE TABLE IF NOT EXISTS `ObjectFlow` (
  `id` int(11) NOT NULL,
  `fk_aobjectflowtarget_id` int(11) DEFAULT NULL,
  `fk_aobjectflowsource_id` int(11) DEFAULT NULL,
  `fk_chiobjectobjectflowsource_id` int(11) DEFAULT NULL,
  `fk_chiobjectobjectflowtarget_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_aobjectflowtarget_id` (`fk_aobjectflowtarget_id`),
  KEY `fk_aobjectflowsource_id` (`fk_aobjectflowsource_id`),
  KEY `fk_chiobjectobjectflowsource_id` (`fk_chiobjectobjectflowsource_id`),
  KEY `fk_chiobjectobjectflowtarget_id` (`fk_chiobjectobjectflowtarget_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `Operation`
--

DROP TABLE IF EXISTS `Operation`;
CREATE TABLE IF NOT EXISTS `Operation` (
  `id` int(11) NOT NULL,
  `fk_chinodemanytomany_id` int(11) DEFAULT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_chicontroller_id` int(11) DEFAULT NULL,
  `fk_chinode_id` int(11) DEFAULT NULL,
  `parameters` varchar(255) DEFAULT NULL,
  `returntype` varchar(255) DEFAULT NULL,
  `visibility` varchar(255) DEFAULT NULL,
  `isabstract` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chinodemanytomany_id` (`fk_chinodemanytomany_id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_chicontroller_id` (`fk_chicontroller_id`),
  KEY `fk_chinode_id` (`fk_chinode_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `Package`
--

DROP TABLE IF EXISTS `Package`;
CREATE TABLE IF NOT EXISTS `Package` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_model_id` int(11) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_model_id` (`fk_model_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `Package`
--

INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(4, NULL, 3, NULL, 'PrimitiveTypes', '?', '2012-05-11 08:48:45', 'admin', 'admin', '2012-06-20 23:39:57', 4);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(5, NULL, 3, NULL, 'root', '?', '2012-05-11 08:48:45', 'admin', 'admin', '2013-02-19 15:45:27', 5);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(6, 5, NULL, NULL, 'configuration', NULL, '2012-05-11 08:48:45', 'admin', 'admin', '2012-05-11 08:49:36', 6);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(7, 6, NULL, NULL, 'default', NULL, '2012-05-11 08:48:46', 'admin', 'admin', '2012-05-11 08:49:36', 7);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(8, 7, NULL, NULL, 'config.ini', NULL, '2012-05-11 08:48:46', 'admin', 'admin', '2012-05-11 08:49:36', 8);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(39, 7, NULL, NULL, 'admin.ini', '?', '2012-05-11 08:48:50', 'admin', 'admin', '2012-06-23 01:04:36', 39);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(42, 7, NULL, NULL, 'server.ini', '?', '2012-05-11 08:48:50', 'admin', 'admin', '2012-06-23 01:20:08', 42);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(59, 7, NULL, NULL, 'persistence.ini', '?', '2012-05-11 08:48:53', 'admin', 'admin', '2012-06-23 01:25:09', 59);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(74, 7, NULL, NULL, 'presentation.ini', '?', '2012-05-11 08:48:55', 'admin', 'admin', '2012-06-23 01:31:29', 74);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(188, 5, NULL, NULL, 'wcmf', NULL, '2012-05-11 08:49:13', 'admin', 'admin', '2012-05-11 08:50:27', 188);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(189, 188, NULL, NULL, 'application', NULL, '2012-05-11 08:49:13', 'admin', 'admin', '2012-05-11 08:50:28', 189);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(190, 189, NULL, NULL, 'controller', '?', '2012-05-11 08:49:14', 'admin', 'admin', '2013-07-12 18:51:14', 190);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(224, 190, NULL, NULL, 'admintool', NULL, '2012-05-11 08:49:18', 'admin', 'admin', '2013-07-12 18:51:51', 32);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(253, 188, NULL, NULL, 'lib', NULL, '2012-05-11 08:49:22', 'admin', 'admin', '2012-05-11 08:50:49', 253);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(254, 253, NULL, NULL, 'model', NULL, '2012-05-11 08:49:22', 'admin', 'admin', '2012-05-11 08:50:49', 254);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(256, 253, NULL, NULL, 'presentation', NULL, '2012-05-11 08:49:22', 'admin', 'admin', '2012-05-11 08:50:50', 256);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(258, 253, NULL, NULL, 'security', '?', '2012-05-11 08:49:22', 'admin', 'admin', '2012-06-26 23:52:10', 258);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(259, 5, NULL, NULL, 'app', '?', '2012-05-11 08:49:22', 'admin', 'admin', '2013-10-27 19:27:43', 259);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(260, 259, NULL, NULL, 'src', '?', '2012-05-11 08:49:22', 'admin', 'admin', '2013-10-27 19:28:02', 260);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(261, 260, NULL, NULL, 'controller', NULL, '2012-05-11 08:49:23', 'admin', 'admin', '2012-05-11 08:50:51', 261);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(262, 260, NULL, NULL, 'views', NULL, '2012-05-11 08:49:23', 'admin', 'admin', '2012-05-11 08:50:51', 262);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(263, 260, NULL, NULL, 'model', '?', '2012-05-11 08:49:23', 'admin', 'admin', '2012-06-19 00:15:39', 263);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(310, 263, NULL, NULL, 'wcmf', '?', '2012-05-11 08:49:30', 'admin', 'admin', '2013-02-21 22:13:33', 8);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(5636, 258, NULL, NULL, 'principal', '?', '2013-03-01 15:56:32', 'admin', 'admin', '2013-03-01 15:57:20', 1);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(5641, 5636, NULL, NULL, 'impl', '?', '2013-03-01 15:57:05', 'admin', 'admin', '2013-03-01 15:58:59', 5641);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `ProductionRule`
--

DROP TABLE IF EXISTS `ProductionRule`;
CREATE TABLE IF NOT EXISTS `ProductionRule` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_productionruleset_id` int(11) DEFAULT NULL,
  `priority` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_productionruleset_id` (`fk_productionruleset_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `ProductionRuleSet`
--

DROP TABLE IF EXISTS `ProductionRuleSet`;
CREATE TABLE IF NOT EXISTS `ProductionRuleSet` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_activityset_id` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_activityset_id` (`fk_activityset_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `Property`
--

DROP TABLE IF EXISTS `Property`;
CREATE TABLE IF NOT EXISTS `Property` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_chicontroller_id` int(11) DEFAULT NULL,
  `fk_chisystem_id` int(11) DEFAULT NULL,
  `default` varchar(255) DEFAULT NULL,
  `propertytype` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_chicontroller_id` (`fk_chicontroller_id`),
  KEY `fk_chisystem_id` (`fk_chisystem_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `Relation`
--

DROP TABLE IF EXISTS `Relation`;
CREATE TABLE IF NOT EXISTS `Relation` (
  `id` int(11) NOT NULL,
  `sourcename` varchar(255) DEFAULT NULL,
  `sourcemultiplicity` varchar(255) DEFAULT NULL,
  `sourcenavigability` varchar(255) DEFAULT NULL,
  `targetname` varchar(255) DEFAULT NULL,
  `targetmultiplicity` varchar(255) DEFAULT NULL,
  `targetnavigability` varchar(255) DEFAULT NULL,
  `relationtype` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `RelationMultiplicity`
--

DROP TABLE IF EXISTS `RelationMultiplicity`;
CREATE TABLE IF NOT EXISTS `RelationMultiplicity` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `RelationMultiplicity`
--

INSERT INTO `RelationMultiplicity` (`id`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(513, '1', NULL, '2012-05-11 08:50:52', 'admin', 'admin', '2012-05-11 08:50:52', NULL);
INSERT INTO `RelationMultiplicity` (`id`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(514, '1..*', NULL, '2012-05-11 08:50:52', 'admin', 'admin', '2012-05-11 08:50:52', NULL);
INSERT INTO `RelationMultiplicity` (`id`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(522, '*', NULL, '2012-05-11 08:50:55', 'admin', 'admin', '2012-05-11 08:50:55', NULL);
INSERT INTO `RelationMultiplicity` (`id`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(542, '0..1', NULL, '2012-05-11 08:51:02', 'admin', 'admin', '2012-05-11 08:51:02', NULL);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `RelationType`
--

DROP TABLE IF EXISTS `RelationType`;
CREATE TABLE IF NOT EXISTS `RelationType` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `role`
--

DROP TABLE IF EXISTS `role`;
CREATE TABLE IF NOT EXISTS `role` (
  `id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `role`
--

INSERT INTO `role` (`id`, `name`) VALUES(1, 'administrators');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `RuleAction`
--

DROP TABLE IF EXISTS `RuleAction`;
CREATE TABLE IF NOT EXISTS `RuleAction` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_productionrule_id` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_productionrule_id` (`fk_productionrule_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `RuleCondition`
--

DROP TABLE IF EXISTS `RuleCondition`;
CREATE TABLE IF NOT EXISTS `RuleCondition` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_productionrule_id` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_productionrule_id` (`fk_productionrule_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `RuleSetVariable`
--

DROP TABLE IF EXISTS `RuleSetVariable`;
CREATE TABLE IF NOT EXISTS `RuleSetVariable` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_productionruleset_id` int(11) DEFAULT NULL,
  `context` varchar(255) DEFAULT NULL,
  `rulevalue` varchar(255) DEFAULT NULL,
  `variabletype` varchar(255) DEFAULT NULL,
  `iseditable` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_productionruleset_id` (`fk_productionruleset_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `RuleVariable`
--

DROP TABLE IF EXISTS `RuleVariable`;
CREATE TABLE IF NOT EXISTS `RuleVariable` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_productionrule_id` int(11) DEFAULT NULL,
  `context` varchar(255) DEFAULT NULL,
  `rulevalue` varchar(255) DEFAULT NULL,
  `variabletype` varchar(255) DEFAULT NULL,
  `iseditable` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_productionrule_id` (`fk_productionrule_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `Translation`
--

DROP TABLE IF EXISTS `Translation`;
CREATE TABLE IF NOT EXISTS `Translation` (
  `id` int(11) NOT NULL,
  `objectid` varchar(255) DEFAULT NULL,
  `attribute` varchar(255) DEFAULT NULL,
  `translation` text,
  `language` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL,
  `login` varchar(50) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `firstname` varchar(50) DEFAULT NULL,
  `config` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `user`
--

INSERT INTO `user` (`id`, `login`, `password`, `name`, `firstname`, `config`) VALUES(2, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'Administrator', NULL, 'admin.ini');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `user_config`
--

DROP TABLE IF EXISTS `user_config`;
CREATE TABLE IF NOT EXISTS `user_config` (
  `id` int(11) NOT NULL,
  `fk_user_id` int(11) DEFAULT NULL,
  `key` varchar(255) DEFAULT NULL,
  `val` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_user_id` (`fk_user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `user_config`
--

INSERT INTO `user_config` (`id`, `fk_user_id`, `key`, `val`) VALUES(1, 2, 'last_browser_model', 'Model:3');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `Visibility`
--

DROP TABLE IF EXISTS `Visibility`;
CREATE TABLE IF NOT EXISTS `Visibility` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `Visibility`
--

INSERT INTO `Visibility` (`id`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(511, 'public', NULL, '2012-05-11 08:50:49', 'admin', 'admin', '2012-05-11 08:50:49', NULL);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
