-- phpMyAdmin SQL Dump
-- version 3.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 22, 2013 at 12:20 AM
-- Server version: 5.5.25a
-- PHP Version: 5.4.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `cwm`
--

-- --------------------------------------------------------

--
-- Table structure for table `Activity`
--

DROP TABLE IF EXISTS `Activity`;
CREATE TABLE IF NOT EXISTS `Activity` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_productionruleset_id` int(11) DEFAULT NULL,
  `fk_activityset_id` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_productionruleset_id` (`fk_productionruleset_id`),
  KEY `fk_activityset_id` (`fk_activityset_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ActivityDecision`
--

DROP TABLE IF EXISTS `ActivityDecision`;
CREATE TABLE IF NOT EXISTS `ActivityDecision` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_productionruleset_id` int(11) DEFAULT NULL,
  `fk_activityset_id` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_productionruleset_id` (`fk_productionruleset_id`),
  KEY `fk_activityset_id` (`fk_activityset_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ActivityFinal`
--

DROP TABLE IF EXISTS `ActivityFinal`;
CREATE TABLE IF NOT EXISTS `ActivityFinal` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_productionruleset_id` int(11) DEFAULT NULL,
  `fk_activityset_id` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_productionruleset_id` (`fk_productionruleset_id`),
  KEY `fk_activityset_id` (`fk_activityset_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ActivityInitial`
--

DROP TABLE IF EXISTS `ActivityInitial`;
CREATE TABLE IF NOT EXISTS `ActivityInitial` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_productionruleset_id` int(11) DEFAULT NULL,
  `fk_activityset_id` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_productionruleset_id` (`fk_productionruleset_id`),
  KEY `fk_activityset_id` (`fk_activityset_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ActivityReceive`
--

DROP TABLE IF EXISTS `ActivityReceive`;
CREATE TABLE IF NOT EXISTS `ActivityReceive` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_productionruleset_id` int(11) DEFAULT NULL,
  `fk_activityset_id` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_productionruleset_id` (`fk_productionruleset_id`),
  KEY `fk_activityset_id` (`fk_activityset_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ActivitySend`
--

DROP TABLE IF EXISTS `ActivitySend`;
CREATE TABLE IF NOT EXISTS `ActivitySend` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_productionruleset_id` int(11) DEFAULT NULL,
  `fk_activityset_id` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_productionruleset_id` (`fk_productionruleset_id`),
  KEY `fk_activityset_id` (`fk_activityset_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ActivitySet`
--

DROP TABLE IF EXISTS `ActivitySet`;
CREATE TABLE IF NOT EXISTS `ActivitySet` (
  `id` int(11) NOT NULL,
  `fk_chibusinessusecasecore_id` int(11) DEFAULT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_chibusinessusecase_id` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chibusinessusecasecore_id` (`fk_chibusinessusecasecore_id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_chibusinessusecase_id` (`fk_chibusinessusecase_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Actor`
--

DROP TABLE IF EXISTS `Actor`;
CREATE TABLE IF NOT EXISTS `Actor` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `adodbseq`
--

DROP TABLE IF EXISTS `adodbseq`;
CREATE TABLE IF NOT EXISTS `adodbseq` (
  `id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adodbseq`
--

INSERT INTO `adodbseq` (`id`) VALUES(5324);

-- --------------------------------------------------------

--
-- Table structure for table `ChiActionKey`
--

DROP TABLE IF EXISTS `ChiActionKey`;
CREATE TABLE IF NOT EXISTS `ChiActionKey` (
  `id` int(11) NOT NULL,
  `action` varchar(255) DEFAULT NULL,
  `config` varchar(255) DEFAULT NULL,
  `context` varchar(255) DEFAULT NULL,
  `sourcename` varchar(255) DEFAULT NULL,
  `sourcemultiplicity` varchar(255) DEFAULT NULL,
  `sourcenavigability` varchar(255) DEFAULT NULL,
  `targetname` varchar(255) DEFAULT NULL,
  `targetmultiplicity` varchar(255) DEFAULT NULL,
  `targetnavigability` varchar(255) DEFAULT NULL,
  `relationtype` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ChiAssociation`
--

DROP TABLE IF EXISTS `ChiAssociation`;
CREATE TABLE IF NOT EXISTS `ChiAssociation` (
  `id` int(11) NOT NULL,
  `fk_chinodetarget_id` int(11) DEFAULT NULL,
  `fk_chinodesource_id` int(11) DEFAULT NULL,
  `fk_chinodemanytomanytarget_id` int(11) DEFAULT NULL,
  `fk_chinodemanytomanysource_id` int(11) DEFAULT NULL,
  `fk_name` varchar(255) DEFAULT NULL,
  `sourcename` varchar(255) DEFAULT NULL,
  `sourcemultiplicity` varchar(255) DEFAULT NULL,
  `sourcenavigability` varchar(255) DEFAULT NULL,
  `targetname` varchar(255) DEFAULT NULL,
  `targetmultiplicity` varchar(255) DEFAULT NULL,
  `targetnavigability` varchar(255) DEFAULT NULL,
  `relationtype` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chinodetarget_id` (`fk_chinodetarget_id`),
  KEY `fk_chinodesource_id` (`fk_chinodesource_id`),
  KEY `fk_chinodemanytomanytarget_id` (`fk_chinodemanytomanytarget_id`),
  KEY `fk_chinodemanytomanysource_id` (`fk_chinodemanytomanysource_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ChiAssociation`
--

INSERT INTO `ChiAssociation` (`id`, `fk_chinodetarget_id`, `fk_chinodesource_id`, `fk_chinodemanytomanytarget_id`, `fk_chinodemanytomanysource_id`, `fk_name`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(512, 278, 264, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'generalization', NULL, '?', '2012-05-11 08:50:52', 'admin', 'admin', '2012-06-23 00:14:22', NULL);
INSERT INTO `ChiAssociation` (`id`, `fk_chinodetarget_id`, `fk_chinodesource_id`, `fk_chinodemanytomanytarget_id`, `fk_chinodemanytomanysource_id`, `fk_name`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(5257, 292, 271, NULL, NULL, NULL, NULL, '513', 'Navigable', NULL, '522', 'Navigable', 'aggregation', 'Aggregation', '?', '2013-02-21 23:10:43', 'admin', 'admin', '2013-02-21 23:39:57', NULL);
INSERT INTO `ChiAssociation` (`id`, `fk_chinodetarget_id`, `fk_chinodesource_id`, `fk_chinodemanytomanytarget_id`, `fk_chinodemanytomanysource_id`, `fk_name`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(521, 278, 271, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'generalization', NULL, NULL, '2012-05-11 08:50:55', 'admin', 'admin', '2012-05-11 08:50:55', NULL);
INSERT INTO `ChiAssociation` (`id`, `fk_chinodetarget_id`, `fk_chinodesource_id`, `fk_chinodemanytomanytarget_id`, `fk_chinodemanytomanysource_id`, `fk_name`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(529, 255, 278, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'generalization', NULL, '?', '2012-05-11 08:50:57', 'admin', 'admin', '2012-06-24 00:16:32', NULL);
INSERT INTO `ChiAssociation` (`id`, `fk_chinodetarget_id`, `fk_chinodesource_id`, `fk_chinodemanytomanytarget_id`, `fk_chinodemanytomanysource_id`, `fk_name`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(534, 278, 284, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'generalization', NULL, NULL, '2012-05-11 08:50:59', 'admin', 'admin', '2012-05-11 08:50:59', NULL);
INSERT INTO `ChiAssociation` (`id`, `fk_chinodetarget_id`, `fk_chinodesource_id`, `fk_chinodemanytomanytarget_id`, `fk_chinodemanytomanysource_id`, `fk_name`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(540, 278, 292, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'generalization', NULL, NULL, '2012-05-11 08:51:02', 'admin', 'admin', '2012-05-11 08:51:02', NULL);
INSERT INTO `ChiAssociation` (`id`, `fk_chinodetarget_id`, `fk_chinodesource_id`, `fk_chinodemanytomanytarget_id`, `fk_chinodemanytomanysource_id`, `fk_name`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(541, 292, 292, NULL, NULL, 'fk_chapter_id', 'ParentChapter', '513', 'Navigable', 'SubChapter', '522', 'Navigable', 'composition', NULL, '?', '2012-05-11 08:51:02', 'admin', 'admin', '2013-02-22 00:16:27', NULL);
INSERT INTO `ChiAssociation` (`id`, `fk_chinodetarget_id`, `fk_chinodesource_id`, `fk_chinodemanytomanytarget_id`, `fk_chinodemanytomanysource_id`, `fk_name`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(543, 284, 292, NULL, NULL, 'fk_titlechapter_id', 'TitleChapter', '513', 'Navigable', 'TitleImage', '542', 'Navigable', 'aggregation', NULL, '?', '2012-05-11 08:51:02', 'admin', 'admin', '2013-02-22 00:03:41', NULL);
INSERT INTO `ChiAssociation` (`id`, `fk_chinodetarget_id`, `fk_chinodesource_id`, `fk_chinodemanytomanytarget_id`, `fk_chinodemanytomanysource_id`, `fk_name`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(544, 284, 292, NULL, NULL, 'fk_chapter_id', 'NormalChapter', '513', 'Navigable', 'NormalImage', '522', 'Navigable', 'aggregation', NULL, '?', '2012-05-11 08:51:02', 'admin', 'admin', '2013-02-22 00:03:57', NULL);
INSERT INTO `ChiAssociation` (`id`, `fk_chinodetarget_id`, `fk_chinodesource_id`, `fk_chinodemanytomanytarget_id`, `fk_chinodemanytomanysource_id`, `fk_name`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(558, 255, 311, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'generalization', NULL, NULL, '2012-05-11 08:51:08', 'admin', 'admin', '2012-05-11 08:51:08', NULL);
INSERT INTO `ChiAssociation` (`id`, `fk_chinodetarget_id`, `fk_chinodesource_id`, `fk_chinodemanytomanytarget_id`, `fk_chinodemanytomanysource_id`, `fk_name`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(559, 255, 313, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'generalization', NULL, NULL, '2012-05-11 08:51:10', 'admin', 'admin', '2012-05-11 08:51:10', NULL);
INSERT INTO `ChiAssociation` (`id`, `fk_chinodetarget_id`, `fk_chinodesource_id`, `fk_chinodemanytomanytarget_id`, `fk_chinodemanytomanysource_id`, `fk_name`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(562, 255, 317, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'generalization', NULL, NULL, '2012-05-11 08:51:11', 'admin', 'admin', '2012-05-11 08:51:11', NULL);
INSERT INTO `ChiAssociation` (`id`, `fk_chinodetarget_id`, `fk_chinodesource_id`, `fk_chinodemanytomanytarget_id`, `fk_chinodemanytomanysource_id`, `fk_name`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(4418, 4398, 323, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'generalization', 'Generalization', NULL, '2012-06-26 23:53:22', 'admin', 'admin', '2012-06-26 23:53:23', NULL);
INSERT INTO `ChiAssociation` (`id`, `fk_chinodetarget_id`, `fk_chinodesource_id`, `fk_chinodemanytomanytarget_id`, `fk_chinodemanytomanysource_id`, `fk_name`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(568, 255, 326, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'generalization', NULL, NULL, '2012-05-11 08:51:13', 'admin', 'admin', '2012-05-11 08:51:13', NULL);
INSERT INTO `ChiAssociation` (`id`, `fk_chinodetarget_id`, `fk_chinodesource_id`, `fk_chinodemanytomanytarget_id`, `fk_chinodemanytomanysource_id`, `fk_name`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(573, 255, 332, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'generalization', NULL, NULL, '2012-05-11 08:51:15', 'admin', 'admin', '2012-05-11 08:51:15', NULL);
INSERT INTO `ChiAssociation` (`id`, `fk_chinodetarget_id`, `fk_chinodesource_id`, `fk_chinodemanytomanytarget_id`, `fk_chinodemanytomanysource_id`, `fk_name`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(576, 317, 337, NULL, NULL, 'fk_user_id', NULL, '513', 'Navigable', NULL, '522', 'Navigable', 'composition', NULL, '?', '2012-05-11 08:51:17', 'admin', 'admin', '2012-06-23 00:37:23', NULL);
INSERT INTO `ChiAssociation` (`id`, `fk_chinodetarget_id`, `fk_chinodesource_id`, `fk_chinodemanytomanytarget_id`, `fk_chinodemanytomanysource_id`, `fk_name`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(4416, 4384, 337, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'generalization', 'Generalization', NULL, '2012-06-26 23:53:15', 'admin', 'admin', '2012-06-26 23:53:15', NULL);
INSERT INTO `ChiAssociation` (`id`, `fk_chinodetarget_id`, `fk_chinodesource_id`, `fk_chinodemanytomanytarget_id`, `fk_chinodemanytomanysource_id`, `fk_name`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(578, 332, 337, NULL, NULL, 'fk_user_id', NULL, '513', 'Navigable', NULL, '522', 'Navigable', 'composition', NULL, '?', '2012-05-11 08:51:17', 'admin', 'admin', '2012-06-23 00:37:36', NULL);
INSERT INTO `ChiAssociation` (`id`, `fk_chinodetarget_id`, `fk_chinodesource_id`, `fk_chinodemanytomanytarget_id`, `fk_chinodemanytomanysource_id`, `fk_name`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(3558, 255, 337, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'generalization', 'Generalization', NULL, '2012-06-23 23:50:08', 'admin', 'admin', '2012-06-23 23:50:09', NULL);
INSERT INTO `ChiAssociation` (`id`, `fk_chinodetarget_id`, `fk_chinodesource_id`, `fk_chinodemanytomanytarget_id`, `fk_chinodemanytomanysource_id`, `fk_name`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(3562, 255, 323, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'generalization', 'Generalization', NULL, '2012-06-23 23:50:31', 'admin', 'admin', '2012-06-23 23:50:31', NULL);
INSERT INTO `ChiAssociation` (`id`, `fk_chinodetarget_id`, `fk_chinodesource_id`, `fk_chinodemanytomanytarget_id`, `fk_chinodemanytomanysource_id`, `fk_name`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(5255, 292, 264, NULL, NULL, NULL, NULL, '513', 'Navigable', NULL, '522', 'Navigable', 'composition', 'Composition', '?', '2013-02-21 23:10:33', 'admin', 'admin', '2013-02-21 23:12:30', NULL);
INSERT INTO `ChiAssociation` (`id`, `fk_chinodetarget_id`, `fk_chinodesource_id`, `fk_chinodemanytomanytarget_id`, `fk_chinodemanytomanysource_id`, `fk_name`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(5157, 278, 5113, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'generalization', 'Generalization', NULL, '2013-02-21 22:11:00', 'admin', 'admin', '2013-02-21 22:11:35', NULL);
INSERT INTO `ChiAssociation` (`id`, `fk_chinodetarget_id`, `fk_chinodesource_id`, `fk_chinodemanytomanytarget_id`, `fk_chinodemanytomanysource_id`, `fk_name`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(5228, 271, 5113, NULL, NULL, NULL, NULL, '513', 'Navigable', NULL, '514', 'Navigable', 'composition', 'Composition', '?', '2013-02-21 23:07:57', 'admin', 'admin', '2013-02-21 23:10:16', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ChiAuthors`
--

DROP TABLE IF EXISTS `ChiAuthors`;
CREATE TABLE IF NOT EXISTS `ChiAuthors` (
  `id` int(11) NOT NULL,
  `role` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ChiBaseStatus`
--

DROP TABLE IF EXISTS `ChiBaseStatus`;
CREATE TABLE IF NOT EXISTS `ChiBaseStatus` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ChiBusinessPartner`
--

DROP TABLE IF EXISTS `ChiBusinessPartner`;
CREATE TABLE IF NOT EXISTS `ChiBusinessPartner` (
  `id` int(11) NOT NULL,
  `fk_chibusinesspartneractive_id` int(11) DEFAULT NULL,
  `fk_chibusinesspartnerpassive_id` int(11) DEFAULT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_chibusinesspartner_id` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chibusinesspartneractive_id` (`fk_chibusinesspartneractive_id`),
  KEY `fk_chibusinesspartnerpassive_id` (`fk_chibusinesspartnerpassive_id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_chibusinesspartner_id` (`fk_chibusinesspartner_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ChiBusinessPartnerActive`
--

DROP TABLE IF EXISTS `ChiBusinessPartnerActive`;
CREATE TABLE IF NOT EXISTS `ChiBusinessPartnerActive` (
  `id` int(11) NOT NULL,
  `fk_chibusinesspartnerpassive_id` int(11) DEFAULT NULL,
  `fk_chibusinesspartner_id` int(11) DEFAULT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_chibusinesspartneractive_id` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chibusinesspartnerpassive_id` (`fk_chibusinesspartnerpassive_id`),
  KEY `fk_chibusinesspartner_id` (`fk_chibusinesspartner_id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_chibusinesspartneractive_id` (`fk_chibusinesspartneractive_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ChiBusinessPartnerPassive`
--

DROP TABLE IF EXISTS `ChiBusinessPartnerPassive`;
CREATE TABLE IF NOT EXISTS `ChiBusinessPartnerPassive` (
  `id` int(11) NOT NULL,
  `fk_chibusinesspartneractive_id` int(11) DEFAULT NULL,
  `fk_chibusinesspartner_id` int(11) DEFAULT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_chibusinesspartnerpassive_id` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chibusinesspartneractive_id` (`fk_chibusinesspartneractive_id`),
  KEY `fk_chibusinesspartner_id` (`fk_chibusinesspartner_id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_chibusinesspartnerpassive_id` (`fk_chibusinesspartnerpassive_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ChiBusinessProcess`
--

DROP TABLE IF EXISTS `ChiBusinessProcess`;
CREATE TABLE IF NOT EXISTS `ChiBusinessProcess` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ChiBusinessUseCase`
--

DROP TABLE IF EXISTS `ChiBusinessUseCase`;
CREATE TABLE IF NOT EXISTS `ChiBusinessUseCase` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_chifeature_id` int(11) DEFAULT NULL,
  `fk_chibusinessprocess_id` int(11) DEFAULT NULL,
  `primaryactor` varchar(255) DEFAULT NULL,
  `otheractors` varchar(255) DEFAULT NULL,
  `goalincontext` varchar(255) DEFAULT NULL,
  `scope` varchar(255) DEFAULT NULL,
  `level` varchar(255) DEFAULT NULL,
  `stakeholders` varchar(255) DEFAULT NULL,
  `precondition` varchar(255) DEFAULT NULL,
  `trigger` varchar(255) DEFAULT NULL,
  `mainsuccessscenario` varchar(255) DEFAULT NULL,
  `extensions` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_chifeature_id` (`fk_chifeature_id`),
  KEY `fk_chibusinessprocess_id` (`fk_chibusinessprocess_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ChiBusinessUseCaseCore`
--

DROP TABLE IF EXISTS `ChiBusinessUseCaseCore`;
CREATE TABLE IF NOT EXISTS `ChiBusinessUseCaseCore` (
  `id` int(11) NOT NULL,
  `fk_chibusinessprocess_id` int(11) DEFAULT NULL,
  `fk_chifeature_id` int(11) DEFAULT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `primaryactor` varchar(255) DEFAULT NULL,
  `otheractors` varchar(255) DEFAULT NULL,
  `goalincontext` varchar(255) DEFAULT NULL,
  `scope` varchar(255) DEFAULT NULL,
  `level` varchar(255) DEFAULT NULL,
  `stakeholders` varchar(255) DEFAULT NULL,
  `precondition` varchar(255) DEFAULT NULL,
  `trigger` varchar(255) DEFAULT NULL,
  `mainsuccessscenario` varchar(255) DEFAULT NULL,
  `extensions` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chibusinessprocess_id` (`fk_chibusinessprocess_id`),
  KEY `fk_chifeature_id` (`fk_chifeature_id`),
  KEY `fk_package_id` (`fk_package_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ChiClass`
--

DROP TABLE IF EXISTS `ChiClass`;
CREATE TABLE IF NOT EXISTS `ChiClass` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `visibility` varchar(255) DEFAULT NULL,
  `isabstract` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ChiController`
--

DROP TABLE IF EXISTS `ChiController`;
CREATE TABLE IF NOT EXISTS `ChiController` (
  `id` int(11) NOT NULL,
  `fk_chibusinessusecasecore_id` int(11) DEFAULT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_chibusinessusecase_id` int(11) DEFAULT NULL,
  `visibility` varchar(255) DEFAULT NULL,
  `isabstract` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chibusinessusecasecore_id` (`fk_chibusinessusecasecore_id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_chibusinessusecase_id` (`fk_chibusinessusecase_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ChiController`
--

INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(191, NULL, 190, NULL, NULL, 'false', '350', 'Chi043Contr', '349', 'null', 'ActionSetController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:28', NULL, 191);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(192, NULL, 190, NULL, NULL, 'false', '350', 'Chi044Contr', '349', 'null', 'AssociateController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:29', NULL, 192);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(193, NULL, 190, NULL, NULL, 'false', '350', 'Chi045Contr', '349', 'null', 'BatchController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:29', NULL, 193);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(194, NULL, 190, NULL, NULL, 'false', '350', 'Chi046Contr', '349', 'null', 'BatchDisplayController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:29', NULL, 194);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(195, NULL, 190, NULL, NULL, 'false', '350', 'Chi047Contr', '349', 'null', 'ConcurrencyController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:30', NULL, 195);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(196, NULL, 190, NULL, NULL, 'false', '350', 'Chi048Contr', '349', 'null', 'CopyController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:30', NULL, 196);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(197, NULL, 190, NULL, NULL, 'false', '350', 'Chi049Contr', '349', 'null', 'DeleteController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:31', NULL, 197);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(198, NULL, 190, NULL, NULL, 'false', '350', 'Chi050Contr', '349', 'null', 'DisplayController', '?', 'null', 'null', 'admin', '2013-02-20 14:49:13', NULL, 198);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(199, NULL, 190, NULL, NULL, 'false', '350', 'Chi051Contr', '349', 'null', 'ElFinderController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:32', NULL, 199);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(200, NULL, 190, NULL, NULL, 'false', '350', 'Chi052Contr', '349', 'null', 'ExitController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:32', NULL, 200);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(201, NULL, 190, NULL, NULL, 'false', '350', 'Chi053Contr', '349', 'null', 'FailureController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:32', NULL, 201);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(202, NULL, 190, NULL, NULL, 'false', '350', 'Chi054Contr', '349', 'null', 'InsertController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:33', NULL, 202);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(203, NULL, 190, NULL, NULL, 'false', '350', 'Chi055Contr', '349', 'null', 'ListboxController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:33', NULL, 203);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(204, NULL, 190, NULL, NULL, 'false', '350', 'Chi056Contr', '349', 'null', 'ListController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:33', NULL, 204);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(205, NULL, 190, NULL, NULL, 'false', '350', 'Chi057Contr', '349', 'null', 'LoggingController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:34', NULL, 205);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(206, NULL, 190, NULL, NULL, 'false', '350', 'Chi058Contr', '349', 'null', 'LoginController', '?', 'null', 'null', 'admin', '2013-02-20 14:55:38', NULL, 206);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(207, NULL, 190, NULL, NULL, 'false', '350', 'Chi059Contr', '349', 'null', 'LongTaskController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:34', NULL, 207);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(208, NULL, 190, NULL, NULL, 'false', '350', 'Chi060Contr', '349', 'null', 'PageExportController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:35', NULL, 208);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(209, NULL, 190, NULL, NULL, 'false', '350', 'Chi061Contr', '349', 'null', 'ResourceTreeController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:35', NULL, 209);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(210, NULL, 190, NULL, NULL, 'false', '350', 'Chi062Contr', '349', 'null', 'RESTController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:35', NULL, 210);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(211, NULL, 190, NULL, NULL, 'false', '350', 'Chi063Contr', '349', 'null', 'SaveController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:36', NULL, 211);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(212, NULL, 190, NULL, NULL, 'false', '350', 'Chi064Contr', '349', 'null', 'SearchController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:36', NULL, 212);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(213, NULL, 190, NULL, NULL, 'false', '350', 'Chi065Contr', '349', 'null', 'SimpleBatchController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:37', NULL, 213);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(214, NULL, 190, NULL, NULL, 'false', '350', 'Chi066Contr', '349', 'null', 'SimpleLongTaskController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:37', NULL, 214);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(215, NULL, 190, NULL, NULL, 'false', '350', 'Chi067Contr', '349', 'null', 'SOAPController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:37', NULL, 215);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(216, NULL, 190, NULL, NULL, 'false', '350', 'Chi068Contr', '349', 'null', 'SortController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:38', NULL, 216);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(217, NULL, 190, NULL, NULL, 'false', '350', 'Chi069Contr', '349', 'null', 'TerminateController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:38', NULL, 217);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(218, NULL, 190, NULL, NULL, 'false', '350', 'Chi070Contr', '349', 'null', 'TextilePreviewController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:39', NULL, 218);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(219, NULL, 190, NULL, NULL, 'false', '350', 'Chi071Contr', '349', 'null', 'TreeViewController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:39', NULL, 219);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(220, NULL, 190, NULL, NULL, 'false', '350', 'Chi072Contr', '349', 'null', 'UserController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:40', NULL, 220);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(221, NULL, 190, NULL, NULL, 'false', '350', 'Chi073Contr', '349', 'null', 'ViewController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:40', NULL, 221);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(222, NULL, 190, NULL, NULL, 'false', '350', 'Chi074Contr', '349', 'null', 'WCMFFrontendController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:40', NULL, 222);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(223, NULL, 190, NULL, NULL, 'false', '350', 'Chi075Contr', '349', 'null', 'XMLExportController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:41', NULL, 223);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(225, NULL, 224, NULL, NULL, 'false', '350', 'Chi076Contr', '349', 'null', 'AdminController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:41', NULL, 225);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(226, NULL, 224, NULL, NULL, 'false', '350', 'Chi077Contr', '349', 'null', 'BackupController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:42', NULL, 226);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(227, NULL, 224, NULL, NULL, 'false', '350', 'Chi078Contr', '349', 'null', 'ConfigController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:42', NULL, 227);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(228, NULL, 224, NULL, NULL, 'false', '350', 'Chi079Contr', '349', 'null', 'CreateInstanceController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:43', NULL, 228);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(229, NULL, 224, NULL, NULL, 'false', '350', 'Chi080Contr', '349', 'null', 'EditRightsController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:43', NULL, 229);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(230, NULL, 224, NULL, NULL, 'false', '350', 'Chi081Contr', '349', 'null', 'MySQLBackupController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:43', NULL, 230);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(231, NULL, 224, NULL, NULL, 'false', '350', 'Chi082Contr', '349', 'null', 'PrincipalController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:44', NULL, 231);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(232, NULL, 224, NULL, NULL, 'false', '350', 'Chi083Contr', '349', 'null', 'SearchIndexController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:44', NULL, 232);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(257, NULL, 256, NULL, NULL, 'false', '350', 'Chi084Contr', '349', 'null', 'Controller', '?', 'null', 'null', 'admin', '2012-06-26 23:52:37', NULL, 257);

-- --------------------------------------------------------

--
-- Table structure for table `ChiFeature`
--

DROP TABLE IF EXISTS `ChiFeature`;
CREATE TABLE IF NOT EXISTS `ChiFeature` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `proofreader` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ChiFeatureStatus`
--

DROP TABLE IF EXISTS `ChiFeatureStatus`;
CREATE TABLE IF NOT EXISTS `ChiFeatureStatus` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ChiGoal`
--

DROP TABLE IF EXISTS `ChiGoal`;
CREATE TABLE IF NOT EXISTS `ChiGoal` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_chigoal_id` int(11) DEFAULT NULL,
  `goaltype` varchar(255) DEFAULT NULL,
  `priority` varchar(255) DEFAULT NULL,
  `value_ammount` varchar(255) DEFAULT NULL,
  `value_goal` varchar(255) DEFAULT NULL,
  `value_name` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_chigoal_id` (`fk_chigoal_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ChiGoalType`
--

DROP TABLE IF EXISTS `ChiGoalType`;
CREATE TABLE IF NOT EXISTS `ChiGoalType` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ChiIssue`
--

DROP TABLE IF EXISTS `ChiIssue`;
CREATE TABLE IF NOT EXISTS `ChiIssue` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_chirequirement_id` int(11) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `responsible` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_chirequirement_id` (`fk_chirequirement_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ChiNode`
--

DROP TABLE IF EXISTS `ChiNode`;
CREATE TABLE IF NOT EXISTS `ChiNode` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_chicontroller_id` int(11) DEFAULT NULL,
  `display_value` varchar(255) DEFAULT NULL,
  `table_name` varchar(255) DEFAULT NULL,
  `is_ordered` varchar(255) DEFAULT NULL,
  `parent_order` varchar(255) DEFAULT NULL,
  `child_order` varchar(255) DEFAULT NULL,
  `pk_name` varchar(255) DEFAULT NULL,
  `is_searchable` varchar(255) DEFAULT NULL,
  `orderby` varchar(255) DEFAULT NULL,
  `is_soap` varchar(255) DEFAULT NULL,
  `initparams` varchar(255) DEFAULT NULL,
  `visibility` varchar(255) DEFAULT NULL,
  `isabstract` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_chicontroller_id` (`fk_chicontroller_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ChiNode`
--

INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(255, 254, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'false', 'none', 'false', 'database', '511', 'true', NULL, 'Chi040Nod', NULL, '1.0', 'Node', '?', '2012-05-11 08:49:22', 'admin', 'admin', '2012-06-23 23:49:00', NULL, 255);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(264, 263, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'name', 'true', 'database', '511', 'false', NULL, 'Chi041Nod', NULL, '1.0', 'Author', '?', '2012-05-11 08:49:23', 'admin', 'admin', '2013-02-21 22:13:33', NULL, 3);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(271, 263, NULL, 'title', NULL, NULL, NULL, NULL, NULL, 'true', 'title DESC', 'true', 'database', '511', 'false', NULL, 'Chi042Nod', NULL, '1.0', 'Book', 'A book is published by a publisher and consists of chapters.', '2012-05-11 08:49:24', 'admin', 'admin', '2013-02-21 22:13:33', NULL, 4);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(278, 263, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'false', 'none', 'false', 'database', '511', 'true', NULL, 'Chi043Nod', NULL, '1.0', 'EntityBase', '?', '2012-05-11 08:49:25', 'admin', 'admin', '2013-02-21 22:13:33', NULL, 9);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(284, 263, NULL, 'filename', NULL, NULL, NULL, NULL, NULL, 'true', 'sortkey', 'true', 'database', '511', 'false', NULL, 'Chi044Nod', NULL, '1.0', 'Image', '?', '2012-05-11 08:49:26', 'admin', 'admin', '2013-02-21 22:13:33', NULL, 6);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(292, 263, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'sortkey', 'true', 'database', '511', 'false', NULL, 'Chi045Nod', NULL, '1.0', 'Chapter', 'A book is divided into chapters. A chapter may contain subchapters.', '2012-05-11 08:49:27', 'admin', 'admin', '2013-02-21 22:13:33', NULL, 5);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(311, 310, NULL, NULL, 'dbsequence', NULL, NULL, NULL, NULL, 'false', 'none', 'false', 'database', '511', 'false', NULL, 'Chi046Nod', NULL, '1.0', 'DBSequence', '?', '2012-05-11 08:49:30', 'admin', 'admin', '2013-02-21 22:39:01', NULL, 311);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(313, 310, NULL, 'name', 'language', NULL, NULL, NULL, NULL, 'false', 'name', 'false', 'database', '511', 'false', NULL, 'Chi047Nod', NULL, '1.0', 'Language', 'A llanguage for which a translation of the model can be created. The code is arbitrary but it is recommended to use the ISO language codes (en, de, it, ...).', '2012-05-11 08:49:30', 'admin', 'admin', '2012-05-11 08:51:09', NULL, 313);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(317, 310, NULL, NULL, 'locktable', NULL, NULL, NULL, NULL, 'false', 'none', 'false', 'database', '511', 'false', NULL, 'Chi048Nod', NULL, '1.0', 'Locktable', '?', '2012-05-11 08:49:30', 'admin', 'admin', '2012-06-23 00:37:59', NULL, 317);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(323, 310, NULL, 'name', 'role', NULL, NULL, NULL, NULL, 'false', 'name', 'false', 'database', '511', 'false', NULL, 'Chi049Nod', NULL, '1.0', 'RoleRDB', '?', '2012-05-11 08:49:31', 'admin', 'admin', '2012-06-23 00:26:03', NULL, 323);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(326, 310, NULL, 'objectid|attribute|language', 'translation', NULL, NULL, NULL, NULL, 'false', 'none', 'false', 'database', '511', 'false', NULL, 'Chi050Nod', NULL, '1.0', 'Translation', 'Instances of this class are used to localize entity attributes. Each instance defines a translation of one attribute of one entity into one language.', '2012-05-11 08:49:32', 'admin', 'admin', '2012-05-11 08:51:13', NULL, 326);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(332, 310, NULL, 'key', 'user_config', NULL, NULL, NULL, NULL, 'false', 'none', 'false', 'database', '511', 'false', NULL, 'Chi051Nod', NULL, '1.0', 'UserConfig', '?', '2012-05-11 08:49:33', 'admin', 'admin', '2012-06-23 00:40:08', NULL, 332);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(337, 310, NULL, 'login', 'user', NULL, NULL, NULL, NULL, 'false', 'name', 'false', 'database', '511', 'false', NULL, 'Chi052Nod', NULL, '1.0', 'UserRDB', '?', '2012-05-11 08:49:33', 'admin', 'admin', '2012-06-23 00:34:01', NULL, 337);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(530, 4, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi182Nod', NULL, '1.0', 'Date', '?', '2012-05-11 08:50:57', 'admin', 'admin', '2013-02-20 00:36:44', NULL, 530);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(531, 4, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi183Nod', NULL, '1.0', 'String', NULL, '2012-05-11 08:50:57', 'admin', 'admin', '2012-05-11 08:50:57', NULL, 531);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(4384, 258, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'false', 'none', NULL, 'database', NULL, 'false', NULL, 'Chi220Nod', NULL, '1.0', 'User', '?', '2012-06-26 23:51:50', 'admin', 'admin', '2012-06-26 23:52:28', NULL, 4384);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(4398, 258, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'false', 'none', NULL, 'database', NULL, 'false', NULL, 'Chi221Nod', NULL, '1.0', 'Role', '?', '2012-06-26 23:52:41', 'admin', 'admin', '2012-06-26 23:53:03', NULL, 4398);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(3476, 4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi219Nod', NULL, '1.0', 'Boolean', '?', '2012-06-23 02:18:19', 'admin', 'admin', '2012-06-23 02:18:54', NULL, 3476);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(3463, 4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi218Nod', NULL, '1.0', 'Integer', '?', '2012-06-23 02:17:25', 'admin', 'admin', '2012-06-23 02:18:00', NULL, 3463);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(5113, 263, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'name', NULL, 'database', NULL, 'false', NULL, 'Chi222Nod', NULL, '1.0', 'Publisher', '?A publisher publishes books.', '2013-02-21 21:50:53', 'admin', 'admin', '2013-02-21 22:13:33', NULL, 2);

-- --------------------------------------------------------

--
-- Table structure for table `ChiNodeManyToMany`
--

DROP TABLE IF EXISTS `ChiNodeManyToMany`;
CREATE TABLE IF NOT EXISTS `ChiNodeManyToMany` (
  `id` int(11) NOT NULL,
  `fk_chicontroller_id` int(11) DEFAULT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `display_value` varchar(255) DEFAULT NULL,
  `table_name` varchar(255) DEFAULT NULL,
  `is_ordered` varchar(255) DEFAULT NULL,
  `parent_order` varchar(255) DEFAULT NULL,
  `child_order` varchar(255) DEFAULT NULL,
  `pk_name` varchar(255) DEFAULT NULL,
  `is_searchable` varchar(255) DEFAULT NULL,
  `orderby` varchar(255) DEFAULT NULL,
  `is_soap` varchar(255) DEFAULT NULL,
  `initparams` varchar(255) DEFAULT NULL,
  `visibility` varchar(255) DEFAULT NULL,
  `isabstract` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chicontroller_id` (`fk_chicontroller_id`),
  KEY `fk_package_id` (`fk_package_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ChiNodeManyToMany`
--

INSERT INTO `ChiNodeManyToMany` (`id`, `fk_chicontroller_id`, `fk_package_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(4437, NULL, 263, NULL, NULL, NULL, NULL, NULL, NULL, 'false', 'sortkey', NULL, 'database', NULL, 'false', NULL, 'Chi001', NULL, '1.0', 'NMPublisherAuthor', '?', '2012-06-27 00:01:50', 'admin', 'admin', '2013-02-21 22:17:03', NULL, 7);
INSERT INTO `ChiNodeManyToMany` (`id`, `fk_chicontroller_id`, `fk_package_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(4268, NULL, 310, NULL, 'nm_user_role', NULL, NULL, NULL, 'fk_user_id|fk_role_id', 'false', 'none', NULL, 'database', NULL, 'false', NULL, 'Chi001', NULL, '1.0', 'NMUserRole', '?', '2012-06-26 23:29:14', 'admin', 'admin', '2012-06-26 23:30:11', NULL, 4268);

-- --------------------------------------------------------

--
-- Table structure for table `ChiObject`
--

DROP TABLE IF EXISTS `ChiObject`;
CREATE TABLE IF NOT EXISTS `ChiObject` (
  `id` int(11) NOT NULL,
  `fk_chinodemanytomany_id` int(11) DEFAULT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_chinode_id` int(11) DEFAULT NULL,
  `fk_productionruleset_id` int(11) DEFAULT NULL,
  `fk_activityset_id` int(11) DEFAULT NULL,
  `object_status` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chinodemanytomany_id` (`fk_chinodemanytomany_id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_chinode_id` (`fk_chinode_id`),
  KEY `fk_productionruleset_id` (`fk_productionruleset_id`),
  KEY `fk_activityset_id` (`fk_activityset_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ChiRequirement`
--

DROP TABLE IF EXISTS `ChiRequirement`;
CREATE TABLE IF NOT EXISTS `ChiRequirement` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_chirequirement_id` int(11) DEFAULT NULL,
  `fk_chigoal_id` int(11) DEFAULT NULL,
  `reqtype` varchar(255) DEFAULT NULL,
  `priority` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `proofreader` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_chirequirement_id` (`fk_chirequirement_id`),
  KEY `fk_chigoal_id` (`fk_chigoal_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ChiRequirementStatus`
--

DROP TABLE IF EXISTS `ChiRequirementStatus`;
CREATE TABLE IF NOT EXISTS `ChiRequirementStatus` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ChiRequirementType`
--

DROP TABLE IF EXISTS `ChiRequirementType`;
CREATE TABLE IF NOT EXISTS `ChiRequirementType` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ChiSystem`
--

DROP TABLE IF EXISTS `ChiSystem`;
CREATE TABLE IF NOT EXISTS `ChiSystem` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `config` varchar(255) DEFAULT NULL,
  `plattform` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ChiSystem`
--

INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(9, 8, 'config.ini', 'wcmf', NULL, 'Chi057Syst', NULL, 'null', 'Config', '?', '2012-06-23 00:49:00', 'admin', 'admin', '2012-06-23 00:49:00', NULL, 9);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(11, 8, 'config.ini', 'wcmf', NULL, 'Chi058Syst', NULL, 'null', 'ActionMapping', '?', '2012-06-23 00:49:06', 'admin', 'admin', '2012-06-23 00:49:06', NULL, 11);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(13, 8, 'config.ini', 'wcmf', NULL, 'Chi059Syst', NULL, 'null', 'Views', '?', '2012-06-23 00:49:16', 'admin', 'admin', '2012-06-23 00:49:16', NULL, 13);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(14, 8, 'config.ini', 'wcmf', NULL, 'Chi060Syst', NULL, 'null', 'TypeMapping', '?', '2012-06-23 00:49:22', 'admin', 'admin', '2012-06-23 00:49:22', NULL, 14);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(15, 8, 'config.ini', 'wcmf', NULL, 'Chi061Syst', NULL, 'null', 'Application', '?', '2012-06-23 00:49:27', 'admin', 'admin', '2012-06-23 00:49:27', NULL, 15);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(23, 8, 'config.ini', 'wcmf', NULL, 'Chi062Syst', NULL, 'null', 'Media', '?', '2012-06-23 00:49:33', 'admin', 'admin', '2012-06-23 00:49:33', NULL, 23);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(25, 8, 'config.ini', 'wcmf', NULL, 'Chi063Syst', NULL, 'null', 'RoleConfig', '?', '2012-05-11 08:49:41', 'admin', 'admin', '2012-06-24 02:24:13', NULL, 25);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(27, 8, 'config.ini', 'wcmf', NULL, 'Chi064Syst', NULL, 'null', 'Authorization', '?', '2012-05-11 08:49:42', 'admin', 'admin', '2012-06-24 02:24:47', NULL, 27);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(28, 8, 'config.ini', 'wcmf', NULL, 'Chi065Syst', NULL, 'null', 'I18N', '?', '2012-05-11 08:49:42', 'admin', 'admin', '2012-06-24 02:25:04', NULL, 28);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(34, 8, 'config.ini', 'wcmf', NULL, 'Chi066Syst', NULL, 'null', 'Search', '?', '2012-06-23 00:49:39', 'admin', 'admin', '2012-06-23 00:49:39', NULL, 34);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(36, 8, 'config.ini', 'wcmf', NULL, 'Chi067Syst', NULL, 'null', 'Boolean', '?', '2012-06-23 00:49:44', 'admin', 'admin', '2012-06-23 00:49:44', NULL, 36);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(40, 39, 'admin.ini', 'wcmf', NULL, 'Chi068Syst', NULL, 'null', 'Application', '?', '2012-06-23 01:05:02', 'admin', 'admin', '2012-06-23 01:05:02', NULL, 40);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(43, 42, 'server.ini', 'wcmf', NULL, 'Chi069Syst', NULL, 'null', 'Database', '?', '2012-06-23 01:20:11', 'admin', 'admin', '2012-06-23 01:20:11', NULL, 43);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(49, 42, 'server.ini', 'wcmf', NULL, 'Chi070Syst', NULL, 'null', 'I18N', '?', '2012-06-23 01:20:15', 'admin', 'admin', '2012-06-23 01:20:15', NULL, 49);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(51, 42, 'server.ini', 'wcmf', NULL, 'Chi071Syst', NULL, 'null', 'Languages', '?', '2012-06-23 01:20:18', 'admin', 'admin', '2012-06-23 01:20:18', NULL, 51);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(54, 42, 'server.ini', 'wcmf', NULL, 'Chi072Syst', NULL, 'null', 'NewInstance', '?', '2012-06-23 01:20:23', 'admin', 'admin', '2012-06-23 01:20:23', NULL, 54);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(57, 42, 'server.ini', 'wcmf', NULL, 'Chi073Syst', NULL, 'null', 'RemoteServer', '?', '2012-06-23 01:20:29', 'admin', 'admin', '2012-06-23 01:20:29', NULL, 57);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(58, 42, 'server.ini', 'wcmf', NULL, 'Chi074Syst', NULL, 'null', 'RemoteUser', '?', '2012-06-23 01:20:35', 'admin', 'admin', '2012-06-23 01:20:35', NULL, 58);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(60, 59, 'persistence.ini', 'wcmf', NULL, 'Chi075Syst', NULL, 'null', 'PersistenceFacade', 'PersistenceFacade implementation', '2012-05-11 08:49:51', 'admin', 'admin', '2012-05-11 08:49:51', NULL, 60);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(65, 59, 'persistence.ini', 'wcmf', NULL, 'Chi076Syst', NULL, 'null', 'AuditingLogStragegy', '?', '2012-06-23 01:25:16', 'admin', 'admin', '2012-06-23 01:25:16', NULL, 65);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(67, 59, 'persistence.ini', 'wcmf', NULL, 'Chi077Syst', NULL, 'null', 'Transaction', 'Transaction implementation', '2012-05-11 08:49:53', 'admin', 'admin', '2012-05-11 08:49:53', NULL, 67);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(69, 59, 'persistence.ini', 'wcmf', NULL, 'Chi078Syst', NULL, 'null', 'Converter', '?', '2012-06-23 01:25:25', 'admin', 'admin', '2012-06-23 01:25:25', NULL, 69);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(70, 59, 'persistence.ini', 'wcmf', NULL, 'Chi079Syst', NULL, 'null', 'LockHandler', 'LockHandler implementation', '2012-05-11 08:49:54', 'admin', 'admin', '2012-05-11 08:49:54', NULL, 70);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(72, 59, 'persistence.ini', 'wcmf', NULL, 'Chi080Syst', NULL, 'null', 'UserManager', 'UserManager implementation', '2012-05-11 08:49:55', 'admin', 'admin', '2012-05-11 08:49:55', NULL, 72);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(75, 74, 'presentation.ini', 'wcmf', NULL, 'Chi081Syst', NULL, 'null', 'View', '?', '2012-06-23 01:31:39', 'admin', 'admin', '2012-06-23 01:31:39', NULL, 75);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(83, 74, 'presentation.ini', 'wcmf', NULL, 'Chi082Syst', NULL, 'null', 'Formats', '?', '2012-06-23 01:31:45', 'admin', 'admin', '2012-06-23 01:31:45', NULL, 83);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(88, 74, 'presentation.ini', 'wcmf', NULL, 'Chi083Syst', NULL, 'null', 'HtmlFormat', '?', '2012-06-23 01:33:20', 'admin', 'admin', '2012-06-23 01:33:20', NULL, 88);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(90, 74, 'presentation.ini', 'wcmf', NULL, 'Chi084Syst', NULL, 'null', 'JsonFormat', '?', '2012-06-23 01:33:53', 'admin', 'admin', '2012-06-23 01:33:53', NULL, 90);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(92, 74, 'presentation.ini', 'wcmf', NULL, 'Chi085Syst', NULL, 'null', 'SoapFormat', '?', '2012-06-23 01:34:00', 'admin', 'admin', '2012-06-23 01:34:00', NULL, 92);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(94, 74, 'presentation.ini', 'wcmf', NULL, 'Chi086Syst', NULL, 'null', 'NullFormat', '?', '2012-06-23 01:34:06', 'admin', 'admin', '2012-06-23 01:34:06', NULL, 94);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(96, 74, 'presentation.ini', 'wcmf', NULL, 'Chi087Syst', NULL, 'null', 'ListStrategies', '?', '2012-06-23 01:35:20', 'admin', 'admin', '2012-06-23 01:35:20', NULL, 96);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(102, 74, 'presentation.ini', 'wcmf', NULL, 'Chi088Syst', NULL, 'null', 'FixedListStrategy', '?', '2012-06-23 01:35:24', 'admin', 'admin', '2012-06-23 01:35:24', NULL, 102);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(104, 74, 'presentation.ini', 'wcmf', NULL, 'Chi089Syst', NULL, 'null', 'FunctionListStrategy', '?', '2012-06-23 01:35:32', 'admin', 'admin', '2012-06-23 01:35:32', NULL, 104);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(106, 74, 'presentation.ini', 'wcmf', NULL, 'Chi090Syst', NULL, 'null', 'ConfigListStrategy', '?', '2012-06-23 01:31:49', 'admin', 'admin', '2012-06-23 01:31:49', NULL, 106);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(108, 74, 'presentation.ini', 'wcmf', NULL, 'Chi091Syst', NULL, 'null', 'AsyncListStrategy', '?', '2012-06-23 01:34:19', 'admin', 'admin', '2012-06-23 01:34:19', NULL, 108);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(110, 74, 'presentation.ini', 'wcmf', NULL, 'Chi092Syst', NULL, 'null', 'AsyncMultListStrategy', '?', '2012-06-23 01:34:23', 'admin', 'admin', '2012-06-23 01:34:23', NULL, 110);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(112, 74, 'presentation.ini', 'wcmf', NULL, 'Chi093Syst', NULL, 'null', 'ValueRenderer', '?', '2012-06-23 01:34:57', 'admin', 'admin', '2012-06-23 01:34:57', NULL, 112);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(115, 74, 'presentation.ini', 'wcmf', NULL, 'Chi094Syst', NULL, 'null', 'DisplayTypes', '?', '2012-06-23 01:34:45', 'admin', 'admin', '2012-06-23 01:34:45', NULL, 115);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(119, 74, 'presentation.ini', 'wcmf', NULL, 'Chi095Syst', NULL, 'null', 'TextDisplayType', '?', '2012-06-23 01:37:07', 'admin', 'admin', '2012-06-23 01:37:07', NULL, 119);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(122, 74, 'presentation.ini', 'wcmf', NULL, 'Chi096Syst', NULL, 'null', 'ImageDisplayType', '?', '2012-06-23 01:37:13', 'admin', 'admin', '2012-06-23 01:37:13', NULL, 122);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(125, 74, 'presentation.ini', 'wcmf', NULL, 'Chi097Syst', NULL, 'null', 'LinkDisplayType', '?', '2012-06-23 01:37:32', 'admin', 'admin', '2012-06-23 01:37:32', NULL, 125);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(128, 74, 'presentation.ini', 'wcmf', NULL, 'Chi098Syst', NULL, 'null', 'ControlRenderer', '?', '2012-06-23 01:37:53', 'admin', 'admin', '2012-06-23 01:37:53', NULL, 128);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(132, 74, 'presentation.ini', 'wcmf', NULL, 'Chi099Syst', NULL, 'null', 'Controls', '?', '2012-06-23 01:37:58', 'admin', 'admin', '2012-06-23 01:37:58', NULL, 132);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(146, 74, 'presentation.ini', 'wcmf', NULL, 'Chi100Syst', NULL, 'null', 'CheckboxControl', '?', '2012-06-23 01:31:51', 'admin', 'admin', '2012-06-23 01:31:51', NULL, 146);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(149, 74, 'presentation.ini', 'wcmf', NULL, 'Chi101Syst', NULL, 'null', 'CkeditorControl', '?', '2012-06-23 01:34:26', 'admin', 'admin', '2012-06-23 01:34:26', NULL, 149);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(152, 74, 'presentation.ini', 'wcmf', NULL, 'Chi102Syst', NULL, 'null', 'DateControl', '?', '2012-06-23 01:34:39', 'admin', 'admin', '2012-06-23 01:34:39', NULL, 152);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(155, 74, 'presentation.ini', 'wcmf', NULL, 'Chi103Syst', NULL, 'null', 'FilebrowserControl', '?', '2012-06-23 01:36:10', 'admin', 'admin', '2012-06-23 01:36:10', NULL, 155);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(158, 74, 'presentation.ini', 'wcmf', NULL, 'Chi104Syst', NULL, 'null', 'LinkbrowserControl', '?', '2012-06-23 01:38:01', 'admin', 'admin', '2012-06-23 01:38:01', NULL, 158);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(161, 74, 'presentation.ini', 'wcmf', NULL, 'Chi105Syst', NULL, 'null', 'PasswordControl', '?', '2012-06-23 01:37:42', 'admin', 'admin', '2012-06-23 01:37:42', NULL, 161);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(164, 74, 'presentation.ini', 'wcmf', NULL, 'Chi106Syst', NULL, 'null', 'RadioControl', '?', '2012-06-23 01:38:40', 'admin', 'admin', '2012-06-23 01:38:40', NULL, 164);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(168, 74, 'presentation.ini', 'wcmf', NULL, 'Chi107Syst', NULL, 'null', 'SelectControl', '?', '2012-06-23 01:38:44', 'admin', 'admin', '2012-06-23 01:38:44', NULL, 168);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(172, 74, 'presentation.ini', 'wcmf', NULL, 'Chi108Syst', NULL, 'null', 'SelectAsyncControl', '?', '2012-06-23 01:38:48', 'admin', 'admin', '2012-06-23 01:38:48', NULL, 172);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(176, 74, 'presentation.ini', 'wcmf', NULL, 'Chi109Syst', NULL, 'null', 'TextControl', '?', '2012-06-23 01:40:31', 'admin', 'admin', '2012-06-23 01:40:31', NULL, 176);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(179, 74, 'presentation.ini', 'wcmf', NULL, 'Chi110Syst', NULL, 'null', 'TextareaControl', '?', '2012-06-23 01:32:49', 'admin', 'admin', '2012-06-23 01:32:49', NULL, 179);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(182, 74, 'presentation.ini', 'wcmf', NULL, 'Chi111Syst', NULL, 'null', 'TextileControl', '?', '2012-06-23 01:34:29', 'admin', 'admin', '2012-06-23 01:34:29', NULL, 182);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(185, 74, 'presentation.ini', 'wcmf', NULL, 'Chi112Syst', NULL, 'null', 'BinaryCheckboxControl', '?', '2012-06-23 01:33:32', 'admin', 'admin', '2012-06-23 01:33:32', NULL, 185);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(4683, 59, 'persistence.ini', 'wcmf', NULL, 'Chi113Syst', NULL, '1.0', 'ConcurrencyManager', '?', '2013-02-19 19:14:54', 'admin', 'admin', '2013-02-19 19:39:15', NULL, 4683);

-- --------------------------------------------------------

--
-- Table structure for table `ChiValue`
--

DROP TABLE IF EXISTS `ChiValue`;
CREATE TABLE IF NOT EXISTS `ChiValue` (
  `id` int(11) NOT NULL,
  `fk_chicontroller_id` int(11) DEFAULT NULL,
  `fk_chisystem_id` int(11) DEFAULT NULL,
  `fk_chinodemanytomany_id` int(11) DEFAULT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_chinode_id` int(11) DEFAULT NULL,
  `column_name` varchar(255) DEFAULT NULL,
  `display_type` varchar(255) DEFAULT NULL,
  `restrictions_description` varchar(255) DEFAULT NULL,
  `restrictions_match` varchar(255) DEFAULT NULL,
  `restrictions_not_match` varchar(255) DEFAULT NULL,
  `input_type` varchar(255) DEFAULT NULL,
  `app_data_type` varchar(255) DEFAULT NULL,
  `db_data_type` varchar(255) DEFAULT NULL,
  `is_editable` varchar(255) DEFAULT NULL,
  `default` varchar(255) DEFAULT NULL,
  `propertytype` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chicontroller_id` (`fk_chicontroller_id`),
  KEY `fk_chisystem_id` (`fk_chisystem_id`),
  KEY `fk_chinodemanytomany_id` (`fk_chinodemanytomany_id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_chinode_id` (`fk_chinode_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ChiValue`
--

INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(10, NULL, 9, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', '{server.ini, persistence.ini, presentation.ini}', '531', NULL, 'Chi027Val', NULL, '1.0', 'include', '?', '2012-05-11 08:48:46', 'admin', 'admin', '2012-06-23 00:53:10', NULL, 10);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(12, NULL, 11, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf\\application\\controller\\FailureController', '531', NULL, 'Chi028Val', NULL, '1.0', '??fatal', '?', '2012-05-11 08:48:46', 'admin', 'admin', '2012-06-25 23:59:14', NULL, 12);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(16, NULL, 15, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'WCMF TEST MODEL', '531', NULL, 'Chi029Val', NULL, '1.0', 'applicationTitle', '?', '2012-05-11 08:48:47', 'admin', 'admin', '2012-06-23 00:56:12', NULL, 16);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(17, NULL, 15, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', '../wcmf/', '531', NULL, 'Chi030Val', NULL, '1.0', 'libDir', '?', '2012-05-11 08:48:47', 'admin', 'admin', '2012-06-23 00:56:36', NULL, 17);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(18, NULL, 15, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', '../../html/', '531', NULL, 'Chi031Val', NULL, '1.0', 'exportDir', '?', '2012-05-11 08:48:47', 'admin', 'admin', '2012-06-23 00:57:02', NULL, 18);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(19, NULL, 15, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'backup/', '531', NULL, 'Chi032Val', NULL, '1.0', 'backupDir', '?', '2012-05-11 08:48:47', 'admin', 'admin', '2012-06-23 00:57:27', NULL, 19);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(21, NULL, 15, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'false', '531', NULL, 'Chi034Val', NULL, '1.0', 'anonymous', '?', '2012-05-11 08:48:47', 'admin', 'admin', '2012-06-23 02:19:17', NULL, 21);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(22, NULL, 15, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', '{Page, Document}', '531', NULL, 'Chi035Val', NULL, '1.0', 'rootTypes', '?', '2012-05-11 08:48:47', 'admin', 'admin', '2012-06-23 01:02:17', NULL, 22);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(24, NULL, 23, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', '../../media/', '531', NULL, 'Chi036Val', NULL, '1.0', 'uploadDir', '?', '2012-05-11 08:48:48', 'admin', 'admin', '2012-06-23 01:03:06', NULL, 24);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(26, NULL, 25, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'admin.ini', '531', NULL, 'Chi037Val', NULL, '1.0', 'administrators', '?', '2012-05-11 08:48:48', 'admin', 'admin', '2012-06-24 02:24:36', NULL, 26);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(29, NULL, 28, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'locale/', '531', NULL, 'Chi038Val', NULL, '1.0', 'localeDir', '?', '2012-05-11 08:48:48', 'admin', 'admin', '2012-06-24 02:25:46', NULL, 29);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(30, NULL, 28, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'en_EN', '531', NULL, 'Chi039Val', NULL, '1.0', 'language', '?', '2012-05-11 08:48:49', 'admin', 'admin', '2012-06-24 02:26:03', NULL, 30);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(31, NULL, 28, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', '{text, textarea, filebrowser, linkbrowser, ckeditor}', '531', NULL, 'Chi040Val', NULL, '1.0', 'inputTypes', '?', '2012-05-11 08:48:49', 'admin', 'admin', '2012-06-24 02:26:27', NULL, 31);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(32, NULL, 28, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'Language', '531', NULL, 'Chi041Val', NULL, '1.0', 'languageType', '?', '2012-05-11 08:48:49', 'admin', 'admin', '2012-06-24 02:26:39', NULL, 32);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(33, NULL, 28, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'Translation', '531', NULL, 'Chi042Val', NULL, '1.0', 'translationType', '?', '2012-05-11 08:48:49', 'admin', 'admin', '2012-06-24 02:27:02', NULL, 33);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(35, NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'searchIndex/', '531', NULL, 'Chi043Val', NULL, '1.0', 'indexPath', '?', '2012-05-11 08:48:50', 'admin', 'admin', '2012-06-23 01:04:29', NULL, 35);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(37, NULL, 36, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'no', '531', NULL, 'Chi044Val', NULL, '1.0', '0', '?', '2012-05-11 08:48:50', 'admin', 'admin', '2012-06-23 00:54:55', NULL, 37);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(38, NULL, 36, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'yes', '531', NULL, 'Chi045Val', NULL, '1.0', '1', '?', '2012-05-11 08:48:50', 'admin', 'admin', '2012-06-23 00:55:14', NULL, 38);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(41, NULL, 40, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', '{Page, Document, UserRDB, RoleRDB, Locktable}', '531', NULL, 'Chi046Val', NULL, '1.0', 'rootTypes', '?', '2012-05-11 08:48:50', 'admin', 'admin', '2012-06-23 01:04:51', NULL, 41);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(44, NULL, 43, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'mysql', '531', NULL, 'Chi047Val', NULL, '1.0', 'dbType', '?', '2012-05-11 08:48:51', 'admin', 'admin', '2012-06-23 01:23:03', NULL, 44);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(45, NULL, 43, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'localhost', '531', NULL, 'Chi048Val', NULL, '1.0', 'dbHostName', '?', '2012-05-11 08:48:51', 'admin', 'admin', '2012-06-23 01:23:23', NULL, 45);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(46, NULL, 43, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf_testapp', '531', NULL, 'Chi049Val', NULL, '1.0', 'dbName', '?', '2012-05-11 08:48:51', 'admin', 'admin', '2013-02-19 15:48:23', NULL, 46);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(47, NULL, 43, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf', '531', NULL, 'Chi050Val', NULL, '1.0', 'dbUserName', '?', '2012-05-11 08:48:51', 'admin', 'admin', '2012-06-23 01:24:13', NULL, 47);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(48, NULL, 43, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'geheim', '531', NULL, 'Chi051Val', NULL, '1.0', 'dbPassword', '?', '2012-05-11 08:48:51', 'admin', 'admin', '2012-06-23 01:24:31', NULL, 48);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(50, NULL, 49, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'en', '531', NULL, 'Chi052Val', NULL, '1.0', 'defaultLanguage', '?', '2012-05-11 08:48:51', 'admin', 'admin', '2012-06-23 01:25:01', NULL, 50);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(52, NULL, 51, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'Deutsch', '531', NULL, 'Chi053Val', NULL, '1.0', 'de', '?', '2012-05-11 08:48:52', 'admin', 'admin', '2012-06-23 01:21:16', NULL, 52);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(53, NULL, 51, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'English', '531', NULL, 'Chi054Val', NULL, '1.0', 'en', '?', '2012-05-11 08:48:52', 'admin', 'admin', '2012-06-23 01:21:37', NULL, 53);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(55, NULL, 54, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf_', '531', NULL, 'Chi055Val', NULL, '1.0', 'dbPrefix', '?', '2012-05-11 08:48:52', 'admin', 'admin', '2012-06-23 01:22:11', NULL, 55);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(56, NULL, 54, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', '../../', '531', NULL, 'Chi056Val', NULL, '1.0', 'targetDir', '?', '2012-05-11 08:48:52', 'admin', 'admin', '2012-06-23 01:22:37', NULL, 56);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(61, NULL, 60, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf\\lib\\persistence\\DefaultPersistenceFacade', '531', NULL, 'Chi057Val', NULL, '1.0', '__class', '?', '2012-05-11 08:48:53', 'admin', 'admin', '2012-06-26 00:01:19', NULL, 61);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(62, NULL, 60, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', '$typeMapping', '531', NULL, 'Chi058Val', NULL, '1.0', 'mappers', '?', '2012-05-11 08:48:53', 'admin', 'admin', '2012-06-23 01:27:23', NULL, 62);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(63, NULL, 60, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'false', '531', NULL, 'Chi059Val', NULL, '1.0', 'logging', '?', '2012-05-11 08:48:53', 'admin', 'admin', '2012-06-23 01:27:40', NULL, 63);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(64, NULL, 60, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', '$auditingLogStragegy', '531', NULL, 'Chi060Val', NULL, '1.0', 'logStrategy', '?', '2012-05-11 08:48:54', 'admin', 'admin', '2012-06-23 01:28:05', NULL, 64);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(66, NULL, 65, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf\\lib\\persistence\\output\\AuditingOutputStrategy', '531', NULL, 'Chi061Val', NULL, '1.0', '__class', '?', '2012-05-11 08:48:54', 'admin', 'admin', '2012-06-26 00:01:44', NULL, 66);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(68, NULL, 67, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf\\lib\\persistence\\DefaultTransaction', '531', NULL, 'Chi062Val', NULL, '1.0', '__class', '?', '2012-05-11 08:48:54', 'admin', 'admin', '2012-06-26 00:01:59', NULL, 68);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(71, NULL, 70, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf\\lib\\persistence\\concurrency\\DefaultLockHandler', '531', NULL, 'Chi063Val', NULL, '1.0', '__class', '?', '2012-05-11 08:48:55', 'admin', 'admin', '2012-06-26 00:03:50', NULL, 71);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(73, NULL, 72, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf\\lib\\security\\DefaultUserManager', '531', NULL, 'Chi064Val', NULL, '1.0', '__class', '?', '2012-05-11 08:48:55', 'admin', 'admin', '2012-06-26 00:05:33', NULL, 73);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(76, NULL, 75, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf\\lib\\presentation\\SmartyView', '531', NULL, 'Chi065Val', NULL, '1.0', '__class', '?', '2012-05-11 08:48:55', 'admin', 'admin', '2012-06-26 00:06:02', NULL, 76);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(77, NULL, 75, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'false', '531', NULL, 'Chi066Val', NULL, '1.0', '__shared', '?', '2012-05-11 08:48:55', 'admin', 'admin', '2012-06-23 02:15:31', NULL, 77);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(78, NULL, 75, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'include/views/', '531', NULL, 'Chi067Val', NULL, '1.0', 'templateDir', '?', '2012-05-11 08:48:56', 'admin', 'admin', '2012-06-23 02:15:55', NULL, 78);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(79, NULL, 75, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'true', '531', NULL, 'Chi068Val', NULL, '1.0', 'compileCheck', '?', '2012-05-11 08:48:56', 'admin', 'admin', '2012-06-23 02:16:12', NULL, 79);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(80, NULL, 75, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'false', '531', NULL, 'Chi069Val', NULL, '1.0', 'debugView', '?', '2012-05-11 08:48:56', 'admin', 'admin', '2012-06-23 02:16:24', NULL, 80);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(81, NULL, 75, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'false', '531', NULL, 'Chi070Val', NULL, '1.0', 'caching', '?', '2012-05-11 08:48:56', 'admin', 'admin', '2012-06-23 02:16:36', NULL, 81);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(82, NULL, 75, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', '3600', '3463', NULL, 'Chi071Val', NULL, '1.0', 'cacheLifetime', '?', '2012-05-11 08:48:56', 'admin', 'admin', '2012-06-23 02:18:08', NULL, 82);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(84, NULL, 83, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', '$htmlFormat', '531', NULL, 'Chi072Val', NULL, '1.0', 'html', '?', '2012-05-11 08:48:56', 'admin', 'admin', '2012-06-23 02:14:05', NULL, 84);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(85, NULL, 83, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', '$jsonFormat', '531', NULL, 'Chi073Val', NULL, '1.0', 'json', '?', '2012-05-11 08:48:57', 'admin', 'admin', '2012-06-23 02:14:21', NULL, 85);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(86, NULL, 83, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', '$soapFormat', '531', NULL, 'Chi074Val', NULL, '1.0', 'soap', '?', '2012-05-11 08:48:57', 'admin', 'admin', '2012-06-23 02:14:37', NULL, 86);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(87, NULL, 83, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', '$nullFormat', '531', NULL, 'Chi075Val', NULL, '1.0', 'null', '?', '2012-05-11 08:48:57', 'admin', 'admin', '2012-06-23 02:14:53', NULL, 87);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(89, NULL, 88, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf\\lib\\presentation\\format\\HtmlFormat', '531', NULL, 'Chi076Val', NULL, '1.0', '__class', '?', '2012-05-11 08:48:57', 'admin', 'admin', '2012-06-26 00:06:35', NULL, 89);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(91, NULL, 90, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf\\lib\\presentation\\format\\JsonFormat', '531', NULL, 'Chi077Val', NULL, '1.0', '__class', '?', '2012-05-11 08:48:58', 'admin', 'admin', '2012-06-26 00:06:49', NULL, 91);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(93, NULL, 92, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf\\lib\\presentation\\format\\SoapFormat', '531', NULL, 'Chi078Val', NULL, '1.0', '__class', '?', '2012-05-11 08:48:58', 'admin', 'admin', '2012-06-26 00:07:02', NULL, 93);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(95, NULL, 94, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf\\lib\\presentation\\format\\NullFormat', '531', NULL, 'Chi079Val', NULL, '1.0', '__class', '?', '2012-05-11 08:48:58', 'admin', 'admin', '2012-06-26 00:07:16', NULL, 95);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(97, NULL, 96, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', '$fixedListStrategy', '531', NULL, 'Chi080Val', NULL, '1.0', 'fix', '?', '2012-05-11 08:48:59', 'admin', 'admin', '2012-06-23 02:11:27', NULL, 97);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(98, NULL, 96, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', '$functionListStrategy', '531', NULL, 'Chi081Val', NULL, '1.0', 'function', '?', '2012-05-11 08:48:59', 'admin', 'admin', '2012-06-23 02:11:42', NULL, 98);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(99, NULL, 96, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', '$configListStrategy', '531', NULL, 'Chi082Val', NULL, '1.0', 'config', '?', '2012-05-11 08:48:59', 'admin', 'admin', '2012-06-23 02:11:57', NULL, 99);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(100, NULL, 96, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', '$asyncListStrategy', '531', NULL, 'Chi083Val', NULL, '1.0', 'async', '?', '2012-05-11 08:48:59', 'admin', 'admin', '2012-06-23 02:12:12', NULL, 100);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(101, NULL, 96, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', '$asyncMultListStrategy', '531', NULL, 'Chi084Val', NULL, '1.0', 'asyncmult', '?', '2012-05-11 08:48:59', 'admin', 'admin', '2012-06-23 02:12:33', NULL, 101);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(103, NULL, 102, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf\\lib\\presentation\\control\\FixedListStrategy', '531', NULL, 'Chi085Val', NULL, '1.0', '__class', '?', '2012-05-11 08:49:00', 'admin', 'admin', '2012-06-26 00:07:46', NULL, 103);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(105, NULL, 104, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf\\lib\\presentation\\control\\FunctionListStrategy', '531', NULL, 'Chi086Val', NULL, '1.0', '__class', '?', '2012-05-11 08:49:00', 'admin', 'admin', '2012-06-26 00:08:03', NULL, 105);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(107, NULL, 106, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf\\lib\\presentation\\control\\ConfigListStrategy', '531', NULL, 'Chi087Val', NULL, '1.0', '__class', '?', '2012-05-11 08:49:00', 'admin', 'admin', '2012-06-26 00:08:19', NULL, 107);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(109, NULL, 108, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf\\lib\\presentation\\control\\AsyncListStrategy', '531', NULL, 'Chi088Val', NULL, '1.0', '__class', '?', '2012-05-11 08:49:00', 'admin', 'admin', '2012-06-26 00:08:29', NULL, 109);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(111, NULL, 110, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf\\lib\\presentation\\control\\AsyncMultListStrategy', '531', NULL, 'Chi089Val', NULL, '1.0', '__class', '?', '2012-05-11 08:49:01', 'admin', 'admin', '2012-06-26 00:08:59', NULL, 111);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(113, NULL, 112, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf\\lib\\presentation\\renderer\\ValueRenderer', '531', NULL, 'Chi090Val', NULL, '1.0', '__class', '?', '2012-05-11 08:49:01', 'admin', 'admin', '2012-06-26 00:09:25', NULL, 113);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(114, NULL, 112, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', '$displayTypes', '531', NULL, 'Chi091Val', NULL, '1.0', 'displayTypes', '?', '2012-05-11 08:49:01', 'admin', 'admin', '2012-06-23 02:09:38', NULL, 114);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(116, NULL, 115, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', '$textDisplayType', '531', NULL, 'Chi092Val', NULL, '1.0', 'text', '?', '2012-05-11 08:49:02', 'admin', 'admin', '2012-06-23 02:08:17', NULL, 116);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(117, NULL, 115, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', '$imageDisplayType', '531', NULL, 'Chi093Val', NULL, '1.0', 'image', '?', '2012-05-11 08:49:02', 'admin', 'admin', '2012-06-23 02:08:34', NULL, 117);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(118, NULL, 115, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', '$linkDisplayType', '531', NULL, 'Chi094Val', NULL, '1.0', 'link', '?', '2012-05-11 08:49:02', 'admin', 'admin', '2012-06-23 02:08:49', NULL, 118);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(120, NULL, 119, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf\\lib\\presentation\\renderer\\BaseDisplayType', '531', NULL, 'Chi095Val', NULL, '1.0', '__class', '?', '2012-05-11 08:49:02', 'admin', 'admin', '2012-06-26 00:09:48', NULL, 120);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(121, NULL, 119, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf/application/views/display/text.tpl', '531', NULL, 'Chi096Val', NULL, '1.0', 'viewTpl', '?', '2012-05-11 08:49:02', 'admin', 'admin', '2012-06-23 02:07:54', NULL, 121);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(123, NULL, 122, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmfl\\ib\\presentation\\renderer\\ImageDisplayType', '531', NULL, 'Chi097Val', NULL, '1.0', '__class', '?', '2012-05-11 08:49:03', 'admin', 'admin', '2012-06-26 00:10:05', NULL, 123);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(124, NULL, 122, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf/application/views/display/image.tpl', '531', NULL, 'Chi098Val', NULL, '1.0', 'viewTpl', '?', '2012-05-11 08:49:03', 'admin', 'admin', '2012-06-23 02:07:13', NULL, 124);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(126, NULL, 125, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf\\lib\\presentation\\renderer\\BaseDisplayType', '531', NULL, 'Chi099Val', NULL, '1.0', '__class', '?', '2012-05-11 08:49:03', 'admin', 'admin', '2012-06-26 00:10:23', NULL, 126);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(127, NULL, 125, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf/application/views/display/link.tpl', '531', NULL, 'Chi100Val', NULL, '1.0', 'viewTpl', '?', '2012-05-11 08:49:03', 'admin', 'admin', '2012-06-23 02:06:27', NULL, 127);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(129, NULL, 128, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf\\lib\\presentation\\control\\ControlRenderer', '531', NULL, 'Chi101Val', NULL, '1.0', '__class', '?', '2012-05-11 08:49:04', 'admin', 'admin', '2012-06-26 00:10:39', NULL, 129);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(130, NULL, 128, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', '$controls', '531', NULL, 'Chi102Val', NULL, '1.0', 'controls', '?', '2012-05-11 08:49:04', 'admin', 'admin', '2012-06-23 02:05:27', NULL, 130);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(131, NULL, 128, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', '-', '531', NULL, 'Chi103Val', NULL, '1.0', 'inputFieldDelimiter', '?', '2012-05-11 08:49:04', 'admin', 'admin', '2012-06-23 02:05:46', NULL, 131);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(133, NULL, 132, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', '$checkboxControl', '531', NULL, 'Chi104Val', NULL, '1.0', 'checkbox', '?', '2012-05-11 08:49:05', 'admin', 'admin', '2012-06-23 02:01:16', NULL, 133);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(134, NULL, 132, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', '$ckeditorControl', '531', NULL, 'Chi105Val', NULL, '1.0', 'ckeditor', '?', '2012-05-11 08:49:05', 'admin', 'admin', '2012-06-23 02:01:35', NULL, 134);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(135, NULL, 132, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', '$dateControl', '531', NULL, 'Chi106Val', NULL, '1.0', 'date', '?', '2012-05-11 08:49:05', 'admin', 'admin', '2012-06-23 02:01:53', NULL, 135);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(136, NULL, 132, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', '$filebrowserControl', '531', NULL, 'Chi107Val', NULL, '1.0', 'filebrowser', '?', '2012-05-11 08:49:05', 'admin', 'admin', '2012-06-23 02:02:13', NULL, 136);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(137, NULL, 132, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', '$linkbrowserControl', '531', NULL, 'Chi108Val', NULL, '1.0', 'linkbrowser', '?', '2012-05-11 08:49:05', 'admin', 'admin', '2012-06-23 02:02:36', NULL, 137);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(138, NULL, 132, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', '$passwordControl', '531', NULL, 'Chi109Val', NULL, '1.0', 'password', '?', '2012-05-11 08:49:05', 'admin', 'admin', '2012-06-23 02:02:52', NULL, 138);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(139, NULL, 132, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', '$radioControl', '531', NULL, 'Chi110Val', NULL, '1.0', 'radio', '?', '2012-05-11 08:49:05', 'admin', 'admin', '2012-06-23 02:03:10', NULL, 139);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(140, NULL, 132, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', '$selectControl', '531', NULL, 'Chi111Val', NULL, '1.0', 'select', '?', '2012-05-11 08:49:06', 'admin', 'admin', '2012-06-23 02:03:26', NULL, 140);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(141, NULL, 132, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', '$selectAsyncControl', '531', NULL, 'Chi112Val', NULL, '1.0', 'select#async', '?', '2012-05-11 08:49:06', 'admin', 'admin', '2012-06-23 02:03:41', NULL, 141);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(142, NULL, 132, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', '$textControl', '531', NULL, 'Chi113Val', NULL, '1.0', 'text', '?', '2012-05-11 08:49:06', 'admin', 'admin', '2012-06-23 02:03:56', NULL, 142);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(143, NULL, 132, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', '$textareaControl', '531', NULL, 'Chi114Val', NULL, '1.0', 'textarea', '?', '2012-05-11 08:49:06', 'admin', 'admin', '2012-06-23 02:04:11', NULL, 143);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(144, NULL, 132, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', '$textileControl', '531', NULL, 'Chi115Val', NULL, '1.0', 'textile', '?', '2012-05-11 08:49:06', 'admin', 'admin', '2012-06-23 02:04:26', NULL, 144);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(145, NULL, 132, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', '$binarycheckboxControl', '531', NULL, 'Chi116Val', NULL, '1.0', 'binarycheckbox', '?', '2012-05-11 08:49:06', 'admin', 'admin', '2012-06-23 02:04:43', NULL, 145);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(147, NULL, 146, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf\\lib\\presentation\\control\\BaseControl', '531', NULL, 'Chi117Val', NULL, '1.0', '__class', '?', '2012-05-11 08:49:07', 'admin', 'admin', '2012-06-26 00:11:04', NULL, 147);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(148, NULL, 146, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf/application/views/forms/checkbox.tpl', '531', NULL, 'Chi118Val', NULL, '1.0', 'viewTpl', '?', '2012-05-11 08:49:07', 'admin', 'admin', '2012-06-23 02:00:57', NULL, 148);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(150, NULL, 149, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf\\lib\\presentation\\control\\BaseControl', '531', NULL, 'Chi119Val', NULL, '1.0', '__class', '?', '2012-05-11 08:49:07', 'admin', 'admin', '2012-06-26 00:11:25', NULL, 150);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(151, NULL, 149, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf/application/views/forms/ckeditor.tpl', '531', NULL, 'Chi120Val', NULL, '1.0', 'viewTpl', '?', '2012-05-11 08:49:07', 'admin', 'admin', '2012-06-23 02:00:16', NULL, 151);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(153, NULL, 152, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf\\lib\\presentation\\control\\BaseControl', '531', NULL, 'Chi121Val', NULL, '1.0', '__class', '?', '2012-05-11 08:49:07', 'admin', 'admin', '2012-06-26 00:11:54', NULL, 153);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(154, NULL, 152, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf/application/views/forms/date.tpl', '531', NULL, 'Chi122Val', NULL, '1.0', 'viewTpl', '?', '2012-05-11 08:49:08', 'admin', 'admin', '2012-06-23 01:59:35', NULL, 154);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(156, NULL, 155, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf\\lib\\presentation\\control\\FileBrowserControl', '531', NULL, 'Chi123Val', NULL, '1.0', '__class', '?', '2012-05-11 08:49:08', 'admin', 'admin', '2012-06-26 00:12:07', NULL, 156);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(157, NULL, 155, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf/application/views/forms/filebrowser.tpl', '531', NULL, 'Chi124Val', NULL, '1.0', 'viewTpl', '?', '2012-05-11 08:49:08', 'admin', 'admin', '2012-06-23 01:58:58', NULL, 157);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(159, NULL, 158, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf\\lib\\presentation\\control\\LinkBrowserControl', '531', NULL, 'Chi125Val', NULL, '1.0', '__class', '?', '2012-05-11 08:49:08', 'admin', 'admin', '2012-06-26 00:12:28', NULL, 159);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(160, NULL, 158, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf/application/views/forms/linkbrowser.tpl', '531', NULL, 'Chi126Val', NULL, '1.0', 'viewTpl', '?', '2012-05-11 08:49:09', 'admin', 'admin', '2012-06-23 01:58:13', NULL, 160);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(162, NULL, 161, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf\\lib\\presentation\\control\\BaseControl', '531', NULL, 'Chi127Val', NULL, '1.0', '__class', '?', '2012-05-11 08:49:09', 'admin', 'admin', '2012-06-26 00:12:44', NULL, 162);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(163, NULL, 161, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf/application/views/forms/password.tpl', '531', NULL, 'Chi128Val', NULL, '1.0', 'viewTpl', '?', '2012-05-11 08:49:09', 'admin', 'admin', '2012-06-23 01:55:46', NULL, 163);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(165, NULL, 164, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf\\lib\\presentation\\control\\ListControl', '531', NULL, 'Chi129Val', NULL, '1.0', '__class', '?', '2012-05-11 08:49:09', 'admin', 'admin', '2012-06-26 00:13:04', NULL, 165);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(166, NULL, 164, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf/application/views/forms/radio.tpl', '531', NULL, 'Chi130Val', NULL, '1.0', 'viewTpl', '?', '2012-05-11 08:49:10', 'admin', 'admin', '2012-06-23 01:51:29', NULL, 166);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(167, NULL, 164, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', '$listStrategies', '531', NULL, 'Chi131Val', NULL, '1.0', 'listStrategies', '?', '2012-05-11 08:49:11', 'admin', 'admin', '2012-06-23 01:50:07', NULL, 167);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(169, NULL, 168, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf\\lib\\presentation\\control\\ListControl', '531', NULL, 'Chi132Val', NULL, '1.0', '__class', '?', '2012-05-11 08:49:11', 'admin', 'admin', '2012-06-26 00:13:19', NULL, 169);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(170, NULL, 168, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf/application/views/forms/select.tpl', '531', NULL, 'Chi133Val', NULL, '1.0', 'viewTpl', '?', '2012-05-11 08:49:11', 'admin', 'admin', '2012-06-23 01:49:17', NULL, 170);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(171, NULL, 168, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', '$listStrategies', '531', NULL, 'Chi134Val', NULL, '1.0', 'listStrategies', '?', '2012-05-11 08:49:12', 'admin', 'admin', '2012-06-23 01:49:44', NULL, 171);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(173, NULL, 172, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf\\lib\\presentation\\control\\AsyncListControl', '531', NULL, 'Chi135Val', NULL, '1.0', '__class', '?', '2012-05-11 08:49:12', 'admin', 'admin', '2012-06-26 00:13:43', NULL, 173);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(174, NULL, 172, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf/application/views/forms/selectasync.tpl', '531', NULL, 'Chi136Val', NULL, '1.0', 'viewTpl', '?', '2012-05-11 08:49:12', 'admin', 'admin', '2012-06-23 01:47:31', NULL, 174);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(175, NULL, 172, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', '$listStrategies', '531', NULL, 'Chi137Val', NULL, '1.0', 'listStrategies', '?', '2012-05-11 08:49:12', 'admin', 'admin', '2012-06-23 01:47:59', NULL, 175);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(177, NULL, 176, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf\\lib\\presentation\\control\\BaseControl', '531', NULL, 'Chi138Val', NULL, '1.0', '__class', '?', '2012-05-11 08:49:12', 'admin', 'admin', '2012-06-26 00:14:02', NULL, 177);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(178, NULL, 176, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf/application/views/forms/text.tpl', '531', NULL, 'Chi139Val', NULL, '1.0', 'viewTpl', '?', '2012-05-11 08:49:12', 'admin', 'admin', '2012-06-23 01:46:18', NULL, 178);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(180, NULL, 179, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf\\lib\\presentation\\control\\BaseControl', '531', NULL, 'Chi140Val', NULL, '1.0', '__class', '?', '2012-05-11 08:49:12', 'admin', 'admin', '2012-06-26 00:14:17', NULL, 180);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(181, NULL, 179, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf/application/views/forms/textarea.tpl', '531', NULL, 'Chi141Val', NULL, '1.0', 'viewTpl', '?', '2012-05-11 08:49:13', 'admin', 'admin', '2012-06-23 01:44:33', NULL, 181);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(183, NULL, 182, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf\\lib\\presentation\\control\\BaseControl', '531', NULL, 'Chi142Val', NULL, '1.0', '__class', '?', '2012-05-11 08:49:13', 'admin', 'admin', '2012-06-26 00:14:29', NULL, 183);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(184, NULL, 182, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf/application/views/forms/textile.tpl', '531', NULL, 'Chi143Val', NULL, '1.0', 'viewTpl', '?', '2012-05-11 08:49:13', 'admin', 'admin', '2012-06-23 01:43:05', NULL, 184);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(186, NULL, 185, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf\\lib\\presentation\\control\\BaseControl', '531', NULL, 'Chi144Val', NULL, '1.0', '__class', '?', '2012-05-11 08:49:13', 'admin', 'admin', '2012-06-26 00:14:44', NULL, 186);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(187, NULL, 185, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', 'wcmf/application/views/forms/binarycheckbox.tpl', '531', NULL, 'Chi145Val', NULL, '1.0', 'viewTpl', '?', '2012-05-11 08:49:13', 'admin', 'admin', '2012-06-23 01:42:11', NULL, 187);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(266, NULL, NULL, NULL, NULL, 264, NULL, '1041', NULL, NULL, NULL, 'text', 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'true', NULL, '531', NULL, 'Chi147Val', NULL, '1.0', 'name', '?', '2012-05-11 08:49:23', 'admin', 'admin', '2012-06-20 23:46:51', NULL, 266);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(273, NULL, NULL, NULL, NULL, 271, NULL, '1041', NULL, NULL, NULL, 'text', 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'true', NULL, '531', NULL, 'Chi153Val', NULL, '1.0', 'title', '?', '2012-05-11 08:49:24', 'admin', 'admin', '2012-06-23 00:23:38', NULL, 273);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(280, NULL, NULL, NULL, NULL, 278, NULL, '1041', NULL, NULL, NULL, 'text', 'DATATYPE_ATTRIBUTE', 'DATETIME', 'false', NULL, '530', NULL, 'Chi159Val', NULL, '1.0', 'created', NULL, '2012-05-11 08:49:25', 'admin', 'admin', '2012-06-22 23:56:21', NULL, 280);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(281, NULL, NULL, NULL, NULL, 278, NULL, '1041', NULL, NULL, NULL, 'text', 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '531', NULL, 'Chi160Val', NULL, '1.0', 'creator', '?', '2012-05-11 08:49:25', 'admin', 'admin', '2012-06-22 23:56:13', NULL, 281);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(282, NULL, NULL, NULL, NULL, 278, NULL, '1041', NULL, NULL, NULL, 'text', 'DATATYPE_ATTRIBUTE', 'DATETIME', 'false', NULL, '530', NULL, 'Chi161Val', NULL, '1.0', 'modified', '?', '2012-05-11 08:49:25', 'admin', 'admin', '2012-06-22 23:56:14', NULL, 282);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(283, NULL, NULL, NULL, NULL, 278, NULL, '1041', NULL, NULL, NULL, 'text', 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '531', NULL, 'Chi162Val', NULL, '1.0', 'last_editor', '?', '2012-05-11 08:49:25', 'admin', 'admin', '2012-06-22 23:56:10', NULL, 283);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(287, NULL, NULL, NULL, NULL, 284, 'file', '1046', NULL, NULL, NULL, 'filebrowser', 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'true', NULL, '531', NULL, 'Chi165Val', NULL, '1.0', 'filename', '?', '2012-05-11 08:49:26', 'admin', 'admin', '2012-06-27 00:51:59', NULL, 287);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(297, NULL, NULL, NULL, NULL, 292, NULL, '1041', NULL, NULL, NULL, 'text', 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'true', NULL, '531', NULL, 'Chi174Val', NULL, '1.0', 'name', '?', '2012-05-11 08:49:28', 'admin', 'admin', '2012-06-20 23:46:25', NULL, 297);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(315, NULL, NULL, NULL, NULL, 313, NULL, '1041', NULL, NULL, NULL, 'text', 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '531', NULL, 'Chi188Val', NULL, '1.0', 'name', '?', '2012-05-11 08:49:30', 'admin', 'admin', '2012-06-23 00:43:30', NULL, 315);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(316, NULL, NULL, NULL, NULL, 313, NULL, NULL, NULL, NULL, NULL, 'text', 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '531', NULL, 'Chi189Val', NULL, '1.0', 'code', '?', '2012-05-11 08:49:30', 'admin', 'admin', '2012-06-23 00:43:56', NULL, 316);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(320, NULL, NULL, NULL, NULL, 317, NULL, '1041', NULL, NULL, NULL, 'text', 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '531', NULL, 'Chi192Val', NULL, '1.0', 'objectid', '?', '2012-05-11 08:49:31', 'admin', 'admin', '2012-06-23 00:38:45', NULL, 320);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(321, NULL, NULL, NULL, NULL, 317, NULL, '1041', NULL, NULL, NULL, 'text', 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '531', NULL, 'Chi193Val', NULL, '1.0', 'sessionid', '?', '2012-05-11 08:49:31', 'admin', 'admin', '2012-06-23 00:39:15', NULL, 321);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(322, NULL, NULL, NULL, NULL, 317, NULL, '1041', NULL, NULL, NULL, 'text', 'DATATYPE_ATTRIBUTE', 'DATETIME', 'false', NULL, '530', NULL, 'Chi194Val', NULL, '1.0', 'since', '?', '2012-05-11 08:49:31', 'admin', 'admin', '2012-06-23 00:39:50', NULL, 322);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(325, NULL, NULL, NULL, NULL, 323, NULL, '1041', NULL, NULL, NULL, 'text', 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'true', NULL, '531', NULL, 'Chi196Val', NULL, '1.0', 'name', '?', '2012-05-11 08:49:32', 'admin', 'admin', '2012-06-23 00:33:01', NULL, 325);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(328, NULL, NULL, NULL, NULL, 326, NULL, '1041', NULL, NULL, NULL, 'text', 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '531', NULL, 'Chi198Val', NULL, '1.0', 'objectid', 'The object id of the object to which the translation belongs', '2012-05-11 08:49:32', 'admin', 'admin', '2012-06-23 00:45:07', NULL, 328);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(329, NULL, NULL, NULL, NULL, 326, NULL, '1041', NULL, NULL, NULL, 'text', 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '531', NULL, 'Chi199Val', NULL, '1.0', 'attribute', 'The attribute of the object that is translated', '2012-05-11 08:49:32', 'admin', 'admin', '2012-06-23 00:46:19', NULL, 329);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(330, NULL, NULL, NULL, NULL, 326, NULL, '1041', NULL, NULL, NULL, 'textarea', 'DATATYPE_ATTRIBUTE', 'TEXT', 'false', NULL, '531', NULL, 'Chi200Val', NULL, '1.0', 'translation', 'The translation', '2012-05-11 08:49:32', 'admin', 'admin', '2012-06-23 00:47:08', NULL, 330);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(331, NULL, NULL, NULL, NULL, 326, NULL, '1041', NULL, NULL, NULL, 'text', 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '531', NULL, 'Chi201Val', NULL, '1.0', 'language', 'The language of the translation', '2012-05-11 08:49:32', 'admin', 'admin', '2012-06-23 00:47:27', NULL, 331);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(335, NULL, NULL, NULL, NULL, 332, NULL, '1041', NULL, NULL, NULL, 'text', 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '531', NULL, 'Chi204Val', NULL, '1.0', 'key', '?', '2012-05-11 08:49:33', 'admin', 'admin', '2012-06-23 00:41:04', NULL, 335);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(336, NULL, NULL, NULL, NULL, 332, NULL, '1041', NULL, NULL, NULL, 'text', 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'true', NULL, '531', NULL, 'Chi205Val', NULL, '1.0', 'val', '?', '2012-05-11 08:49:33', 'admin', 'admin', '2012-06-23 00:42:01', NULL, 336);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(339, NULL, NULL, NULL, NULL, 337, NULL, '1041', NULL, NULL, NULL, 'text', 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'true', NULL, '531', NULL, 'Chi207Val', NULL, '1.0', 'login', '?', '2012-05-11 08:49:34', 'admin', 'admin', '2012-06-23 00:34:45', NULL, 339);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(340, NULL, NULL, NULL, NULL, 337, NULL, '1041', NULL, NULL, NULL, 'password', 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'true', NULL, '531', NULL, 'Chi208Val', NULL, '1.0', 'password', '?', '2012-05-11 08:49:34', 'admin', 'admin', '2012-06-23 00:35:30', NULL, 340);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(341, NULL, NULL, NULL, NULL, 337, NULL, '1041', NULL, NULL, NULL, 'text', 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'true', NULL, '531', NULL, 'Chi209Val', NULL, '1.0', 'name', '?', '2012-05-11 08:49:34', 'admin', 'admin', '2012-06-23 00:36:07', NULL, 341);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(342, NULL, NULL, NULL, NULL, 337, NULL, '1041', NULL, NULL, NULL, 'text', 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'true', NULL, '531', NULL, 'Chi210Val', NULL, '1.0', 'firstname', '?', '2012-05-11 08:49:34', 'admin', 'admin', '2012-06-23 00:36:36', NULL, 342);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(343, NULL, NULL, NULL, NULL, 337, NULL, '1041', NULL, NULL, NULL, 'text', 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'true', NULL, '531', NULL, 'Chi211Val', NULL, '1.0', 'config', '?', '2012-05-11 08:49:34', 'admin', 'admin', '2012-06-23 00:37:05', NULL, 343);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(3909, NULL, 43, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', NULL, 'utf8', '531', NULL, 'Chi216Val', NULL, '1.0', 'dbCharSet', '?', '2012-06-26 00:00:15', 'admin', 'admin', '2012-06-26 00:00:48', NULL, 3909);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(4536, NULL, 72, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', NULL, 'UserRDB', '531', NULL, 'Chi217Val', NULL, '1.0', 'userType', '?', '2012-06-27 00:03:48', 'admin', 'admin', '2012-06-27 00:04:36', NULL, 4536);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(4547, NULL, 72, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', NULL, 'RoleRDB', '531', NULL, 'Chi218Val', NULL, '1.0', 'roleType', '?', '2012-06-27 00:04:31', 'admin', 'admin', '2012-06-27 00:05:09', NULL, 4547);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(4690, NULL, 4683, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', NULL, 'wcmf\\lib\\persistence\\concurrency\\ConcurrencyManager', NULL, NULL, 'Chi219Val', NULL, '1.0', '__class', '?', '2013-02-19 19:15:09', 'admin', 'admin', '2013-02-19 19:15:33', NULL, 4690);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(4698, NULL, 4683, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', NULL, '$lockHandler', NULL, NULL, 'Chi220Val', NULL, '1.0', 'lockHandler', '?', '2013-02-19 19:15:31', 'admin', 'admin', '2013-02-19 19:19:58', NULL, 4698);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(4967, NULL, NULL, NULL, NULL, 271, NULL, '1041', NULL, NULL, NULL, 'textarea', 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'true', NULL, '531', NULL, 'Chi221Val', NULL, '1.0', 'description', '?', '2013-02-20 23:53:51', 'admin', 'admin', '2013-02-21 21:34:50', NULL, 4967);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(4969, NULL, NULL, NULL, NULL, 271, NULL, '1041', NULL, NULL, NULL, 'date', 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'true', NULL, '530', NULL, 'Chi222Val', NULL, '1.0', 'year', '?', '2013-02-20 23:54:19', 'admin', 'admin', '2013-02-21 21:34:31', NULL, 4969);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(5123, NULL, NULL, NULL, NULL, 5113, NULL, '1041', NULL, NULL, NULL, 'text', 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'true', NULL, '531', NULL, 'Chi223Val', NULL, '1.0', 'name', '?', '2013-02-21 22:00:51', 'admin', 'admin', '2013-02-21 22:11:07', NULL, 5123);

-- --------------------------------------------------------

--
-- Table structure for table `ChiValueRef`
--

DROP TABLE IF EXISTS `ChiValueRef`;
CREATE TABLE IF NOT EXISTS `ChiValueRef` (
  `id` int(11) NOT NULL,
  `fk_chinodemanytomany_id` int(11) DEFAULT NULL,
  `fk_chivalue_id` int(11) DEFAULT NULL,
  `fk_chinode_id` int(11) DEFAULT NULL,
  `reference_type` varchar(255) DEFAULT NULL,
  `reference_value` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chinodemanytomany_id` (`fk_chinodemanytomany_id`),
  KEY `fk_chivalue_id` (`fk_chivalue_id`),
  KEY `fk_chinode_id` (`fk_chinode_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ChiValueRef`
--

INSERT INTO `ChiValueRef` (`id`, `fk_chinodemanytomany_id`, `fk_chivalue_id`, `fk_chinode_id`, `reference_type`, `reference_value`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(1247, NULL, NULL, 292, 'Author', 'name', 'author_name', '?', '2012-06-20 23:45:50', 'admin', 'admin', '2012-06-20 23:46:12', NULL, 1247);

-- --------------------------------------------------------

--
-- Table structure for table `ChiView`
--

DROP TABLE IF EXISTS `ChiView`;
CREATE TABLE IF NOT EXISTS `ChiView` (
  `id` int(11) NOT NULL,
  `fk_chinodemanytomany_id` int(11) DEFAULT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_chinode_id` int(11) DEFAULT NULL,
  `visibility` varchar(255) DEFAULT NULL,
  `isabstract` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chinodemanytomany_id` (`fk_chinodemanytomany_id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_chinode_id` (`fk_chinode_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ChiView`
--

INSERT INTO `ChiView` (`id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(234, NULL, 233, NULL, NULL, 'false', '350', 'Chi018View', '349', 'null', 'displayfailure', 'Displays a failure. Attached to FailureController.', 'null', 'null', 'admin', '2012-05-11 08:50:45', NULL, 234);
INSERT INTO `ChiView` (`id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(235, NULL, 233, NULL, NULL, 'false', '350', 'Chi019View', '349', 'null', 'displaynode', 'Displays the content of a Node. Attached to DisplayController.', 'null', 'null', 'admin', '2012-05-11 08:50:45', NULL, 235);
INSERT INTO `ChiView` (`id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(236, NULL, 233, NULL, NULL, 'false', '350', 'Chi020View', '349', 'null', 'elfinder', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:45', NULL, 236);
INSERT INTO `ChiView` (`id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(237, NULL, 233, NULL, NULL, 'false', '350', 'Chi021View', '349', 'null', 'frontend', 'Displays the content tree. Attached to TreeViewController.', 'null', 'null', 'admin', '2012-05-11 08:50:45', NULL, 237);
INSERT INTO `ChiView` (`id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(238, NULL, 233, NULL, NULL, 'false', '350', 'Chi022View', '349', 'null', 'login', 'Displays the login dialog. Attached to LoginController.', 'null', 'null', 'admin', '2012-05-11 08:50:46', NULL, 238);
INSERT INTO `ChiView` (`id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(239, NULL, 233, NULL, NULL, 'false', '350', 'Chi023View', '349', 'null', 'model', 'Displays the content tree. Attached to TreeViewController.', 'null', 'null', 'admin', '2012-05-11 08:50:46', NULL, 239);
INSERT INTO `ChiView` (`id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(240, NULL, 233, NULL, NULL, 'false', '350', 'Chi024View', '349', 'null', 'nodelist', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:46', NULL, 240);
INSERT INTO `ChiView` (`id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(241, NULL, 233, NULL, NULL, 'false', '350', 'Chi025View', '349', 'null', 'progressbar', 'Displays a progress bar. Attached to LongTaskController.', 'null', 'null', 'admin', '2012-05-11 08:50:46', NULL, 241);
INSERT INTO `ChiView` (`id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(242, NULL, 233, NULL, NULL, 'false', '350', 'Chi026View', '349', 'null', 'resourcetree', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:46', NULL, 242);
INSERT INTO `ChiView` (`id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(243, NULL, 233, NULL, NULL, 'false', '350', 'Chi027View', '349', 'null', 'treeview', 'Displays the content tree. Attached to TreeViewController.', 'null', 'null', 'admin', '2012-05-11 08:50:47', NULL, 243);
INSERT INTO `ChiView` (`id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(244, NULL, 233, NULL, NULL, 'false', '350', 'Chi028View', '349', 'null', 'user', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:47', NULL, 244);
INSERT INTO `ChiView` (`id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(246, NULL, 245, NULL, NULL, 'false', '350', 'Chi029View', '349', 'null', 'config', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:47', NULL, 246);
INSERT INTO `ChiView` (`id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(247, NULL, 245, NULL, NULL, 'false', '350', 'Chi030View', '349', 'null', 'overview', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:48', NULL, 247);
INSERT INTO `ChiView` (`id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(248, NULL, 245, NULL, NULL, 'false', '350', 'Chi031View', '349', 'null', 'rights', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:48', NULL, 248);
INSERT INTO `ChiView` (`id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(249, NULL, 245, NULL, NULL, 'false', '350', 'Chi032View', '349', 'null', 'role', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:48', NULL, 249);
INSERT INTO `ChiView` (`id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(250, NULL, 245, NULL, NULL, 'false', '350', 'Chi033View', '349', 'null', 'user', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:48', NULL, 250);
INSERT INTO `ChiView` (`id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(252, NULL, 251, NULL, NULL, 'false', '350', 'Chi034View', '349', 'null', 'textilepreview', 'Displays a failure. Attached to FailureController.', 'null', 'null', 'admin', '2012-05-11 08:50:49', NULL, 252);

-- --------------------------------------------------------

--
-- Table structure for table `ChiWorker`
--

DROP TABLE IF EXISTS `ChiWorker`;
CREATE TABLE IF NOT EXISTS `ChiWorker` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ChiWorkerExternal`
--

DROP TABLE IF EXISTS `ChiWorkerExternal`;
CREATE TABLE IF NOT EXISTS `ChiWorkerExternal` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_chiworkerexternal_id` int(11) DEFAULT NULL,
  `is_offlineuser` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_chiworkerexternal_id` (`fk_chiworkerexternal_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ChiWorkerInternal`
--

DROP TABLE IF EXISTS `ChiWorkerInternal`;
CREATE TABLE IF NOT EXISTS `ChiWorkerInternal` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_chiworkerinternal_id` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_chiworkerinternal_id` (`fk_chiworkerinternal_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ControlFlow`
--

DROP TABLE IF EXISTS `ControlFlow`;
CREATE TABLE IF NOT EXISTS `ControlFlow` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fk_activityfinal_id` int(11) DEFAULT NULL,
  `fk_activityinitial_id` int(11) DEFAULT NULL,
  `fk_ascontrolflowsource_id` int(11) DEFAULT NULL,
  `fk_ascontrolflowtarget_id` int(11) DEFAULT NULL,
  `fk_arcontrolflowsource_id` int(11) DEFAULT NULL,
  `fk_arcontrolflowtarget_id` int(11) DEFAULT NULL,
  `fk_adcontrolflowtarget_id` int(11) DEFAULT NULL,
  `fk_adcontrolflowsource_id` int(11) DEFAULT NULL,
  `fk_acontrolflowsource_id` int(11) DEFAULT NULL,
  `fk_acontrolflowtarget_id` int(11) DEFAULT NULL,
  `guard` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_activityfinal_id` (`fk_activityfinal_id`),
  KEY `fk_activityinitial_id` (`fk_activityinitial_id`),
  KEY `fk_ascontrolflowsource_id` (`fk_ascontrolflowsource_id`),
  KEY `fk_ascontrolflowtarget_id` (`fk_ascontrolflowtarget_id`),
  KEY `fk_arcontrolflowsource_id` (`fk_arcontrolflowsource_id`),
  KEY `fk_arcontrolflowtarget_id` (`fk_arcontrolflowtarget_id`),
  KEY `fk_adcontrolflowtarget_id` (`fk_adcontrolflowtarget_id`),
  KEY `fk_adcontrolflowsource_id` (`fk_adcontrolflowsource_id`),
  KEY `fk_acontrolflowsource_id` (`fk_acontrolflowsource_id`),
  KEY `fk_acontrolflowtarget_id` (`fk_acontrolflowtarget_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `Counter`
--

DROP TABLE IF EXISTS `Counter`;
CREATE TABLE IF NOT EXISTS `Counter` (
  `id` int(11) NOT NULL,
  `activity` varchar(255) DEFAULT NULL,
  `activitydecision` varchar(255) DEFAULT NULL,
  `activityfinal` varchar(255) DEFAULT NULL,
  `activityinitial` varchar(255) DEFAULT NULL,
  `activityreceive` varchar(255) DEFAULT NULL,
  `activitysend` varchar(255) DEFAULT NULL,
  `chibusinesspartner` varchar(255) DEFAULT NULL,
  `chibusinesspartneractive` varchar(255) DEFAULT NULL,
  `chibusinesspartnerpassive` varchar(255) DEFAULT NULL,
  `chibusinessprocess` varchar(255) DEFAULT NULL,
  `chibusinessusecase` varchar(255) DEFAULT NULL,
  `chibusinessusecasecore` varchar(255) DEFAULT NULL,
  `chicontroller` varchar(255) DEFAULT NULL,
  `chifeature` varchar(255) DEFAULT NULL,
  `chigoal` varchar(255) DEFAULT NULL,
  `chiissue` varchar(255) DEFAULT NULL,
  `chinode` varchar(255) DEFAULT NULL,
  `chirequirement` varchar(255) DEFAULT NULL,
  `chisystem` varchar(255) DEFAULT NULL,
  `chivalue` varchar(255) DEFAULT NULL,
  `chiview` varchar(255) DEFAULT NULL,
  `chiworker` varchar(255) DEFAULT NULL,
  `chiworkerexternal` varchar(255) DEFAULT NULL,
  `chiworkerinternal` varchar(255) DEFAULT NULL,
  `operation` varchar(255) DEFAULT NULL,
  `diagram` varchar(255) DEFAULT NULL,
  `activityset` varchar(255) DEFAULT NULL,
  `productionruleset` varchar(255) DEFAULT NULL,
  `productionrule` varchar(255) DEFAULT NULL,
  `rulesetvariable` varchar(255) DEFAULT NULL,
  `rulevariable` varchar(255) DEFAULT NULL,
  `rulecondition` varchar(255) DEFAULT NULL,
  `ruleaction` varchar(255) DEFAULT NULL,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Counter`
--

INSERT INTO `Counter` (`id`, `activity`, `activitydecision`, `activityfinal`, `activityinitial`, `activityreceive`, `activitysend`, `chibusinesspartner`, `chibusinesspartneractive`, `chibusinesspartnerpassive`, `chibusinessprocess`, `chibusinessusecase`, `chibusinessusecasecore`, `chicontroller`, `chifeature`, `chigoal`, `chiissue`, `chinode`, `chirequirement`, `chisystem`, `chivalue`, `chiview`, `chiworker`, `chiworkerexternal`, `chiworkerinternal`, `operation`, `diagram`, `activityset`, `productionruleset`, `productionrule`, `rulesetvariable`, `rulevariable`, `rulecondition`, `ruleaction`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '85', NULL, NULL, NULL, '222', NULL, '113', '223', '34', NULL, NULL, NULL, NULL, '9', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'admin', '2013-02-21 22:00:52', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `dbupdate`
--

DROP TABLE IF EXISTS `dbupdate`;
CREATE TABLE IF NOT EXISTS `dbupdate` (
  `table_id` varchar(100) NOT NULL,
  `column_id` varchar(100) NOT NULL,
  `type` varchar(100) NOT NULL,
  `table` varchar(255) DEFAULT NULL,
  `column` varchar(255) DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`table_id`,`column_id`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Diagram`
--

DROP TABLE IF EXISTS `Diagram`;
CREATE TABLE IF NOT EXISTS `Diagram` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `width` varchar(255) DEFAULT NULL,
  `height` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Diagram`
--

INSERT INTO `Diagram` (`id`, `fk_package_id`, `width`, `height`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(586, 8, NULL, NULL, NULL, 'Chi002Dia', NULL, '1.0', 'config.ini', '?', NULL, NULL, 'admin', '2012-06-23 00:48:13', NULL, NULL);
INSERT INTO `Diagram` (`id`, `fk_package_id`, `width`, `height`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(701, 263, NULL, NULL, NULL, 'Chi003Dia', NULL, '1.0', 'model', '?', NULL, NULL, 'admin', '2013-02-21 22:13:33', NULL, 1);
INSERT INTO `Diagram` (`id`, `fk_package_id`, `width`, `height`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(1708, 310, NULL, NULL, NULL, 'Chi004Dia', NULL, '1.0', 'wcmf', '?', NULL, NULL, 'admin', '2012-06-23 23:49:53', NULL, NULL);
INSERT INTO `Diagram` (`id`, `fk_package_id`, `width`, `height`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(2407, 39, NULL, NULL, NULL, 'Chi005Dia', NULL, '1.0', 'admin.ini', '?', NULL, NULL, 'admin', '2012-06-25 23:59:50', NULL, NULL);
INSERT INTO `Diagram` (`id`, `fk_package_id`, `width`, `height`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(2424, 42, NULL, NULL, NULL, 'Chi006Dia', NULL, '1.0', 'server.ini', '?', NULL, NULL, 'admin', '2012-06-25 23:59:59', NULL, NULL);
INSERT INTO `Diagram` (`id`, `fk_package_id`, `width`, `height`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(2539, 59, NULL, NULL, NULL, 'Chi007Dia', NULL, '1.0', 'persistence.ini', '?', NULL, NULL, 'admin', '2012-06-26 00:01:07', NULL, NULL);
INSERT INTO `Diagram` (`id`, `fk_package_id`, `width`, `height`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(2637, 74, NULL, NULL, NULL, 'Chi008Dia', NULL, '1.0', 'presentation.ini', '?', NULL, NULL, 'admin', '2012-06-23 01:54:02', NULL, NULL);
INSERT INTO `Diagram` (`id`, `fk_package_id`, `width`, `height`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(4733, 260, NULL, NULL, NULL, 'Chi009Dia', NULL, '1.0', 'backend', '?', '2013-02-20 13:54:43', 'admin', 'admin', '2013-02-20 13:55:14', NULL, 4733);

-- --------------------------------------------------------

--
-- Table structure for table `DisplayType`
--

DROP TABLE IF EXISTS `DisplayType`;
CREATE TABLE IF NOT EXISTS `DisplayType` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `DisplayType`
--

INSERT INTO `DisplayType` (`id`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(1041, 'text', '?', '2012-06-19 00:41:32', 'admin', 'admin', '2012-06-19 00:41:50', NULL);
INSERT INTO `DisplayType` (`id`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(1046, 'image', '?', '2012-06-19 00:41:47', 'admin', 'admin', '2012-06-19 00:42:02', NULL);
INSERT INTO `DisplayType` (`id`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(1052, 'link', '?', '2012-06-19 00:41:56', 'admin', 'admin', '2012-06-19 00:42:20', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Figure`
--

DROP TABLE IF EXISTS `Figure`;
CREATE TABLE IF NOT EXISTS `Figure` (
  `id` int(11) NOT NULL,
  `fk_chiobject_id` int(11) DEFAULT NULL,
  `fk_activity_id` int(11) DEFAULT NULL,
  `fk_activitydecision_id` int(11) DEFAULT NULL,
  `fk_activityreceive_id` int(11) DEFAULT NULL,
  `fk_activitysend_id` int(11) DEFAULT NULL,
  `fk_activityinitial_id` int(11) DEFAULT NULL,
  `fk_activityfinal_id` int(11) DEFAULT NULL,
  `fk_chisystem_id` int(11) DEFAULT NULL,
  `fk_productionrule_id` int(11) DEFAULT NULL,
  `fk_productionruleset_id` int(11) DEFAULT NULL,
  `fk_ruleaction_id` int(11) DEFAULT NULL,
  `fk_rulecondition_id` int(11) DEFAULT NULL,
  `fk_rulesetvariable_id` int(11) DEFAULT NULL,
  `fk_rulevariable_id` int(11) DEFAULT NULL,
  `fk_chiworkerexternal_id` int(11) DEFAULT NULL,
  `fk_chiworkerinternal_id` int(11) DEFAULT NULL,
  `fk_chiworker_id` int(11) DEFAULT NULL,
  `fk_chibusinesspartneractive_id` int(11) DEFAULT NULL,
  `fk_chibusinesspartnerpassive_id` int(11) DEFAULT NULL,
  `fk_chibusinesspartner_id` int(11) DEFAULT NULL,
  `fk_actor_id` int(11) DEFAULT NULL,
  `fk_chibusinessprocess_id` int(11) DEFAULT NULL,
  `fk_chibusinessusecasecore_id` int(11) DEFAULT NULL,
  `fk_chibusinessusecase_id` int(11) DEFAULT NULL,
  `fk_chigoal_id` int(11) DEFAULT NULL,
  `fk_chirequirement_id` int(11) DEFAULT NULL,
  `fk_chifeature_id` int(11) DEFAULT NULL,
  `fk_chiissue_id` int(11) DEFAULT NULL,
  `fk_operation_id` int(11) DEFAULT NULL,
  `fk_chinodemanytomany_id` int(11) DEFAULT NULL,
  `fk_chinode_id` int(11) DEFAULT NULL,
  `fk_chicontroller_id` int(11) DEFAULT NULL,
  `fk_chiview_id` int(11) DEFAULT NULL,
  `fk_chiclass_id` int(11) DEFAULT NULL,
  `fk_feature_id` int(11) DEFAULT NULL,
  `fk_chivalue_id` int(11) DEFAULT NULL,
  `fk_property_id` int(11) DEFAULT NULL,
  `fk_glossary_id` int(11) DEFAULT NULL,
  `fk_diagram_id` int(11) DEFAULT NULL,
  `fk_chibase_id` int(11) DEFAULT NULL,
  `fk_activityset_id` int(11) DEFAULT NULL,
  `backgroundcolor` varchar(255) DEFAULT NULL,
  `foregroundcolor` varchar(255) DEFAULT NULL,
  `gid` varchar(255) DEFAULT NULL,
  `height` varchar(255) DEFAULT NULL,
  `positionx` varchar(255) DEFAULT NULL,
  `positiony` varchar(255) DEFAULT NULL,
  `showinheritedattributes` varchar(255) DEFAULT NULL,
  `width` varchar(255) DEFAULT NULL,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chiobject_id` (`fk_chiobject_id`),
  KEY `fk_activity_id` (`fk_activity_id`),
  KEY `fk_activitydecision_id` (`fk_activitydecision_id`),
  KEY `fk_activityreceive_id` (`fk_activityreceive_id`),
  KEY `fk_activitysend_id` (`fk_activitysend_id`),
  KEY `fk_activityinitial_id` (`fk_activityinitial_id`),
  KEY `fk_activityfinal_id` (`fk_activityfinal_id`),
  KEY `fk_chisystem_id` (`fk_chisystem_id`),
  KEY `fk_productionrule_id` (`fk_productionrule_id`),
  KEY `fk_productionruleset_id` (`fk_productionruleset_id`),
  KEY `fk_ruleaction_id` (`fk_ruleaction_id`),
  KEY `fk_rulecondition_id` (`fk_rulecondition_id`),
  KEY `fk_rulesetvariable_id` (`fk_rulesetvariable_id`),
  KEY `fk_rulevariable_id` (`fk_rulevariable_id`),
  KEY `fk_chiworkerexternal_id` (`fk_chiworkerexternal_id`),
  KEY `fk_chiworkerinternal_id` (`fk_chiworkerinternal_id`),
  KEY `fk_chiworker_id` (`fk_chiworker_id`),
  KEY `fk_chibusinesspartneractive_id` (`fk_chibusinesspartneractive_id`),
  KEY `fk_chibusinesspartnerpassive_id` (`fk_chibusinesspartnerpassive_id`),
  KEY `fk_chibusinesspartner_id` (`fk_chibusinesspartner_id`),
  KEY `fk_actor_id` (`fk_actor_id`),
  KEY `fk_chibusinessprocess_id` (`fk_chibusinessprocess_id`),
  KEY `fk_chibusinessusecasecore_id` (`fk_chibusinessusecasecore_id`),
  KEY `fk_chibusinessusecase_id` (`fk_chibusinessusecase_id`),
  KEY `fk_chigoal_id` (`fk_chigoal_id`),
  KEY `fk_chirequirement_id` (`fk_chirequirement_id`),
  KEY `fk_chifeature_id` (`fk_chifeature_id`),
  KEY `fk_chiissue_id` (`fk_chiissue_id`),
  KEY `fk_operation_id` (`fk_operation_id`),
  KEY `fk_chinodemanytomany_id` (`fk_chinodemanytomany_id`),
  KEY `fk_chinode_id` (`fk_chinode_id`),
  KEY `fk_chicontroller_id` (`fk_chicontroller_id`),
  KEY `fk_chiview_id` (`fk_chiview_id`),
  KEY `fk_chiclass_id` (`fk_chiclass_id`),
  KEY `fk_feature_id` (`fk_feature_id`),
  KEY `fk_chivalue_id` (`fk_chivalue_id`),
  KEY `fk_property_id` (`fk_property_id`),
  KEY `fk_glossary_id` (`fk_glossary_id`),
  KEY `fk_diagram_id` (`fk_diagram_id`),
  KEY `fk_chibase_id` (`fk_chibase_id`),
  KEY `fk_activityset_id` (`fk_activityset_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Figure`
--

INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(587, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 9, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 586, NULL, NULL, NULL, NULL, NULL, '50', '5024', '5023', NULL, '50', NULL, NULL, 'admin', '2012-06-23 00:48:48', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(588, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 11, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 586, NULL, NULL, NULL, NULL, NULL, '50', '5192', '5021', NULL, '50', NULL, NULL, 'admin', '2012-06-23 00:48:41', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(589, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 13, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 586, NULL, NULL, NULL, NULL, NULL, '50', '5364', '5022', NULL, '50', NULL, NULL, 'admin', '2012-05-11 08:52:06', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(590, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 14, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 586, NULL, NULL, NULL, NULL, NULL, '50', '5363', '5101', NULL, '50', NULL, NULL, 'admin', '2012-05-11 08:52:10', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(591, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 15, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 586, NULL, NULL, NULL, NULL, NULL, '161', '5363', '5178', NULL, '150', NULL, NULL, 'admin', '2012-06-23 00:57:58', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(592, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 23, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 586, NULL, NULL, NULL, NULL, NULL, '50', '5363', '5349', NULL, '50', NULL, NULL, 'admin', '2012-06-23 01:03:18', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(593, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 25, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 586, NULL, NULL, NULL, NULL, NULL, '50', '5529', '5022', NULL, '50', NULL, NULL, 'admin', '2012-06-24 02:23:58', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(594, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 27, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 586, NULL, NULL, NULL, NULL, NULL, '50', '5528', '5112', NULL, '50', NULL, NULL, 'admin', '2012-06-24 02:24:38', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(595, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 28, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 586, NULL, NULL, NULL, NULL, NULL, '50', '5528', '5187', NULL, '50', NULL, NULL, 'admin', '2012-06-24 02:24:55', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(596, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 586, NULL, NULL, NULL, NULL, NULL, '50', '5363', '5441', NULL, '50', NULL, NULL, 'admin', '2012-06-23 01:03:22', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(597, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 36, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 586, NULL, NULL, NULL, NULL, NULL, '50', '5024', '5130', NULL, '50', NULL, NULL, 'admin', '2012-06-23 00:54:30', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(702, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 701, NULL, NULL, NULL, NULL, NULL, '50', '5150', '5050', NULL, '50', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(703, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 264, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 701, NULL, NULL, NULL, NULL, NULL, '81', '5001', '5097', NULL, '150', NULL, NULL, 'admin', '2013-02-21 21:50:09', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(704, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 271, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 701, NULL, NULL, NULL, NULL, NULL, '161', '5361', '5290', NULL, '150', NULL, NULL, 'admin', '2013-02-21 21:40:13', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(705, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 278, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 701, NULL, NULL, NULL, NULL, NULL, '140', '5312', '4955', NULL, '150', NULL, NULL, 'admin', '2012-06-23 00:21:23', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(706, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 284, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 701, NULL, NULL, NULL, NULL, NULL, '81', '5030', '5589', NULL, '150', NULL, NULL, 'admin', '2013-02-21 21:39:28', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(707, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 292, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 701, NULL, NULL, NULL, NULL, NULL, '117', '5012', '5307', NULL, '150', NULL, NULL, 'admin', '2013-02-21 21:36:57', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(4438, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4437, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 701, NULL, NULL, NULL, NULL, NULL, '95', '5039', '4947', NULL, '96', '2012-06-27 00:01:53', 'admin', 'admin', '2013-02-21 21:50:53', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(1709, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 311, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1708, NULL, NULL, NULL, NULL, NULL, '65', '5513', '5388', NULL, '150', NULL, NULL, 'admin', '2012-06-23 00:44:23', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(1710, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 313, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1708, NULL, NULL, NULL, NULL, NULL, '97', '5515', '5468', NULL, '150', NULL, NULL, 'admin', '2012-06-23 00:42:53', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(1711, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 317, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1708, NULL, NULL, NULL, NULL, NULL, '50', '5291', '5213', NULL, '50', NULL, NULL, 'admin', '2012-06-23 00:37:23', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(1712, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 323, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1708, NULL, NULL, NULL, NULL, NULL, '81', '5523', '5060', NULL, '150', NULL, NULL, 'admin', '2012-06-23 00:31:57', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(1713, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 326, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1708, NULL, NULL, NULL, NULL, NULL, '129', '5516', '5581', NULL, '150', NULL, NULL, 'admin', '2012-06-23 00:44:29', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(1714, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 332, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1708, NULL, NULL, NULL, NULL, NULL, '50', '5210', '5367', NULL, '50', NULL, NULL, 'admin', '2012-06-23 00:30:08', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(1715, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 337, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1708, NULL, NULL, NULL, NULL, NULL, '50', '5009', '5050', NULL, '50', NULL, NULL, 'admin', '2012-06-23 00:29:55', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(4269, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4268, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1708, NULL, NULL, NULL, NULL, NULL, '95', '5284', '5033', NULL, '96', '2012-06-26 23:29:17', 'admin', 'admin', '2012-06-26 23:29:22', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2408, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 40, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2407, NULL, NULL, NULL, NULL, NULL, '50', '5150', '5050', NULL, '50', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2425, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 43, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2424, NULL, NULL, NULL, NULL, NULL, '161', '5055', '5052', NULL, '150', NULL, NULL, 'admin', '2012-06-26 00:00:16', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2426, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 49, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2424, NULL, NULL, NULL, NULL, NULL, '50', '5055', '5226', NULL, '50', NULL, NULL, 'admin', '2012-06-26 00:00:50', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2427, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 51, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2424, NULL, NULL, NULL, NULL, NULL, '50', '5222', '5054', NULL, '50', NULL, NULL, 'admin', '2012-06-23 01:20:17', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2428, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 54, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2424, NULL, NULL, NULL, NULL, NULL, '50', '5224', '5197', NULL, '50', NULL, NULL, 'admin', '2012-06-23 01:20:22', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2429, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 57, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2424, NULL, NULL, NULL, NULL, NULL, '50', '5421', '5054', NULL, '50', NULL, NULL, 'admin', '2012-06-23 01:20:35', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2430, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 58, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2424, NULL, NULL, NULL, NULL, NULL, '50', '5422', '5132', NULL, '50', NULL, NULL, 'admin', '2012-06-23 01:20:39', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2540, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 60, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2539, NULL, NULL, NULL, NULL, NULL, '50', '5034', '5034', NULL, '50', NULL, NULL, 'admin', '2012-06-23 01:25:10', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2541, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 65, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2539, NULL, NULL, NULL, NULL, NULL, '50', '5036', '5177', NULL, '50', NULL, NULL, 'admin', '2012-06-23 01:25:15', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2542, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2539, NULL, NULL, NULL, NULL, NULL, '50', '5208', '5035', NULL, '50', NULL, NULL, 'admin', '2012-06-23 01:25:19', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2543, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 69, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2539, NULL, NULL, NULL, NULL, NULL, '50', '5209', '5130', NULL, '50', NULL, NULL, 'admin', '2012-06-23 01:25:24', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2544, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 70, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2539, NULL, NULL, NULL, NULL, NULL, '50', '5210', '5209', NULL, '50', NULL, NULL, 'admin', '2012-06-23 01:25:28', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2545, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 72, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2539, NULL, NULL, NULL, NULL, NULL, '113', '5374', '5035', NULL, '150', NULL, NULL, 'admin', '2012-06-27 00:04:38', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2638, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 75, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2637, NULL, NULL, NULL, NULL, NULL, '50', '5027', '5026', NULL, '50', NULL, NULL, 'admin', '2012-06-26 00:06:12', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2639, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 83, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2637, NULL, NULL, NULL, NULL, NULL, '50', '5029', '5216', NULL, '50', NULL, NULL, 'admin', '2012-06-23 01:32:54', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2640, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 88, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2637, NULL, NULL, NULL, NULL, NULL, '50', '5031', '5357', NULL, '50', NULL, NULL, 'admin', '2012-06-23 01:33:43', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2641, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 90, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2637, NULL, NULL, NULL, NULL, NULL, '50', '5032', '5449', NULL, '50', NULL, NULL, 'admin', '2012-06-23 01:33:52', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2642, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 92, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2637, NULL, NULL, NULL, NULL, NULL, '50', '5033', '5543', NULL, '50', NULL, NULL, 'admin', '2012-06-23 01:33:58', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2643, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 94, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2637, NULL, NULL, NULL, NULL, NULL, '50', '5035', '5636', NULL, '50', NULL, NULL, 'admin', '2012-06-23 01:34:04', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2644, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 96, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2637, NULL, NULL, NULL, NULL, NULL, '50', '5192', '5026', NULL, '50', NULL, NULL, 'admin', '2012-06-23 02:11:04', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2645, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 102, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2637, NULL, NULL, NULL, NULL, NULL, '50', '5194', '5183', NULL, '50', NULL, NULL, 'admin', '2012-06-23 01:35:37', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2646, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 104, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2637, NULL, NULL, NULL, NULL, NULL, '50', '5195', '5274', NULL, '50', NULL, NULL, 'admin', '2012-06-23 01:35:52', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2647, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 106, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2637, NULL, NULL, NULL, NULL, NULL, '50', '5196', '5366', NULL, '50', NULL, NULL, 'admin', '2012-06-23 01:36:14', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2648, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 108, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2637, NULL, NULL, NULL, NULL, NULL, '50', '5198', '5456', NULL, '50', NULL, NULL, 'admin', '2012-06-23 01:36:25', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2649, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 110, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2637, NULL, NULL, NULL, NULL, NULL, '50', '5197', '5549', NULL, '50', NULL, NULL, 'admin', '2012-06-23 01:36:32', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2650, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 112, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2637, NULL, NULL, NULL, NULL, NULL, '50', '5359', '5027', NULL, '50', NULL, NULL, 'admin', '2012-06-23 01:36:46', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2651, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 115, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2637, NULL, NULL, NULL, NULL, NULL, '50', '5358', '5136', NULL, '50', NULL, NULL, 'admin', '2012-06-23 01:36:58', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2652, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 119, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2637, NULL, NULL, NULL, NULL, NULL, '50', '5359', '5258', NULL, '50', NULL, NULL, 'admin', '2012-06-23 01:37:06', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2653, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 122, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2637, NULL, NULL, NULL, NULL, NULL, '50', '5359', '5366', NULL, '50', NULL, NULL, 'admin', '2012-06-23 01:37:12', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2654, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 125, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2637, NULL, NULL, NULL, NULL, NULL, '50', '5359', '5472', NULL, '50', NULL, NULL, 'admin', '2012-06-23 01:37:21', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2655, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 128, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2637, NULL, NULL, NULL, NULL, NULL, '50', '5523', '5026', NULL, '50', NULL, NULL, 'admin', '2012-06-23 01:37:46', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2656, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 132, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2637, NULL, NULL, NULL, NULL, NULL, '50', '5523', '5149', NULL, '50', NULL, NULL, 'admin', '2012-06-23 01:38:05', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2657, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 146, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2637, NULL, NULL, NULL, NULL, NULL, '50', '5688', '5026', NULL, '50', NULL, NULL, 'admin', '2012-06-23 01:38:14', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2658, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 149, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2637, NULL, NULL, NULL, NULL, NULL, '50', '5688', '5132', NULL, '50', NULL, NULL, 'admin', '2012-06-23 01:38:29', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2659, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 152, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2637, NULL, NULL, NULL, NULL, NULL, '50', '5688', '5238', NULL, '50', NULL, NULL, 'admin', '2012-06-23 01:38:52', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2660, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 155, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2637, NULL, NULL, NULL, NULL, NULL, '50', '5689', '5344', NULL, '50', NULL, NULL, 'admin', '2012-06-23 01:39:00', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2661, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 158, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2637, NULL, NULL, NULL, NULL, NULL, '50', '5689', '5449', NULL, '50', NULL, NULL, 'admin', '2012-06-23 01:39:16', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2662, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 161, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2637, NULL, NULL, NULL, NULL, NULL, '50', '5689', '5556', NULL, '50', NULL, NULL, 'admin', '2012-06-23 01:51:30', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2663, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 164, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2637, NULL, NULL, NULL, NULL, NULL, '50', '5853', '5027', NULL, '50', NULL, NULL, 'admin', '2012-06-23 01:39:46', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2664, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 168, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2637, NULL, NULL, NULL, NULL, NULL, '50', '5853', '5148', NULL, '50', NULL, NULL, 'admin', '2012-06-23 01:40:09', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2665, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 172, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2637, NULL, NULL, NULL, NULL, NULL, '50', '5856', '5272', NULL, '50', NULL, NULL, 'admin', '2012-06-23 01:40:17', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2666, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 176, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2637, NULL, NULL, NULL, NULL, NULL, '50', '5857', '5396', NULL, '50', NULL, NULL, 'admin', '2012-06-23 01:40:27', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2667, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 179, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2637, NULL, NULL, NULL, NULL, NULL, '50', '5859', '5505', NULL, '50', NULL, NULL, 'admin', '2012-06-23 01:43:06', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2668, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 182, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2637, NULL, NULL, NULL, NULL, NULL, '50', '5861', '5613', NULL, '50', NULL, NULL, 'admin', '2012-06-23 01:42:11', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2669, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 185, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2637, NULL, NULL, NULL, NULL, NULL, '50', '5863', '5722', NULL, '50', NULL, NULL, 'admin', '2012-06-23 01:40:43', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(4406, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4384, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1708, NULL, NULL, NULL, NULL, NULL, '95', '5048', '4932', NULL, '96', '2012-06-26 23:53:01', 'admin', 'admin', '2012-06-26 23:53:05', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(4412, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4398, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1708, NULL, NULL, NULL, NULL, NULL, '95', '5547', '4931', NULL, '96', '2012-06-26 23:53:08', 'admin', 'admin', '2012-06-26 23:53:25', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(4684, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4683, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2539, NULL, NULL, NULL, NULL, NULL, '97', '5036', '5276', NULL, '150', '2013-02-19 19:14:55', 'admin', 'admin', '2013-02-19 19:15:34', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(4861, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 206, NULL, NULL, NULL, NULL, NULL, NULL, 4733, NULL, NULL, NULL, NULL, NULL, '95', '5147', '5234', NULL, '96', '2013-02-20 14:55:26', 'admin', 'admin', '2013-02-20 14:55:30', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(4750, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 257, NULL, NULL, NULL, NULL, NULL, NULL, 4733, NULL, NULL, NULL, NULL, NULL, '95', '5178', '5057', NULL, '96', '2013-02-20 13:55:37', 'admin', 'admin', '2013-02-20 13:55:38', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(4830, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 198, NULL, NULL, NULL, NULL, NULL, NULL, 4733, NULL, NULL, NULL, NULL, NULL, '95', '5406', '5233', NULL, '96', '2013-02-20 14:47:19', 'admin', 'admin', '2013-02-20 14:47:26', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(5114, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 5113, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 701, NULL, NULL, NULL, NULL, NULL, '81', '4824', '4976', NULL, '150', '2013-02-21 21:50:57', 'admin', 'admin', '2013-02-21 22:02:00', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Glossary`
--

DROP TABLE IF EXISTS `Glossary`;
CREATE TABLE IF NOT EXISTS `Glossary` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `entrytype` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `History`
--

DROP TABLE IF EXISTS `History`;
CREATE TABLE IF NOT EXISTS `History` (
  `id` int(11) NOT NULL,
  `data` text,
  `duplicate` tinyint(1) DEFAULT NULL,
  `eventtype` enum('create','delete','changeProperty','associate','disassociate') DEFAULT NULL,
  `affectedoid` varchar(255) DEFAULT NULL,
  `otheroid` varchar(255) DEFAULT NULL,
  `timestamp` bigint(20) DEFAULT NULL,
  `user` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `History`
--

INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5323, 'a:1:{i:0;a:1:{s:10:"sourceName";a:2:{s:8:"oldValue";N;s:8:"newValue";s:13:"ParentChapter";}}}', NULL, 'changeProperty', 'ChiAssociation:541', NULL, 1361488582643060, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5319, 'a:1:{i:0;a:1:{s:7:"fk_name";a:2:{s:8:"oldValue";s:10:"fk_page_id";s:8:"newValue";s:13:"fk_chapter_id";}}}', NULL, 'changeProperty', 'ChiAssociation:544', NULL, 1361487832783856, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5322, 'a:1:{i:0;a:1:{s:7:"fk_name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:13:"fk_chapter_id";}}}', NULL, 'changeProperty', 'ChiAssociation:541', NULL, 1361488558748400, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5311, 'a:1:{i:0;a:1:{s:10:"sourceName";a:2:{s:8:"oldValue";s:10:"NormalPage";s:8:"newValue";s:13:"NormalChapter";}}}', NULL, 'changeProperty', 'ChiAssociation:544', NULL, 1361486445494643, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5316, 'a:1:{i:0;a:1:{s:7:"fk_name";a:2:{s:8:"oldValue";s:15:"fk_titlepage_id";s:8:"newValue";s:18:"fk_titlechapter_id";}}}', NULL, 'changeProperty', 'ChiAssociation:543', NULL, 1361487816075905, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5308, 'a:1:{i:0;a:1:{s:10:"sourceName";a:2:{s:8:"oldValue";s:9:"TitlePage";s:8:"newValue";s:12:"TitleChapter";}}}', NULL, 'changeProperty', 'ChiAssociation:543', NULL, 1361486430529080, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5305, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"?";}}}', NULL, 'changeProperty', 'ChiAssociation:5257', NULL, 1361486391888742, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5304, 'a:1:{i:0;a:1:{s:18:"targetNavigability";a:2:{s:8:"oldValue";s:9:"Navigable";s:8:"newValue";s:9:"Navigable";}}}', NULL, 'changeProperty', 'ChiAssociation:5257', NULL, 1361484956522548, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5303, 'a:1:{i:0;a:1:{s:18:"sourceMultiplicity";a:2:{s:8:"oldValue";s:3:"513";s:8:"newValue";s:3:"513";}}}', NULL, 'changeProperty', 'ChiAssociation:5257', NULL, 1361484950350288, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5301, 'a:1:{i:0;a:1:{s:18:"targetMultiplicity";a:2:{s:8:"oldValue";s:3:"522";s:8:"newValue";s:3:"522";}}}', NULL, 'changeProperty', 'ChiAssociation:5257', NULL, 1361484937943070, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5302, 'a:1:{i:0;a:1:{s:18:"sourceNavigability";a:2:{s:8:"oldValue";s:9:"Navigable";s:8:"newValue";s:9:"Navigable";}}}', NULL, 'changeProperty', 'ChiAssociation:5257', NULL, 1361484944102785, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5300, 'a:1:{i:0;a:1:{s:18:"targetNavigability";a:2:{s:8:"oldValue";s:9:"Navigable";s:8:"newValue";s:9:"Navigable";}}}', NULL, 'changeProperty', 'ChiAssociation:5257', NULL, 1361484908048852, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5299, 'a:1:{i:0;a:1:{s:18:"targetMultiplicity";a:2:{s:8:"oldValue";s:3:"522";s:8:"newValue";s:3:"522";}}}', NULL, 'changeProperty', 'ChiAssociation:5257', NULL, 1361484901884459, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5297, 'a:1:{i:0;a:1:{s:18:"sourceMultiplicity";a:2:{s:8:"oldValue";s:3:"513";s:8:"newValue";s:3:"513";}}}', NULL, 'changeProperty', 'ChiAssociation:5257', NULL, 1361484889610343, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5298, 'a:1:{i:0;a:1:{s:18:"sourceNavigability";a:2:{s:8:"oldValue";s:9:"Navigable";s:8:"newValue";s:9:"Navigable";}}}', NULL, 'changeProperty', 'ChiAssociation:5257', NULL, 1361484895742065, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5296, 'a:1:{i:0;a:1:{s:18:"targetNavigability";a:2:{s:8:"oldValue";s:9:"Navigable";s:8:"newValue";s:9:"Navigable";}}}', NULL, 'changeProperty', 'ChiAssociation:5257', NULL, 1361484883344432, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5295, 'a:1:{i:0;a:1:{s:18:"targetMultiplicity";a:2:{s:8:"oldValue";s:3:"522";s:8:"newValue";s:3:"522";}}}', NULL, 'changeProperty', 'ChiAssociation:5257', NULL, 1361484877082992, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5293, 'a:1:{i:0;a:1:{s:18:"sourceMultiplicity";a:2:{s:8:"oldValue";s:3:"513";s:8:"newValue";s:3:"513";}}}', NULL, 'changeProperty', 'ChiAssociation:5257', NULL, 1361484864762373, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5294, 'a:1:{i:0;a:1:{s:18:"sourceNavigability";a:2:{s:8:"oldValue";s:9:"Navigable";s:8:"newValue";s:9:"Navigable";}}}', NULL, 'changeProperty', 'ChiAssociation:5257', NULL, 1361484870910214, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5292, 'a:1:{i:0;a:1:{s:18:"targetNavigability";a:2:{s:8:"oldValue";N;s:8:"newValue";s:9:"Navigable";}}}', NULL, 'changeProperty', 'ChiAssociation:5257', NULL, 1361484858619794, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5291, 'a:1:{i:0;a:1:{s:18:"targetMultiplicity";a:2:{s:8:"oldValue";s:3:"522";s:8:"newValue";s:3:"522";}}}', NULL, 'changeProperty', 'ChiAssociation:5257', NULL, 1361484852481762, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5290, 'a:1:{i:0;a:1:{s:18:"sourceNavigability";a:2:{s:8:"oldValue";s:9:"Navigable";s:8:"newValue";s:9:"Navigable";}}}', NULL, 'changeProperty', 'ChiAssociation:5257', NULL, 1361484846352859, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5289, 'a:1:{i:0;a:1:{s:18:"sourceMultiplicity";a:2:{s:8:"oldValue";s:3:"513";s:8:"newValue";s:3:"513";}}}', NULL, 'changeProperty', 'ChiAssociation:5257', NULL, 1361484840199598, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5287, 'a:1:{i:0;a:1:{s:18:"sourceNavigability";a:2:{s:8:"oldValue";s:9:"Navigable";s:8:"newValue";s:9:"Navigable";}}}', NULL, 'changeProperty', 'ChiAssociation:5257', NULL, 1361484827784973, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5288, 'a:1:{i:0;a:1:{s:18:"targetMultiplicity";a:2:{s:8:"oldValue";s:3:"522";s:8:"newValue";s:3:"522";}}}', NULL, 'changeProperty', 'ChiAssociation:5257', NULL, 1361484834053470, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5286, 'a:1:{i:0;a:1:{s:18:"sourceMultiplicity";a:2:{s:8:"oldValue";s:3:"513";s:8:"newValue";s:3:"513";}}}', NULL, 'changeProperty', 'ChiAssociation:5257', NULL, 1361484821519787, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5285, 'a:1:{i:0;a:1:{s:18:"sourceNavigability";a:2:{s:8:"oldValue";s:9:"Navigable";s:8:"newValue";s:9:"Navigable";}}}', NULL, 'changeProperty', 'ChiAssociation:5257', NULL, 1361484815367487, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5283, 'a:1:{i:0;a:1:{s:18:"targetMultiplicity";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"522";}}}', NULL, 'changeProperty', 'ChiAssociation:5257', NULL, 1361484803003769, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5284, 'a:1:{i:0;a:1:{s:18:"sourceMultiplicity";a:2:{s:8:"oldValue";s:3:"513";s:8:"newValue";s:3:"513";}}}', NULL, 'changeProperty', 'ChiAssociation:5257', NULL, 1361484809178023, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5282, 'a:1:{i:0;a:1:{s:18:"sourceMultiplicity";a:2:{s:8:"oldValue";s:3:"513";s:8:"newValue";s:3:"513";}}}', NULL, 'changeProperty', 'ChiAssociation:5257', NULL, 1361484796777908, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5280, 'a:1:{i:0;a:1:{s:18:"sourceMultiplicity";a:2:{s:8:"oldValue";s:3:"513";s:8:"newValue";s:3:"513";}}}', NULL, 'changeProperty', 'ChiAssociation:5257', NULL, 1361484780422297, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5281, 'a:1:{i:0;a:1:{s:18:"sourceNavigability";a:2:{s:8:"oldValue";s:9:"Navigable";s:8:"newValue";s:9:"Navigable";}}}', NULL, 'changeProperty', 'ChiAssociation:5257', NULL, 1361484790614881, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5279, 'a:1:{i:0;a:1:{s:18:"sourceNavigability";a:2:{s:8:"oldValue";N;s:8:"newValue";s:9:"Navigable";}}}', NULL, 'changeProperty', 'ChiAssociation:5257', NULL, 1361484774271302, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5278, 'a:1:{i:0;a:1:{s:18:"sourceMultiplicity";a:2:{s:8:"oldValue";s:3:"513";s:8:"newValue";s:3:"513";}}}', NULL, 'changeProperty', 'ChiAssociation:5257', NULL, 1361484768104575, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5274, 'a:1:{i:0;a:1:{s:18:"targetNavigability";a:2:{s:8:"oldValue";N;s:8:"newValue";s:9:"Navigable";}}}', NULL, 'changeProperty', 'ChiAssociation:5255', NULL, 1361484745506032, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5277, 'a:1:{i:0;a:1:{s:18:"sourceMultiplicity";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"513";}}}', NULL, 'changeProperty', 'ChiAssociation:5257', NULL, 1361484761973101, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5273, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"?";}}}', NULL, 'changeProperty', 'ChiAssociation:5255', NULL, 1361484739233681, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5272, 'a:1:{i:0;a:1:{s:18:"targetMultiplicity";a:2:{s:8:"oldValue";s:3:"522";s:8:"newValue";s:3:"522";}}}', NULL, 'changeProperty', 'ChiAssociation:5255', NULL, 1361484733027086, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5270, 'a:1:{i:0;a:1:{s:18:"sourceMultiplicity";a:2:{s:8:"oldValue";s:3:"513";s:8:"newValue";s:3:"513";}}}', NULL, 'changeProperty', 'ChiAssociation:5255', NULL, 1361484720674561, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5271, 'a:1:{i:0;a:1:{s:18:"sourceNavigability";a:2:{s:8:"oldValue";s:9:"Navigable";s:8:"newValue";s:9:"Navigable";}}}', NULL, 'changeProperty', 'ChiAssociation:5255', NULL, 1361484726844388, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5269, 'a:1:{i:0;a:1:{s:18:"sourceNavigability";a:2:{s:8:"oldValue";s:9:"Navigable";s:8:"newValue";s:9:"Navigable";}}}', NULL, 'changeProperty', 'ChiAssociation:5255', NULL, 1361484714451895, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5268, 'a:1:{i:0;a:1:{s:18:"sourceMultiplicity";a:2:{s:8:"oldValue";s:3:"513";s:8:"newValue";s:3:"513";}}}', NULL, 'changeProperty', 'ChiAssociation:5255', NULL, 1361484708198805, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5267, 'a:1:{i:0;a:1:{s:18:"targetMultiplicity";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"522";}}}', NULL, 'changeProperty', 'ChiAssociation:5255', NULL, 1361484701971488, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5266, 'a:1:{i:0;a:1:{s:18:"sourceMultiplicity";a:2:{s:8:"oldValue";s:3:"513";s:8:"newValue";s:3:"513";}}}', NULL, 'changeProperty', 'ChiAssociation:5255', NULL, 1361484695795512, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5265, 'a:1:{i:0;a:1:{s:18:"sourceNavigability";a:2:{s:8:"oldValue";s:9:"Navigable";s:8:"newValue";s:9:"Navigable";}}}', NULL, 'changeProperty', 'ChiAssociation:5255', NULL, 1361484689595426, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5264, 'a:1:{i:0;a:1:{s:18:"sourceNavigability";a:2:{s:8:"oldValue";N;s:8:"newValue";s:9:"Navigable";}}}', NULL, 'changeProperty', 'ChiAssociation:5255', NULL, 1361484679285248, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5263, 'a:1:{i:0;a:1:{s:18:"sourceMultiplicity";a:2:{s:8:"oldValue";s:3:"513";s:8:"newValue";s:3:"513";}}}', NULL, 'changeProperty', 'ChiAssociation:5255', NULL, 1361484673028399, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5262, 'a:1:{i:0;a:1:{s:18:"sourceMultiplicity";a:2:{s:8:"oldValue";s:3:"513";s:8:"newValue";s:3:"513";}}}', NULL, 'changeProperty', 'ChiAssociation:5255', NULL, 1361484666838107, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5261, 'a:1:{i:0;a:1:{s:18:"sourceMultiplicity";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"513";}}}', NULL, 'changeProperty', 'ChiAssociation:5255', NULL, 1361484660607132, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5258, 'a:2:{i:0;a:1:{s:12:"relationType";a:2:{s:8:"oldValue";N;s:8:"newValue";s:11:"aggregation";}}i:1;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:11:"Aggregation";}}}', NULL, 'changeProperty', 'ChiAssociation:5257', NULL, 1361484644832776, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5256, 'a:2:{i:0;a:1:{s:12:"relationType";a:2:{s:8:"oldValue";N;s:8:"newValue";s:11:"composition";}}i:1;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:11:"Composition";}}}', NULL, 'changeProperty', 'ChiAssociation:5255', NULL, 1361484634461202, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5247, 'a:1:{i:0;a:1:{s:18:"targetNavigability";a:2:{s:8:"oldValue";N;s:8:"newValue";s:9:"Navigable";}}}', NULL, 'changeProperty', 'ChiAssociation:5228', NULL, 1361484605224597, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5248, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"?";}}}', NULL, 'changeProperty', 'ChiAssociation:5228', NULL, 1361484611433858, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5246, 'a:1:{i:0;a:1:{s:18:"targetMultiplicity";a:2:{s:8:"oldValue";s:3:"514";s:8:"newValue";s:3:"514";}}}', NULL, 'changeProperty', 'ChiAssociation:5228', NULL, 1361484599070801, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5245, 'a:1:{i:0;a:1:{s:18:"sourceNavigability";a:2:{s:8:"oldValue";s:9:"Navigable";s:8:"newValue";s:9:"Navigable";}}}', NULL, 'changeProperty', 'ChiAssociation:5228', NULL, 1361484592893630, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5244, 'a:1:{i:0;a:1:{s:18:"sourceMultiplicity";a:2:{s:8:"oldValue";s:3:"513";s:8:"newValue";s:3:"513";}}}', NULL, 'changeProperty', 'ChiAssociation:5228', NULL, 1361484586561497, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5243, 'a:1:{i:0;a:1:{s:18:"targetMultiplicity";a:2:{s:8:"oldValue";s:3:"514";s:8:"newValue";s:3:"514";}}}', NULL, 'changeProperty', 'ChiAssociation:5228', NULL, 1361484580386405, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5242, 'a:1:{i:0;a:1:{s:18:"sourceNavigability";a:2:{s:8:"oldValue";s:9:"Navigable";s:8:"newValue";s:9:"Navigable";}}}', NULL, 'changeProperty', 'ChiAssociation:5228', NULL, 1361484574112373, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5241, 'a:1:{i:0;a:1:{s:18:"sourceMultiplicity";a:2:{s:8:"oldValue";s:3:"513";s:8:"newValue";s:3:"513";}}}', NULL, 'changeProperty', 'ChiAssociation:5228', NULL, 1361484567938375, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5240, 'a:1:{i:0;a:1:{s:18:"targetMultiplicity";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"514";}}}', NULL, 'changeProperty', 'ChiAssociation:5228', NULL, 1361484561786772, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5239, 'a:1:{i:0;a:1:{s:18:"sourceMultiplicity";a:2:{s:8:"oldValue";s:3:"513";s:8:"newValue";s:3:"513";}}}', NULL, 'changeProperty', 'ChiAssociation:5228', NULL, 1361484555640495, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5238, 'a:1:{i:0;a:1:{s:18:"sourceNavigability";a:2:{s:8:"oldValue";s:9:"Navigable";s:8:"newValue";s:9:"Navigable";}}}', NULL, 'changeProperty', 'ChiAssociation:5228', NULL, 1361484549472837, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5237, 'a:1:{i:0;a:1:{s:18:"sourceNavigability";a:2:{s:8:"oldValue";s:9:"Navigable";s:8:"newValue";s:9:"Navigable";}}}', NULL, 'changeProperty', 'ChiAssociation:5228', NULL, 1361484541499464, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5236, 'a:1:{i:0;a:1:{s:18:"sourceMultiplicity";a:2:{s:8:"oldValue";s:3:"513";s:8:"newValue";s:3:"513";}}}', NULL, 'changeProperty', 'ChiAssociation:5228', NULL, 1361484535305532, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5235, 'a:1:{i:0;a:1:{s:18:"sourceMultiplicity";a:2:{s:8:"oldValue";s:3:"513";s:8:"newValue";s:3:"513";}}}', NULL, 'changeProperty', 'ChiAssociation:5228', NULL, 1361484518057382, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5234, 'a:1:{i:0;a:1:{s:18:"sourceNavigability";a:2:{s:8:"oldValue";N;s:8:"newValue";s:9:"Navigable";}}}', NULL, 'changeProperty', 'ChiAssociation:5228', NULL, 1361484511797083, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5233, 'a:1:{i:0;a:1:{s:18:"sourceMultiplicity";a:2:{s:8:"oldValue";s:3:"513";s:8:"newValue";s:3:"513";}}}', NULL, 'changeProperty', 'ChiAssociation:5228', NULL, 1361484505590986, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5232, 'a:1:{i:0;a:1:{s:18:"sourceMultiplicity";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"513";}}}', NULL, 'changeProperty', 'ChiAssociation:5228', NULL, 1361484499328177, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5229, 'a:2:{i:0;a:1:{s:12:"relationType";a:2:{s:8:"oldValue";N;s:8:"newValue";s:11:"composition";}}i:1;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:11:"Composition";}}}', NULL, 'changeProperty', 'ChiAssociation:5228', NULL, 1361484479227900, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5227, 'a:1:{i:0;a:1:{s:10:"table_name";a:2:{s:8:"oldValue";s:8:"adodbseq";s:8:"newValue";s:10:"dbsequence";}}}', NULL, 'changeProperty', 'ChiNode:311', NULL, 1361482738001371, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5222, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:5:"DBSeq";s:8:"newValue";s:10:"DBSequence";}}}', NULL, 'changeProperty', 'ChiNode:311', NULL, 1361482676727048, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5221, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:8:"Adodbseq";s:8:"newValue";s:5:"DBSeq";}}}', NULL, 'changeProperty', 'ChiNode:311', NULL, 1361482666740468, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5218, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"?";}}}', NULL, 'changeProperty', 'Model:3', NULL, 1361482582885281, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(4968, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:12:"New ChiValue";}}}', NULL, 'changeProperty', 'ChiValue:4967', NULL, 1361400850556925, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(4970, 'a:2:{i:0;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:3:"150";s:8:"newValue";s:3:"150";}}i:1;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:2:"81";s:8:"newValue";s:3:"113";}}}', NULL, 'changeProperty', 'Figure:704', NULL, 1361400872711860, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(4971, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";s:1:"?";s:8:"newValue";s:60:"A book is published by a publisher and consists of chapters.";}}}', NULL, 'changeProperty', 'ChiNode:271', NULL, 1361400920924375, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(4981, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:12:"New ChiValue";}}}', NULL, 'changeProperty', 'ChiValue:4969', NULL, 1361400956306272, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(4986, 'a:2:{i:0;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:3:"150";s:8:"newValue";s:3:"150";}}i:1;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:3:"113";s:8:"newValue";s:3:"161";}}}', NULL, 'changeProperty', 'Figure:704', NULL, 1361400984588019, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(4987, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:12:"New ChiValue";s:8:"newValue";s:4:"year";}}}', NULL, 'changeProperty', 'ChiValue:4969', NULL, 1361401029258311, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(4988, 'a:1:{i:0;a:1:{s:12:"PropertyType";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"530";}}}', NULL, 'changeProperty', 'ChiValue:4969', NULL, 1361401048565692, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5020, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:12:"New ChiValue";s:8:"newValue";s:11:"description";}}}', NULL, 'changeProperty', 'ChiValue:4967', NULL, 1361478730178837, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5021, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"?";}}}', NULL, 'changeProperty', 'ChiValue:4967', NULL, 1361478744627146, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5022, 'a:1:{i:0;a:1:{s:12:"PropertyType";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"531";}}}', NULL, 'changeProperty', 'ChiValue:4967', NULL, 1361478751825612, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5025, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"?";}}}', NULL, 'changeProperty', 'ChiValue:4969', NULL, 1361478764600934, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5028, 'a:1:{i:0;a:1:{s:11:"is_editable";a:2:{s:8:"oldValue";s:4:"true";s:8:"newValue";s:4:"true";}}}', NULL, 'changeProperty', 'ChiValue:273', NULL, 1361478775476087, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5031, 'a:1:{i:0;a:1:{s:12:"display_type";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"1041";}}}', NULL, 'changeProperty', 'ChiValue:4967', NULL, 1361478796798423, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5032, 'a:1:{i:0;a:1:{s:12:"display_type";a:2:{s:8:"oldValue";s:4:"1041";s:8:"newValue";s:4:"1041";}}}', NULL, 'changeProperty', 'ChiValue:4967', NULL, 1361478807303422, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5033, 'a:1:{i:0;a:1:{s:10:"input_type";a:2:{s:8:"oldValue";N;s:8:"newValue";s:8:"textarea";}}}', NULL, 'changeProperty', 'ChiValue:4967', NULL, 1361478814526797, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5036, 'a:1:{i:0;a:1:{s:12:"display_type";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"1041";}}}', NULL, 'changeProperty', 'ChiValue:4969', NULL, 1361478831725240, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5037, 'a:1:{i:0;a:1:{s:12:"display_type";a:2:{s:8:"oldValue";s:4:"1041";s:8:"newValue";s:4:"1041";}}}', NULL, 'changeProperty', 'ChiValue:4969', NULL, 1361478843178315, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5038, 'a:1:{i:0;a:1:{s:12:"display_type";a:2:{s:8:"oldValue";s:4:"1041";s:8:"newValue";s:4:"1041";}}}', NULL, 'changeProperty', 'ChiValue:4969', NULL, 1361478850413061, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5039, 'a:1:{i:0;a:1:{s:11:"is_editable";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"true";}}}', NULL, 'changeProperty', 'ChiValue:4969', NULL, 1361478857693680, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5040, 'a:1:{i:0;a:1:{s:10:"input_type";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"date";}}}', NULL, 'changeProperty', 'ChiValue:4969', NULL, 1361478864930032, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5041, 'a:1:{i:0;a:1:{s:10:"input_type";a:2:{s:8:"oldValue";s:4:"date";s:8:"newValue";s:4:"date";}}}', NULL, 'changeProperty', 'ChiValue:4969', NULL, 1361478872163037, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5044, 'a:1:{i:0;a:1:{s:11:"is_editable";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"true";}}}', NULL, 'changeProperty', 'ChiValue:4967', NULL, 1361478884865430, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5047, 'a:1:{i:0;a:1:{s:11:"is_editable";a:2:{s:8:"oldValue";s:4:"true";s:8:"newValue";s:4:"true";}}}', NULL, 'changeProperty', 'ChiValue:273', NULL, 1361478895560259, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5052, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"4932";s:8:"newValue";s:4:"4843";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5420";s:8:"newValue";s:4:"4921";}}}', NULL, 'changeProperty', 'Figure:4438', NULL, 1361478924068076, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5055, 'a:1:{i:0;a:1:{s:7:"is_soap";a:2:{s:8:"oldValue";s:4:"true";s:8:"newValue";s:4:"true";}}}', NULL, 'changeProperty', 'ChiNode:292', NULL, 1361478968114057, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5056, 'a:1:{i:0;a:1:{s:13:"is_searchable";a:2:{s:8:"oldValue";s:4:"true";s:8:"newValue";s:4:"true";}}}', NULL, 'changeProperty', 'ChiNode:292', NULL, 1361478972352387, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5057, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5012";s:8:"newValue";s:4:"5012";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5210";s:8:"newValue";s:4:"5307";}}}', NULL, 'changeProperty', 'Figure:707', NULL, 1361478976637044, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5060, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5124";s:8:"newValue";s:4:"5111";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5549";s:8:"newValue";s:4:"5513";}}}', NULL, 'changeProperty', 'Figure:704', NULL, 1361479021785093, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5062, 'a:1:{i:0;a:1:{s:13:"is_searchable";a:2:{s:8:"oldValue";s:4:"true";s:8:"newValue";s:4:"true";}}}', NULL, 'changeProperty', 'ChiNode:271', NULL, 1361479067240562, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5063, 'a:1:{i:0;a:1:{s:7:"is_soap";a:2:{s:8:"oldValue";s:4:"true";s:8:"newValue";s:4:"true";}}}', NULL, 'changeProperty', 'ChiNode:271', NULL, 1361479071527949, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5068, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5111";s:8:"newValue";s:4:"5473";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5513";s:8:"newValue";s:4:"5306";}}}', NULL, 'changeProperty', 'Figure:704', NULL, 1361479082381877, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5071, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5337";s:8:"newValue";s:4:"5030";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5552";s:8:"newValue";s:4:"5589";}}}', NULL, 'changeProperty', 'Figure:706', NULL, 1361479127701757, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5074, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5473";s:8:"newValue";s:4:"5361";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5306";s:8:"newValue";s:4:"5290";}}}', NULL, 'changeProperty', 'Figure:704', NULL, 1361479173013111, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5075, 'a:1:{i:0;a:1:{s:13:"is_searchable";a:2:{s:8:"oldValue";s:4:"true";s:8:"newValue";s:4:"true";}}}', NULL, 'changeProperty', 'ChiNode:271', NULL, 1361479214779156, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5076, 'a:1:{i:0;a:1:{s:7:"is_soap";a:2:{s:8:"oldValue";s:4:"true";s:8:"newValue";s:4:"true";}}}', NULL, 'changeProperty', 'ChiNode:271', NULL, 1361479219038817, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5079, 'a:2:{i:0;a:1:{s:12:"relationType";a:2:{s:8:"oldValue";N;s:8:"newValue";s:11:"composition";}}i:1;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:11:"Composition";}}}', NULL, 'changeProperty', 'ChiAssociation:5061', NULL, 1361479225408256, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5082, 'a:1:{i:0;a:1:{s:10:"targetName";a:2:{s:8:"oldValue";s:9:"ChildPage";s:8:"newValue";s:10:"SubChapter";}}}', NULL, 'changeProperty', 'ChiAssociation:541', NULL, 1361479539714405, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5083, 'a:1:{i:0;a:1:{s:10:"sourceName";a:2:{s:8:"oldValue";s:10:"ParentPage";s:8:"newValue";s:0:"";}}}', NULL, 'changeProperty', 'ChiAssociation:541', NULL, 1361479624512911, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5090, 'a:1:{i:0;a:1:{s:18:"sourceMultiplicity";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"513";}}}', NULL, 'changeProperty', 'ChiAssociation:5061', NULL, 1361479654363143, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5091, 'a:1:{i:0;a:1:{s:18:"sourceMultiplicity";a:2:{s:8:"oldValue";s:3:"513";s:8:"newValue";s:3:"513";}}}', NULL, 'changeProperty', 'ChiAssociation:5061', NULL, 1361479663028751, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5092, 'a:1:{i:0;a:1:{s:18:"sourceMultiplicity";a:2:{s:8:"oldValue";s:3:"513";s:8:"newValue";s:3:"513";}}}', NULL, 'changeProperty', 'ChiAssociation:5061', NULL, 1361479669274649, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5093, 'a:1:{i:0;a:1:{s:18:"targetMultiplicity";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"522";}}}', NULL, 'changeProperty', 'ChiAssociation:5061', NULL, 1361479675548341, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5094, 'a:1:{i:0;a:1:{s:18:"targetMultiplicity";a:2:{s:8:"oldValue";s:3:"522";s:8:"newValue";s:3:"522";}}}', NULL, 'changeProperty', 'ChiAssociation:5061', NULL, 1361479681740837, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5095, 'a:1:{i:0;a:1:{s:18:"sourceMultiplicity";a:2:{s:8:"oldValue";s:3:"513";s:8:"newValue";s:3:"513";}}}', NULL, 'changeProperty', 'ChiAssociation:5061', NULL, 1361479687996393, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5096, 'a:1:{i:0;a:1:{s:18:"sourceMultiplicity";a:2:{s:8:"oldValue";s:3:"513";s:8:"newValue";s:3:"513";}}}', NULL, 'changeProperty', 'ChiAssociation:5061', NULL, 1361479694188274, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5097, 'a:1:{i:0;a:1:{s:18:"targetMultiplicity";a:2:{s:8:"oldValue";s:3:"522";s:8:"newValue";s:3:"522";}}}', NULL, 'changeProperty', 'ChiAssociation:5061', NULL, 1361479700457027, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5098, 'a:1:{i:0;a:1:{s:18:"sourceNavigability";a:2:{s:8:"oldValue";N;s:8:"newValue";s:9:"Navigable";}}}', NULL, 'changeProperty', 'ChiAssociation:5061', NULL, 1361479706729975, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5099, 'a:1:{i:0;a:1:{s:18:"sourceMultiplicity";a:2:{s:8:"oldValue";s:3:"513";s:8:"newValue";s:3:"513";}}}', NULL, 'changeProperty', 'ChiAssociation:5061', NULL, 1361479712982781, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5100, 'a:1:{i:0;a:1:{s:18:"targetMultiplicity";a:2:{s:8:"oldValue";s:3:"522";s:8:"newValue";s:3:"522";}}}', NULL, 'changeProperty', 'ChiAssociation:5061', NULL, 1361479719261986, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5101, 'a:1:{i:0;a:1:{s:18:"sourceNavigability";a:2:{s:8:"oldValue";s:9:"Navigable";s:8:"newValue";s:9:"Navigable";}}}', NULL, 'changeProperty', 'ChiAssociation:5061', NULL, 1361479725444280, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5102, 'a:1:{i:0;a:1:{s:18:"sourceMultiplicity";a:2:{s:8:"oldValue";s:3:"513";s:8:"newValue";s:3:"513";}}}', NULL, 'changeProperty', 'ChiAssociation:5061', NULL, 1361479731648605, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5103, 'a:1:{i:0;a:1:{s:18:"targetMultiplicity";a:2:{s:8:"oldValue";s:3:"522";s:8:"newValue";s:3:"522";}}}', NULL, 'changeProperty', 'ChiAssociation:5061', NULL, 1361479737940349, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5104, 'a:1:{i:0;a:1:{s:18:"sourceNavigability";a:2:{s:8:"oldValue";s:9:"Navigable";s:8:"newValue";s:9:"Navigable";}}}', NULL, 'changeProperty', 'ChiAssociation:5061', NULL, 1361479744176373, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5105, 'a:1:{i:0;a:1:{s:18:"targetNavigability";a:2:{s:8:"oldValue";N;s:8:"newValue";s:9:"Navigable";}}}', NULL, 'changeProperty', 'ChiAssociation:5061', NULL, 1361479750357755, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5106, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"?";}}}', NULL, 'changeProperty', 'ChiAssociation:5061', NULL, 1361479756563089, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5111, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"4957";s:8:"newValue";s:4:"5001";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5055";s:8:"newValue";s:4:"5097";}}}', NULL, 'changeProperty', 'Figure:703', NULL, 1361479768332646, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5112, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"4843";s:8:"newValue";s:4:"5039";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"4921";s:8:"newValue";s:4:"4947";}}}', NULL, 'changeProperty', 'Figure:4438', NULL, 1361479812461608, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5115, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:11:"New ChiNode";}}}', NULL, 'changeProperty', 'ChiNode:5113', NULL, 1361479859002598, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5116, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"4835";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5036";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"96";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"95";}}}', NULL, 'changeProperty', 'Figure:5114', NULL, 1361479863448164, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5119, 'a:1:{i:0;a:1:{s:13:"is_searchable";a:2:{s:8:"oldValue";s:4:"true";s:8:"newValue";s:4:"true";}}}', NULL, 'changeProperty', 'ChiNode:5113', NULL, 1361479907513720, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5120, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:11:"New ChiNode";s:8:"newValue";s:9:"Publisher";}}}', NULL, 'changeProperty', 'ChiNode:5113', NULL, 1361480377981248, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5121, 'a:1:{i:0;a:1:{s:7:"orderby";a:2:{s:8:"oldValue";s:4:"none";s:8:"newValue";s:4:"name";}}}', NULL, 'changeProperty', 'ChiNode:5113', NULL, 1361480406385329, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5122, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"4835";s:8:"newValue";s:4:"4824";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5036";s:8:"newValue";s:4:"4976";}}}', NULL, 'changeProperty', 'Figure:5114', NULL, 1361480410706442, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5124, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";N;s:8:"newValue";s:31:"?A publisher publishes books.";}}}', NULL, 'changeProperty', 'ChiNode:5113', NULL, 1361480459945224, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5125, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:12:"New ChiValue";}}}', NULL, 'changeProperty', 'ChiValue:5123', NULL, 1361480466329968, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5128, 'a:2:{i:0;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:2:"96";s:8:"newValue";s:3:"150";}}i:1;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:2:"95";s:8:"newValue";s:2:"81";}}}', NULL, 'changeProperty', 'Figure:5114', NULL, 1361480479676926, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5129, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:12:"New ChiValue";s:8:"newValue";s:4:"name";}}}', NULL, 'changeProperty', 'ChiValue:5123', NULL, 1361480849179120, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5130, 'a:1:{i:0;a:1:{s:12:"PropertyType";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"531";}}}', NULL, 'changeProperty', 'ChiValue:5123', NULL, 1361480863197903, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5131, 'a:1:{i:0;a:1:{s:12:"PropertyType";a:2:{s:8:"oldValue";s:3:"531";s:8:"newValue";s:3:"531";}}}', NULL, 'changeProperty', 'ChiValue:5123', NULL, 1361480873339055, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5132, 'a:1:{i:0;a:1:{s:12:"PropertyType";a:2:{s:8:"oldValue";s:3:"531";s:8:"newValue";s:3:"531";}}}', NULL, 'changeProperty', 'ChiValue:5123', NULL, 1361480880659110, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5133, 'a:1:{i:0;a:1:{s:12:"display_type";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"1041";}}}', NULL, 'changeProperty', 'ChiValue:5123', NULL, 1361480887877879, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5134, 'a:1:{i:0;a:1:{s:12:"PropertyType";a:2:{s:8:"oldValue";s:3:"531";s:8:"newValue";s:3:"531";}}}', NULL, 'changeProperty', 'ChiValue:5123', NULL, 1361480898421568, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5135, 'a:1:{i:0;a:1:{s:12:"display_type";a:2:{s:8:"oldValue";s:4:"1041";s:8:"newValue";s:4:"1041";}}}', NULL, 'changeProperty', 'ChiValue:5123', NULL, 1361480905657257, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5136, 'a:1:{i:0;a:1:{s:10:"input_type";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"text";}}}', NULL, 'changeProperty', 'ChiValue:5123', NULL, 1361480912931613, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5137, 'a:1:{i:0;a:1:{s:12:"display_type";a:2:{s:8:"oldValue";s:4:"1041";s:8:"newValue";s:4:"1041";}}}', NULL, 'changeProperty', 'ChiValue:5123', NULL, 1361480920299410, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5138, 'a:1:{i:0;a:1:{s:12:"PropertyType";a:2:{s:8:"oldValue";s:3:"531";s:8:"newValue";s:3:"531";}}}', NULL, 'changeProperty', 'ChiValue:5123', NULL, 1361480927582973, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5139, 'a:1:{i:0;a:1:{s:11:"is_editable";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"true";}}}', NULL, 'changeProperty', 'ChiValue:5123', NULL, 1361480934869629, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5140, 'a:1:{i:0;a:1:{s:12:"PropertyType";a:2:{s:8:"oldValue";s:3:"531";s:8:"newValue";s:3:"531";}}}', NULL, 'changeProperty', 'ChiValue:5123', NULL, 1361480942109154, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5141, 'a:1:{i:0;a:1:{s:12:"display_type";a:2:{s:8:"oldValue";s:4:"1041";s:8:"newValue";s:4:"1041";}}}', NULL, 'changeProperty', 'ChiValue:5123', NULL, 1361480949401240, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5142, 'a:1:{i:0;a:1:{s:10:"input_type";a:2:{s:8:"oldValue";s:4:"text";s:8:"newValue";s:4:"text";}}}', NULL, 'changeProperty', 'ChiValue:5123', NULL, 1361480956646240, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5143, 'a:1:{i:0;a:1:{s:12:"PropertyType";a:2:{s:8:"oldValue";s:3:"531";s:8:"newValue";s:3:"531";}}}', NULL, 'changeProperty', 'ChiValue:5123', NULL, 1361480963969939, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5144, 'a:1:{i:0;a:1:{s:12:"display_type";a:2:{s:8:"oldValue";s:4:"1041";s:8:"newValue";s:4:"1041";}}}', NULL, 'changeProperty', 'ChiValue:5123', NULL, 1361480971256764, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5145, 'a:1:{i:0;a:1:{s:10:"input_type";a:2:{s:8:"oldValue";s:4:"text";s:8:"newValue";s:4:"text";}}}', NULL, 'changeProperty', 'ChiValue:5123', NULL, 1361480978474425, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5147, 'a:1:{i:0;a:1:{s:12:"PropertyType";a:2:{s:8:"oldValue";s:3:"531";s:8:"newValue";s:3:"531";}}}', NULL, 'changeProperty', 'ChiValue:5123', NULL, 1361480989096552, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5148, 'a:1:{i:0;a:1:{s:12:"display_type";a:2:{s:8:"oldValue";s:4:"1041";s:8:"newValue";s:4:"1041";}}}', NULL, 'changeProperty', 'ChiValue:5123', NULL, 1361480996470172, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5149, 'a:1:{i:0;a:1:{s:10:"input_type";a:2:{s:8:"oldValue";s:4:"text";s:8:"newValue";s:4:"text";}}}', NULL, 'changeProperty', 'ChiValue:5123', NULL, 1361481003794793, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5150, 'a:1:{i:0;a:1:{s:12:"PropertyType";a:2:{s:8:"oldValue";s:3:"531";s:8:"newValue";s:3:"531";}}}', NULL, 'changeProperty', 'ChiValue:5123', NULL, 1361481011082553, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5151, 'a:1:{i:0;a:1:{s:12:"display_type";a:2:{s:8:"oldValue";s:4:"1041";s:8:"newValue";s:4:"1041";}}}', NULL, 'changeProperty', 'ChiValue:5123', NULL, 1361481018354517, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5152, 'a:1:{i:0;a:1:{s:10:"input_type";a:2:{s:8:"oldValue";s:4:"text";s:8:"newValue";s:4:"text";}}}', NULL, 'changeProperty', 'ChiValue:5123', NULL, 1361481025623289, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5154, 'a:1:{i:0;a:1:{s:12:"PropertyType";a:2:{s:8:"oldValue";s:3:"531";s:8:"newValue";s:3:"531";}}}', NULL, 'changeProperty', 'ChiValue:5123', NULL, 1361481036330378, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5155, 'a:1:{i:0;a:1:{s:12:"display_type";a:2:{s:8:"oldValue";s:4:"1041";s:8:"newValue";s:4:"1041";}}}', NULL, 'changeProperty', 'ChiValue:5123', NULL, 1361481043631302, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5156, 'a:1:{i:0;a:1:{s:10:"input_type";a:2:{s:8:"oldValue";s:4:"text";s:8:"newValue";s:4:"text";}}}', NULL, 'changeProperty', 'ChiValue:5123', NULL, 1361481050940826, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5158, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"?";}}}', NULL, 'changeProperty', 'ChiValue:5123', NULL, 1361481061637681, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5159, 'a:1:{i:0;a:1:{s:10:"input_type";a:2:{s:8:"oldValue";s:4:"text";s:8:"newValue";s:4:"text";}}}', NULL, 'changeProperty', 'ChiValue:5123', NULL, 1361481068969767, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5162, 'a:2:{i:0;a:1:{s:12:"relationType";a:2:{s:8:"oldValue";N;s:8:"newValue";s:11:"composition";}}i:1;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:11:"Composition";}}}', NULL, 'changeProperty', 'NMChiNodeChiMany2Many:5146', NULL, 1361481081740780, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5163, 'a:2:{i:0;a:1:{s:12:"relationType";a:2:{s:8:"oldValue";N;s:8:"newValue";s:11:"composition";}}i:1;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:11:"Composition";}}}', NULL, 'changeProperty', 'NMChiNodeChiMany2Many:5153', NULL, 1361481085914240, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5164, 'a:2:{i:0;a:1:{s:12:"relationType";a:2:{s:8:"oldValue";N;s:8:"newValue";s:14:"generalization";}}i:1;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:14:"Generalization";}}}', NULL, 'changeProperty', 'ChiAssociation:5157', NULL, 1361481090107853, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5165, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:13:"NMBookChapter";s:8:"newValue";s:17:"NMPublisherAuthor";}}}', NULL, 'changeProperty', 'ChiNodeManyToMany:4437', NULL, 1361481128528642, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5168, 'a:1:{i:0;a:1:{s:18:"sourceMultiplicity";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"513";}}}', NULL, 'changeProperty', 'NMChiNodeChiMany2Many:5146', NULL, 1361481143634615, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5169, 'a:1:{i:0;a:1:{s:18:"sourceMultiplicity";a:2:{s:8:"oldValue";s:3:"513";s:8:"newValue";s:3:"513";}}}', NULL, 'changeProperty', 'NMChiNodeChiMany2Many:5146', NULL, 1361481147793288, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5170, 'a:1:{i:0;a:1:{s:18:"sourceMultiplicity";a:2:{s:8:"oldValue";s:3:"513";s:8:"newValue";s:3:"513";}}}', NULL, 'changeProperty', 'NMChiNodeChiMany2Many:5146', NULL, 1361481151960334, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5171, 'a:1:{i:0;a:1:{s:18:"sourceNavigability";a:2:{s:8:"oldValue";N;s:8:"newValue";s:9:"Navigable";}}}', NULL, 'changeProperty', 'NMChiNodeChiMany2Many:5146', NULL, 1361481156106528, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5172, 'a:1:{i:0;a:1:{s:18:"sourceMultiplicity";a:2:{s:8:"oldValue";s:3:"513";s:8:"newValue";s:3:"513";}}}', NULL, 'changeProperty', 'NMChiNodeChiMany2Many:5146', NULL, 1361481162848385, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5173, 'a:1:{i:0;a:1:{s:18:"sourceNavigability";a:2:{s:8:"oldValue";s:9:"Navigable";s:8:"newValue";s:9:"Navigable";}}}', NULL, 'changeProperty', 'NMChiNodeChiMany2Many:5146', NULL, 1361481166984596, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5174, 'a:1:{i:0;a:1:{s:18:"sourceNavigability";a:2:{s:8:"oldValue";s:9:"Navigable";s:8:"newValue";s:9:"Navigable";}}}', NULL, 'changeProperty', 'NMChiNodeChiMany2Many:5146', NULL, 1361481171146625, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5175, 'a:1:{i:0;a:1:{s:18:"targetMultiplicity";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"522";}}}', NULL, 'changeProperty', 'NMChiNodeChiMany2Many:5146', NULL, 1361481175318791, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5176, 'a:1:{i:0;a:1:{s:18:"sourceMultiplicity";a:2:{s:8:"oldValue";s:3:"513";s:8:"newValue";s:3:"513";}}}', NULL, 'changeProperty', 'NMChiNodeChiMany2Many:5146', NULL, 1361481179494995, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5177, 'a:1:{i:0;a:1:{s:18:"sourceMultiplicity";a:2:{s:8:"oldValue";s:3:"513";s:8:"newValue";s:3:"513";}}}', NULL, 'changeProperty', 'NMChiNodeChiMany2Many:5146', NULL, 1361481183675548, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5178, 'a:1:{i:0;a:1:{s:18:"sourceNavigability";a:2:{s:8:"oldValue";s:9:"Navigable";s:8:"newValue";s:9:"Navigable";}}}', NULL, 'changeProperty', 'NMChiNodeChiMany2Many:5146', NULL, 1361481187830347, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5179, 'a:1:{i:0;a:1:{s:18:"targetMultiplicity";a:2:{s:8:"oldValue";s:3:"522";s:8:"newValue";s:3:"522";}}}', NULL, 'changeProperty', 'NMChiNodeChiMany2Many:5146', NULL, 1361481191974737, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5180, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"?";}}}', NULL, 'changeProperty', 'NMChiNodeChiMany2Many:5146', NULL, 1361481196142153, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5181, 'a:1:{i:0;a:1:{s:18:"targetNavigability";a:2:{s:8:"oldValue";N;s:8:"newValue";s:9:"Navigable";}}}', NULL, 'changeProperty', 'NMChiNodeChiMany2Many:5146', NULL, 1361481200303376, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5184, 'a:1:{i:0;a:1:{s:18:"sourceMultiplicity";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"513";}}}', NULL, 'changeProperty', 'NMChiNodeChiMany2Many:5153', NULL, 1361481218176542, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5185, 'a:1:{i:0;a:1:{s:18:"sourceMultiplicity";a:2:{s:8:"oldValue";s:3:"513";s:8:"newValue";s:3:"513";}}}', NULL, 'changeProperty', 'NMChiNodeChiMany2Many:5153', NULL, 1361481222330127, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5186, 'a:1:{i:0;a:1:{s:18:"sourceNavigability";a:2:{s:8:"oldValue";N;s:8:"newValue";s:9:"Navigable";}}}', NULL, 'changeProperty', 'NMChiNodeChiMany2Many:5153', NULL, 1361481226505921, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5187, 'a:1:{i:0;a:1:{s:18:"sourceMultiplicity";a:2:{s:8:"oldValue";s:3:"513";s:8:"newValue";s:3:"513";}}}', NULL, 'changeProperty', 'NMChiNodeChiMany2Many:5153', NULL, 1361481230663727, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5188, 'a:1:{i:0;a:1:{s:18:"sourceMultiplicity";a:2:{s:8:"oldValue";s:3:"513";s:8:"newValue";s:3:"513";}}}', NULL, 'changeProperty', 'NMChiNodeChiMany2Many:5153', NULL, 1361481234817490, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5189, 'a:1:{i:0;a:1:{s:18:"sourceNavigability";a:2:{s:8:"oldValue";s:9:"Navigable";s:8:"newValue";s:9:"Navigable";}}}', NULL, 'changeProperty', 'NMChiNodeChiMany2Many:5153', NULL, 1361481238990489, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5190, 'a:1:{i:0;a:1:{s:18:"sourceMultiplicity";a:2:{s:8:"oldValue";s:3:"513";s:8:"newValue";s:3:"513";}}}', NULL, 'changeProperty', 'NMChiNodeChiMany2Many:5153', NULL, 1361481243156311, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5191, 'a:1:{i:0;a:1:{s:18:"sourceNavigability";a:2:{s:8:"oldValue";s:9:"Navigable";s:8:"newValue";s:9:"Navigable";}}}', NULL, 'changeProperty', 'NMChiNodeChiMany2Many:5153', NULL, 1361481247326327, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5192, 'a:1:{i:0;a:1:{s:18:"targetNavigability";a:2:{s:8:"oldValue";N;s:8:"newValue";s:9:"Navigable";}}}', NULL, 'changeProperty', 'NMChiNodeChiMany2Many:5153', NULL, 1361481251500568, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5193, 'a:1:{i:0;a:1:{s:18:"sourceNavigability";a:2:{s:8:"oldValue";s:9:"Navigable";s:8:"newValue";s:9:"Navigable";}}}', NULL, 'changeProperty', 'NMChiNodeChiMany2Many:5153', NULL, 1361481258498563, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5194, 'a:1:{i:0;a:1:{s:18:"sourceMultiplicity";a:2:{s:8:"oldValue";s:3:"513";s:8:"newValue";s:3:"513";}}}', NULL, 'changeProperty', 'NMChiNodeChiMany2Many:5153', NULL, 1361481262663862, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5195, 'a:1:{i:0;a:1:{s:18:"targetNavigability";a:2:{s:8:"oldValue";s:9:"Navigable";s:8:"newValue";s:9:"Navigable";}}}', NULL, 'changeProperty', 'NMChiNodeChiMany2Many:5153', NULL, 1361481266838642, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5196, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"?";}}}', NULL, 'changeProperty', 'NMChiNodeChiMany2Many:5153', NULL, 1361481275888790, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5197, 'a:1:{i:0;a:1:{s:18:"targetMultiplicity";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"522";}}}', NULL, 'changeProperty', 'NMChiNodeChiMany2Many:5153', NULL, 1361481280055352, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5202, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:13:"NMBookChapter";s:8:"newValue";s:17:"NMPublisherAuthor";}}}', NULL, 'changeProperty', 'ChiNodeManyToMany:4437', NULL, 1361481411715207, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5203, 'a:1:{i:0;a:1:{s:13:"display_value";a:2:{s:8:"oldValue";s:4:"name";s:8:"newValue";s:0:"";}}}', NULL, 'changeProperty', 'ChiNodeManyToMany:4437', NULL, 1361481415968739, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(5204, 'a:1:{i:0;a:1:{s:7:"orderby";a:2:{s:8:"oldValue";s:4:"none";s:8:"newValue";s:7:"sortkey";}}}', NULL, 'changeProperty', 'ChiNodeManyToMany:4437', NULL, 1361481420627509, 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `InputType`
--

DROP TABLE IF EXISTS `InputType`;
CREATE TABLE IF NOT EXISTS `InputType` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `InputType`
--

INSERT INTO `InputType` (`id`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(1058, 'text', '?', '2012-06-19 00:42:16', 'admin', 'admin', '2012-06-19 00:48:45', NULL);
INSERT INTO `InputType` (`id`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(1064, 'checkbox', '?', '2012-06-19 00:48:43', 'admin', 'admin', '2012-06-19 00:49:01', NULL);
INSERT INTO `InputType` (`id`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(1070, 'ckeditor', '?', '2012-06-19 00:48:54', 'admin', 'admin', '2012-06-19 00:49:07', NULL);
INSERT INTO `InputType` (`id`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(1076, 'date', '?', '2012-06-19 00:49:06', 'admin', 'admin', '2012-06-19 00:49:20', NULL);
INSERT INTO `InputType` (`id`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(1082, 'filebrowser', '?', '2012-06-19 00:49:18', 'admin', 'admin', '2012-06-19 00:49:30', NULL);
INSERT INTO `InputType` (`id`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(1088, 'linkbrowser', '?', '2012-06-19 00:49:29', 'admin', 'admin', '2012-06-19 00:49:41', NULL);
INSERT INTO `InputType` (`id`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(1094, 'password', '?', '2012-06-19 00:49:40', 'admin', 'admin', '2012-06-19 00:49:52', NULL);
INSERT INTO `InputType` (`id`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(1100, 'radio', '?', '2012-06-19 00:49:51', 'admin', 'admin', '2012-06-19 00:50:08', NULL);
INSERT INTO `InputType` (`id`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(1106, 'select', '?', '2012-06-19 00:50:07', 'admin', 'admin', '2012-06-19 00:50:20', NULL);
INSERT INTO `InputType` (`id`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(1112, 'select#async', '?', '2012-06-19 00:50:18', 'admin', 'admin', '2012-06-19 00:50:31', NULL);
INSERT INTO `InputType` (`id`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(1118, 'textarea', '?', '2012-06-19 00:50:30', 'admin', 'admin', '2012-06-19 00:50:44', NULL);
INSERT INTO `InputType` (`id`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(1124, 'textile', '?', '2012-06-19 00:50:41', 'admin', 'admin', '2012-06-19 00:50:56', NULL);
INSERT INTO `InputType` (`id`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(1130, 'binarycheckbox', NULL, '2012-06-19 00:50:54', 'admin', 'admin', '2012-06-19 00:51:03', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Language`
--

DROP TABLE IF EXISTS `Language`;
CREATE TABLE IF NOT EXISTS `Language` (
  `id` int(11) NOT NULL,
  `code` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Language`
--

INSERT INTO `Language` (`id`, `code`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(1, 'en', 'English', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Language` (`id`, `code`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2, 'de', 'Deutsch', NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `locktable`
--

DROP TABLE IF EXISTS `locktable`;
CREATE TABLE IF NOT EXISTS `locktable` (
  `id` int(11) NOT NULL,
  `fk_user_id` int(11) DEFAULT NULL,
  `objectid` varchar(255) DEFAULT NULL,
  `sessionid` varchar(255) DEFAULT NULL,
  `since` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_user_id` (`fk_user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Model`
--

DROP TABLE IF EXISTS `Model`;
CREATE TABLE IF NOT EXISTS `Model` (
  `id` int(11) NOT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Model`
--

INSERT INTO `Model` (`id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(3, NULL, 'wcmf test', '?', '2012-05-11 08:48:45', 'admin', 'admin', '2013-02-21 22:36:23', 3);

-- --------------------------------------------------------

--
-- Table structure for table `NMChiControllerActionKeyChiController`
--

DROP TABLE IF EXISTS `NMChiControllerActionKeyChiController`;
CREATE TABLE IF NOT EXISTS `NMChiControllerActionKeyChiController` (
  `id` int(11) NOT NULL,
  `fk_chicontrolleractionkeysource_id` int(11) DEFAULT NULL,
  `fk_chicontrolleractionkeytarget_id` int(11) DEFAULT NULL,
  `action` varchar(255) DEFAULT NULL,
  `config` varchar(255) DEFAULT NULL,
  `context` varchar(255) DEFAULT NULL,
  `sourcename` varchar(255) DEFAULT NULL,
  `sourcemultiplicity` varchar(255) DEFAULT NULL,
  `sourcenavigability` varchar(255) DEFAULT NULL,
  `targetname` varchar(255) DEFAULT NULL,
  `targetmultiplicity` varchar(255) DEFAULT NULL,
  `targetnavigability` varchar(255) DEFAULT NULL,
  `relationtype` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chicontrolleractionkeysource_id` (`fk_chicontrolleractionkeysource_id`),
  KEY `fk_chicontrolleractionkeytarget_id` (`fk_chicontrolleractionkeytarget_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `NMChiControllerActionKeyChiController`
--

INSERT INTO `NMChiControllerActionKeyChiController` (`id`, `fk_chicontrolleractionkeysource_id`, `fk_chicontrolleractionkeytarget_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(4908, 206, 206, 'dologin', 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'association', 'dologin', NULL, '2013-02-20 14:57:47', 'admin', 'admin', '2013-02-20 14:58:07', NULL);
INSERT INTO `NMChiControllerActionKeyChiController` (`id`, `fk_chicontrolleractionkeysource_id`, `fk_chicontrolleractionkeytarget_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(4901, 206, 206, 'failure', 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'association', 'failure', '?', '2013-02-20 14:57:34', 'admin', 'admin', '2013-02-20 14:57:59', NULL);
INSERT INTO `NMChiControllerActionKeyChiController` (`id`, `fk_chicontrolleractionkeysource_id`, `fk_chicontrolleractionkeytarget_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(4880, 206, 198, 'ok', 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'association', 'ok', '?', '2013-02-20 14:56:06', 'admin', 'admin', '2013-02-20 14:57:34', NULL);
INSERT INTO `NMChiControllerActionKeyChiController` (`id`, `fk_chicontrolleractionkeysource_id`, `fk_chicontrolleractionkeytarget_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(4873, 257, 206, 'logout', 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'association', 'logout', '?', '2013-02-20 14:55:52', 'admin', 'admin', '2013-02-20 14:56:42', NULL);
INSERT INTO `NMChiControllerActionKeyChiController` (`id`, `fk_chicontrolleractionkeysource_id`, `fk_chicontrolleractionkeytarget_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(4866, 257, 206, 'login', 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'association', 'login', '?', '2013-02-20 14:55:35', 'admin', 'admin', '2013-02-20 14:55:52', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `NMChiControllerActionKeyChiView`
--

DROP TABLE IF EXISTS `NMChiControllerActionKeyChiView`;
CREATE TABLE IF NOT EXISTS `NMChiControllerActionKeyChiView` (
  `id` int(11) NOT NULL,
  `fk_chiview_id` int(11) DEFAULT NULL,
  `fk_chicontroller_id` int(11) DEFAULT NULL,
  `action` varchar(255) DEFAULT NULL,
  `config` varchar(255) DEFAULT NULL,
  `context` varchar(255) DEFAULT NULL,
  `sourcename` varchar(255) DEFAULT NULL,
  `sourcemultiplicity` varchar(255) DEFAULT NULL,
  `sourcenavigability` varchar(255) DEFAULT NULL,
  `targetname` varchar(255) DEFAULT NULL,
  `targetmultiplicity` varchar(255) DEFAULT NULL,
  `targetnavigability` varchar(255) DEFAULT NULL,
  `relationtype` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chiview_id` (`fk_chiview_id`),
  KEY `fk_chicontroller_id` (`fk_chicontroller_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `NMChiControllerChiController`
--

DROP TABLE IF EXISTS `NMChiControllerChiController`;
CREATE TABLE IF NOT EXISTS `NMChiControllerChiController` (
  `id` int(11) NOT NULL,
  `fk_chicontrollersource_id` int(11) DEFAULT NULL,
  `fk_chicontrollertarget_id` int(11) DEFAULT NULL,
  `sourcename` varchar(255) DEFAULT NULL,
  `sourcemultiplicity` varchar(255) DEFAULT NULL,
  `sourcenavigability` varchar(255) DEFAULT NULL,
  `targetname` varchar(255) DEFAULT NULL,
  `targetmultiplicity` varchar(255) DEFAULT NULL,
  `targetnavigability` varchar(255) DEFAULT NULL,
  `relationtype` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chicontrollersource_id` (`fk_chicontrollersource_id`),
  KEY `fk_chicontrollertarget_id` (`fk_chicontrollertarget_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `NMChiNodeChiMany2Many`
--

DROP TABLE IF EXISTS `NMChiNodeChiMany2Many`;
CREATE TABLE IF NOT EXISTS `NMChiNodeChiMany2Many` (
  `id` int(11) NOT NULL,
  `fk_chinode_id` int(11) DEFAULT NULL,
  `fk_chinodemanytomany_id` int(11) DEFAULT NULL,
  `sourcename` varchar(255) DEFAULT NULL,
  `sourcemultiplicity` varchar(255) DEFAULT NULL,
  `sourcenavigability` varchar(255) DEFAULT NULL,
  `targetname` varchar(255) DEFAULT NULL,
  `targetmultiplicity` varchar(255) DEFAULT NULL,
  `targetnavigability` varchar(255) DEFAULT NULL,
  `relationtype` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `fk_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chinode_id` (`fk_chinode_id`),
  KEY `fk_chinodemanytomany_id` (`fk_chinodemanytomany_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `NMChiNodeChiMany2Many`
--

INSERT INTO `NMChiNodeChiMany2Many` (`id`, `fk_chinode_id`, `fk_chinodemanytomany_id`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `fk_name`) VALUES(5146, 5113, 4437, NULL, '513', 'Navigable', NULL, '522', 'Navigable', 'composition', 'Composition', '?', '2013-02-21 22:09:48', 'admin', 'admin', '2013-02-21 22:13:23', NULL, NULL);
INSERT INTO `NMChiNodeChiMany2Many` (`id`, `fk_chinode_id`, `fk_chinodemanytomany_id`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `fk_name`) VALUES(5153, 264, 4437, NULL, '513', 'Navigable', NULL, '522', 'Navigable', 'composition', 'Composition', '?', '2013-02-21 22:10:35', 'admin', 'admin', '2013-02-21 22:14:43', NULL, NULL);
INSERT INTO `NMChiNodeChiMany2Many` (`id`, `fk_chinode_id`, `fk_chinodemanytomany_id`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `fk_name`) VALUES(4281, 323, 4268, NULL, '513', 'Navigable', NULL, '522', 'Navigable', 'composition', 'Composition', '?', '2012-06-26 23:30:10', 'admin', 'admin', '2012-06-26 23:31:43', NULL, 'fk_role_id');
INSERT INTO `NMChiNodeChiMany2Many` (`id`, `fk_chinode_id`, `fk_chinodemanytomany_id`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `fk_name`) VALUES(4287, 337, 4268, NULL, '513', 'Navigable', NULL, '522', 'Navigable', 'composition', 'Composition', '?', '2012-06-26 23:30:48', 'admin', 'admin', '2012-06-26 23:31:29', NULL, 'fk_user_id');

-- --------------------------------------------------------

--
-- Table structure for table `NMChiUseCaseChiUseCase`
--

DROP TABLE IF EXISTS `NMChiUseCaseChiUseCase`;
CREATE TABLE IF NOT EXISTS `NMChiUseCaseChiUseCase` (
  `id` int(11) NOT NULL,
  `fk_chiusecasecoresource_id` int(11) DEFAULT NULL,
  `fk_chiusecasecoretarget_id` int(11) DEFAULT NULL,
  `fk_chiusecasetarget_id` int(11) DEFAULT NULL,
  `fk_chiusecasesource_id` int(11) DEFAULT NULL,
  `sourcename` varchar(255) DEFAULT NULL,
  `sourcemultiplicity` varchar(255) DEFAULT NULL,
  `sourcenavigability` varchar(255) DEFAULT NULL,
  `targetname` varchar(255) DEFAULT NULL,
  `targetmultiplicity` varchar(255) DEFAULT NULL,
  `targetnavigability` varchar(255) DEFAULT NULL,
  `relationtype` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chiusecasecoresource_id` (`fk_chiusecasecoresource_id`),
  KEY `fk_chiusecasecoretarget_id` (`fk_chiusecasecoretarget_id`),
  KEY `fk_chiusecasetarget_id` (`fk_chiusecasetarget_id`),
  KEY `fk_chiusecasesource_id` (`fk_chiusecasesource_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `NMFeatureRequirements`
--

DROP TABLE IF EXISTS `NMFeatureRequirements`;
CREATE TABLE IF NOT EXISTS `NMFeatureRequirements` (
  `id` int(11) NOT NULL,
  `fk_chifeature_id` int(11) DEFAULT NULL,
  `fk_chirequirement_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chifeature_id` (`fk_chifeature_id`),
  KEY `fk_chirequirement_id` (`fk_chirequirement_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `NMFiguresDiagram`
--

DROP TABLE IF EXISTS `NMFiguresDiagram`;
CREATE TABLE IF NOT EXISTS `NMFiguresDiagram` (
  `id` int(11) NOT NULL,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `NMUCActor`
--

DROP TABLE IF EXISTS `NMUCActor`;
CREATE TABLE IF NOT EXISTS `NMUCActor` (
  `id` int(11) NOT NULL,
  `fk_chiworkerexternal_id` int(11) DEFAULT NULL,
  `fk_chiworkerinternal_id` int(11) DEFAULT NULL,
  `fk_chiworker_id` int(11) DEFAULT NULL,
  `fk_chibusinesspartneractive_id` int(11) DEFAULT NULL,
  `fk_chibusinesspartnerpassive_id` int(11) DEFAULT NULL,
  `fk_chibusinesspartner_id` int(11) DEFAULT NULL,
  `fk_chibusinessusecasecore_id` int(11) DEFAULT NULL,
  `fk_chibusinessusecase_id` int(11) DEFAULT NULL,
  `fk_actor_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chiworkerexternal_id` (`fk_chiworkerexternal_id`),
  KEY `fk_chiworkerinternal_id` (`fk_chiworkerinternal_id`),
  KEY `fk_chiworker_id` (`fk_chiworker_id`),
  KEY `fk_chibusinesspartneractive_id` (`fk_chibusinesspartneractive_id`),
  KEY `fk_chibusinesspartnerpassive_id` (`fk_chibusinesspartnerpassive_id`),
  KEY `fk_chibusinesspartner_id` (`fk_chibusinesspartner_id`),
  KEY `fk_chibusinessusecasecore_id` (`fk_chibusinessusecasecore_id`),
  KEY `fk_chibusinessusecase_id` (`fk_chibusinessusecase_id`),
  KEY `fk_actor_id` (`fk_actor_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `nm_user_role`
--

DROP TABLE IF EXISTS `nm_user_role`;
CREATE TABLE IF NOT EXISTS `nm_user_role` (
  `fk_user_id` int(11) NOT NULL DEFAULT '0',
  `fk_role_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`fk_user_id`,`fk_role_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `nm_user_role`
--

INSERT INTO `nm_user_role` (`fk_user_id`, `fk_role_id`) VALUES(2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `ObjectFlow`
--

DROP TABLE IF EXISTS `ObjectFlow`;
CREATE TABLE IF NOT EXISTS `ObjectFlow` (
  `id` int(11) NOT NULL,
  `fk_aobjectflowtarget_id` int(11) DEFAULT NULL,
  `fk_aobjectflowsource_id` int(11) DEFAULT NULL,
  `fk_chiobjectobjectflowsource_id` int(11) DEFAULT NULL,
  `fk_chiobjectobjectflowtarget_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_aobjectflowtarget_id` (`fk_aobjectflowtarget_id`),
  KEY `fk_aobjectflowsource_id` (`fk_aobjectflowsource_id`),
  KEY `fk_chiobjectobjectflowsource_id` (`fk_chiobjectobjectflowsource_id`),
  KEY `fk_chiobjectobjectflowtarget_id` (`fk_chiobjectobjectflowtarget_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Operation`
--

DROP TABLE IF EXISTS `Operation`;
CREATE TABLE IF NOT EXISTS `Operation` (
  `id` int(11) NOT NULL,
  `fk_chinodemanytomany_id` int(11) DEFAULT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_chicontroller_id` int(11) DEFAULT NULL,
  `fk_chinode_id` int(11) DEFAULT NULL,
  `parameters` varchar(255) DEFAULT NULL,
  `returntype` varchar(255) DEFAULT NULL,
  `visibility` varchar(255) DEFAULT NULL,
  `isabstract` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chinodemanytomany_id` (`fk_chinodemanytomany_id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_chicontroller_id` (`fk_chicontroller_id`),
  KEY `fk_chinode_id` (`fk_chinode_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Package`
--

DROP TABLE IF EXISTS `Package`;
CREATE TABLE IF NOT EXISTS `Package` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_model_id` int(11) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_model_id` (`fk_model_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Package`
--

INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(4, NULL, 3, NULL, 'PrimitiveTypes', '?', '2012-05-11 08:48:45', 'admin', 'admin', '2012-06-20 23:39:57', 4);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(5, NULL, 3, NULL, 'root', '?', '2012-05-11 08:48:45', 'admin', 'admin', '2013-02-19 15:45:27', 5);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(6, 5, NULL, NULL, 'configuration', NULL, '2012-05-11 08:48:45', 'admin', 'admin', '2012-05-11 08:49:36', 6);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(7, 6, NULL, NULL, 'default', NULL, '2012-05-11 08:48:46', 'admin', 'admin', '2012-05-11 08:49:36', 7);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(8, 7, NULL, NULL, 'config.ini', NULL, '2012-05-11 08:48:46', 'admin', 'admin', '2012-05-11 08:49:36', 8);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(39, 7, NULL, NULL, 'admin.ini', '?', '2012-05-11 08:48:50', 'admin', 'admin', '2012-06-23 01:04:36', 39);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(42, 7, NULL, NULL, 'server.ini', '?', '2012-05-11 08:48:50', 'admin', 'admin', '2012-06-23 01:20:08', 42);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(59, 7, NULL, NULL, 'persistence.ini', '?', '2012-05-11 08:48:53', 'admin', 'admin', '2012-06-23 01:25:09', 59);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(74, 7, NULL, NULL, 'presentation.ini', '?', '2012-05-11 08:48:55', 'admin', 'admin', '2012-06-23 01:31:29', 74);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(188, 5, NULL, NULL, 'wcmf', NULL, '2012-05-11 08:49:13', 'admin', 'admin', '2012-05-11 08:50:27', 188);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(189, 188, NULL, NULL, 'application', NULL, '2012-05-11 08:49:13', 'admin', 'admin', '2012-05-11 08:50:28', 189);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(190, 189, NULL, NULL, 'controller', NULL, '2012-05-11 08:49:14', 'admin', 'admin', '2012-05-11 08:50:28', 190);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(224, 190, NULL, NULL, 'admintool', NULL, '2012-05-11 08:49:18', 'admin', 'admin', '2012-05-11 08:50:41', 224);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(233, 189, NULL, NULL, 'views', NULL, '2012-05-11 08:49:19', 'admin', 'admin', '2012-05-11 08:50:45', 233);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(245, 233, NULL, NULL, 'admintool', NULL, '2012-05-11 08:49:21', 'admin', 'admin', '2012-05-11 08:50:47', 245);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(251, 233, NULL, NULL, 'forms', NULL, '2012-05-11 08:49:22', 'admin', 'admin', '2012-05-11 08:50:48', 251);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(253, 188, NULL, NULL, 'lib', NULL, '2012-05-11 08:49:22', 'admin', 'admin', '2012-05-11 08:50:49', 253);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(254, 253, NULL, NULL, 'model', NULL, '2012-05-11 08:49:22', 'admin', 'admin', '2012-05-11 08:50:49', 254);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(256, 253, NULL, NULL, 'presentation', NULL, '2012-05-11 08:49:22', 'admin', 'admin', '2012-05-11 08:50:50', 256);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(258, 253, NULL, NULL, 'security', '?', '2012-05-11 08:49:22', 'admin', 'admin', '2012-06-26 23:52:10', 258);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(259, 5, NULL, NULL, 'testapp', '?', '2012-05-11 08:49:22', 'admin', 'admin', '2013-02-19 15:44:46', 259);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(260, 259, NULL, NULL, 'application', '?', '2012-05-11 08:49:22', 'admin', 'admin', '2013-02-20 13:54:46', 260);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(261, 260, NULL, NULL, 'controller', NULL, '2012-05-11 08:49:23', 'admin', 'admin', '2012-05-11 08:50:51', 261);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(262, 260, NULL, NULL, 'views', NULL, '2012-05-11 08:49:23', 'admin', 'admin', '2012-05-11 08:50:51', 262);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(263, 260, NULL, NULL, 'model', '?', '2012-05-11 08:49:23', 'admin', 'admin', '2012-06-19 00:15:39', 263);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(310, 263, NULL, NULL, 'wcmf', '?', '2012-05-11 08:49:30', 'admin', 'admin', '2013-02-21 22:13:33', 8);

-- --------------------------------------------------------

--
-- Table structure for table `ProductionRule`
--

DROP TABLE IF EXISTS `ProductionRule`;
CREATE TABLE IF NOT EXISTS `ProductionRule` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_productionruleset_id` int(11) DEFAULT NULL,
  `priority` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_productionruleset_id` (`fk_productionruleset_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ProductionRuleSet`
--

DROP TABLE IF EXISTS `ProductionRuleSet`;
CREATE TABLE IF NOT EXISTS `ProductionRuleSet` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_activityset_id` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_activityset_id` (`fk_activityset_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Property`
--

DROP TABLE IF EXISTS `Property`;
CREATE TABLE IF NOT EXISTS `Property` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_chicontroller_id` int(11) DEFAULT NULL,
  `fk_chisystem_id` int(11) DEFAULT NULL,
  `default` varchar(255) DEFAULT NULL,
  `propertytype` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_chicontroller_id` (`fk_chicontroller_id`),
  KEY `fk_chisystem_id` (`fk_chisystem_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Relation`
--

DROP TABLE IF EXISTS `Relation`;
CREATE TABLE IF NOT EXISTS `Relation` (
  `id` int(11) NOT NULL,
  `sourcename` varchar(255) DEFAULT NULL,
  `sourcemultiplicity` varchar(255) DEFAULT NULL,
  `sourcenavigability` varchar(255) DEFAULT NULL,
  `targetname` varchar(255) DEFAULT NULL,
  `targetmultiplicity` varchar(255) DEFAULT NULL,
  `targetnavigability` varchar(255) DEFAULT NULL,
  `relationtype` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `RelationMultiplicity`
--

DROP TABLE IF EXISTS `RelationMultiplicity`;
CREATE TABLE IF NOT EXISTS `RelationMultiplicity` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `RelationMultiplicity`
--

INSERT INTO `RelationMultiplicity` (`id`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(513, '1', NULL, '2012-05-11 08:50:52', 'admin', 'admin', '2012-05-11 08:50:52', NULL);
INSERT INTO `RelationMultiplicity` (`id`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(514, '1..*', NULL, '2012-05-11 08:50:52', 'admin', 'admin', '2012-05-11 08:50:52', NULL);
INSERT INTO `RelationMultiplicity` (`id`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(522, '*', NULL, '2012-05-11 08:50:55', 'admin', 'admin', '2012-05-11 08:50:55', NULL);
INSERT INTO `RelationMultiplicity` (`id`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(542, '0..1', NULL, '2012-05-11 08:51:02', 'admin', 'admin', '2012-05-11 08:51:02', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `RelationType`
--

DROP TABLE IF EXISTS `RelationType`;
CREATE TABLE IF NOT EXISTS `RelationType` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
CREATE TABLE IF NOT EXISTS `role` (
  `id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`id`, `name`) VALUES(1, 'administrators');

-- --------------------------------------------------------

--
-- Table structure for table `RuleAction`
--

DROP TABLE IF EXISTS `RuleAction`;
CREATE TABLE IF NOT EXISTS `RuleAction` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_productionrule_id` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_productionrule_id` (`fk_productionrule_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `RuleCondition`
--

DROP TABLE IF EXISTS `RuleCondition`;
CREATE TABLE IF NOT EXISTS `RuleCondition` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_productionrule_id` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_productionrule_id` (`fk_productionrule_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `RuleSetVariable`
--

DROP TABLE IF EXISTS `RuleSetVariable`;
CREATE TABLE IF NOT EXISTS `RuleSetVariable` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_productionruleset_id` int(11) DEFAULT NULL,
  `context` varchar(255) DEFAULT NULL,
  `rulevalue` varchar(255) DEFAULT NULL,
  `variabletype` varchar(255) DEFAULT NULL,
  `iseditable` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_productionruleset_id` (`fk_productionruleset_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `RuleVariable`
--

DROP TABLE IF EXISTS `RuleVariable`;
CREATE TABLE IF NOT EXISTS `RuleVariable` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_productionrule_id` int(11) DEFAULT NULL,
  `context` varchar(255) DEFAULT NULL,
  `rulevalue` varchar(255) DEFAULT NULL,
  `variabletype` varchar(255) DEFAULT NULL,
  `iseditable` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_productionrule_id` (`fk_productionrule_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Translation`
--

DROP TABLE IF EXISTS `Translation`;
CREATE TABLE IF NOT EXISTS `Translation` (
  `id` int(11) NOT NULL,
  `objectid` varchar(255) DEFAULT NULL,
  `attribute` varchar(255) DEFAULT NULL,
  `translation` text,
  `language` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL,
  `login` varchar(50) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `firstname` varchar(50) DEFAULT NULL,
  `config` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `login`, `password`, `name`, `firstname`, `config`) VALUES(2, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'Administrator', NULL, 'admin.ini');

-- --------------------------------------------------------

--
-- Table structure for table `user_config`
--

DROP TABLE IF EXISTS `user_config`;
CREATE TABLE IF NOT EXISTS `user_config` (
  `id` int(11) NOT NULL,
  `fk_user_id` int(11) DEFAULT NULL,
  `key` varchar(255) DEFAULT NULL,
  `val` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_user_id` (`fk_user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_config`
--

INSERT INTO `user_config` (`id`, `fk_user_id`, `key`, `val`) VALUES(1, 2, 'last_browser_model', 'Model:3');

-- --------------------------------------------------------

--
-- Table structure for table `Visibility`
--

DROP TABLE IF EXISTS `Visibility`;
CREATE TABLE IF NOT EXISTS `Visibility` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Visibility`
--

INSERT INTO `Visibility` (`id`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(511, 'public', NULL, '2012-05-11 08:50:49', 'admin', 'admin', '2012-05-11 08:50:49', NULL);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
