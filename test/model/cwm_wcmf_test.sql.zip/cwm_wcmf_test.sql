-- phpMyAdmin SQL Dump
-- version 3.4.10.1deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 11, 2012 at 08:53 AM
-- Server version: 5.5.22
-- PHP Version: 5.3.10-1ubuntu3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `cwm_wcmf_test`
--

-- --------------------------------------------------------

--
-- Table structure for table `Activity`
--

CREATE TABLE IF NOT EXISTS `Activity` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_productionruleset_id` int(11) DEFAULT NULL,
  `fk_activityset_id` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_productionruleset_id` (`fk_productionruleset_id`),
  KEY `fk_activityset_id` (`fk_activityset_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ActivityDecision`
--

CREATE TABLE IF NOT EXISTS `ActivityDecision` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_productionruleset_id` int(11) DEFAULT NULL,
  `fk_activityset_id` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_productionruleset_id` (`fk_productionruleset_id`),
  KEY `fk_activityset_id` (`fk_activityset_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ActivityFinal`
--

CREATE TABLE IF NOT EXISTS `ActivityFinal` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_productionruleset_id` int(11) DEFAULT NULL,
  `fk_activityset_id` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_productionruleset_id` (`fk_productionruleset_id`),
  KEY `fk_activityset_id` (`fk_activityset_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ActivityInitial`
--

CREATE TABLE IF NOT EXISTS `ActivityInitial` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_productionruleset_id` int(11) DEFAULT NULL,
  `fk_activityset_id` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_productionruleset_id` (`fk_productionruleset_id`),
  KEY `fk_activityset_id` (`fk_activityset_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ActivityReceive`
--

CREATE TABLE IF NOT EXISTS `ActivityReceive` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_productionruleset_id` int(11) DEFAULT NULL,
  `fk_activityset_id` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_productionruleset_id` (`fk_productionruleset_id`),
  KEY `fk_activityset_id` (`fk_activityset_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ActivitySend`
--

CREATE TABLE IF NOT EXISTS `ActivitySend` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_productionruleset_id` int(11) DEFAULT NULL,
  `fk_activityset_id` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_productionruleset_id` (`fk_productionruleset_id`),
  KEY `fk_activityset_id` (`fk_activityset_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ActivitySet`
--

CREATE TABLE IF NOT EXISTS `ActivitySet` (
  `id` int(11) NOT NULL,
  `fk_chibusinessusecasecore_id` int(11) DEFAULT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_chibusinessusecase_id` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chibusinessusecasecore_id` (`fk_chibusinessusecasecore_id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_chibusinessusecase_id` (`fk_chibusinessusecase_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Actor`
--

CREATE TABLE IF NOT EXISTS `Actor` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `adodbseq`
--

CREATE TABLE IF NOT EXISTS `adodbseq` (
  `id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adodbseq`
--

INSERT INTO `adodbseq` (`id`) VALUES(648);

-- --------------------------------------------------------

--
-- Table structure for table `ChiActionKey`
--

CREATE TABLE IF NOT EXISTS `ChiActionKey` (
  `id` int(11) NOT NULL,
  `action` varchar(255) DEFAULT NULL,
  `config` varchar(255) DEFAULT NULL,
  `context` varchar(255) DEFAULT NULL,
  `sourcename` varchar(255) DEFAULT NULL,
  `sourcemultiplicity` varchar(255) DEFAULT NULL,
  `sourcenavigability` varchar(255) DEFAULT NULL,
  `targetname` varchar(255) DEFAULT NULL,
  `targetmultiplicity` varchar(255) DEFAULT NULL,
  `targetnavigability` varchar(255) DEFAULT NULL,
  `relationtype` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ChiAssociation`
--

CREATE TABLE IF NOT EXISTS `ChiAssociation` (
  `id` int(11) NOT NULL,
  `fk_chinodetarget_id` int(11) DEFAULT NULL,
  `fk_chinodesource_id` int(11) DEFAULT NULL,
  `fk_chinodemanytomanytarget_id` int(11) DEFAULT NULL,
  `fk_chinodemanytomanysource_id` int(11) DEFAULT NULL,
  `fk_name` varchar(255) DEFAULT NULL,
  `sourcename` varchar(255) DEFAULT NULL,
  `sourcemultiplicity` varchar(255) DEFAULT NULL,
  `sourcenavigability` varchar(255) DEFAULT NULL,
  `targetname` varchar(255) DEFAULT NULL,
  `targetmultiplicity` varchar(255) DEFAULT NULL,
  `targetnavigability` varchar(255) DEFAULT NULL,
  `relationtype` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chinodetarget_id` (`fk_chinodetarget_id`),
  KEY `fk_chinodesource_id` (`fk_chinodesource_id`),
  KEY `fk_chinodemanytomanytarget_id` (`fk_chinodemanytomanytarget_id`),
  KEY `fk_chinodemanytomanysource_id` (`fk_chinodemanytomanysource_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ChiAssociation`
--

INSERT INTO `ChiAssociation` (`id`, `fk_chinodetarget_id`, `fk_chinodesource_id`, `fk_chinodemanytomanytarget_id`, `fk_chinodemanytomanysource_id`, `fk_name`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(512, 278, 264, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'generalization', NULL, NULL, '2012-05-11 08:50:52', 'admin', 'admin', '2012-05-11 08:50:52', NULL);
INSERT INTO `ChiAssociation` (`id`, `fk_chinodetarget_id`, `fk_chinodesource_id`, `fk_chinodemanytomanytarget_id`, `fk_chinodemanytomanysource_id`, `fk_name`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(515, 292, 264, NULL, NULL, NULL, NULL, '513', 'Navigable', NULL, '514', 'Navigable', 'aggregation', NULL, NULL, '2012-05-11 08:50:52', 'admin', 'admin', '2012-05-11 08:50:52', NULL);
INSERT INTO `ChiAssociation` (`id`, `fk_chinodetarget_id`, `fk_chinodesource_id`, `fk_chinodemanytomanytarget_id`, `fk_chinodemanytomanysource_id`, `fk_name`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(521, 278, 271, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'generalization', NULL, NULL, '2012-05-11 08:50:55', 'admin', 'admin', '2012-05-11 08:50:55', NULL);
INSERT INTO `ChiAssociation` (`id`, `fk_chinodetarget_id`, `fk_chinodesource_id`, `fk_chinodemanytomanytarget_id`, `fk_chinodemanytomanysource_id`, `fk_name`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(523, NULL, 271, NULL, 302, NULL, NULL, '513', 'Navigable', NULL, '522', 'Navigable', 'aggregation', NULL, NULL, '2012-05-11 08:50:55', 'admin', 'admin', '2012-05-11 08:50:55', NULL);
INSERT INTO `ChiAssociation` (`id`, `fk_chinodetarget_id`, `fk_chinodesource_id`, `fk_chinodemanytomanytarget_id`, `fk_chinodemanytomanysource_id`, `fk_name`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(529, 255, 278, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'generalization', NULL, NULL, '2012-05-11 08:50:57', 'admin', 'admin', '2012-05-11 08:50:57', NULL);
INSERT INTO `ChiAssociation` (`id`, `fk_chinodetarget_id`, `fk_chinodesource_id`, `fk_chinodemanytomanytarget_id`, `fk_chinodemanytomanysource_id`, `fk_name`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(534, 278, 284, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'generalization', NULL, NULL, '2012-05-11 08:50:59', 'admin', 'admin', '2012-05-11 08:50:59', NULL);
INSERT INTO `ChiAssociation` (`id`, `fk_chinodetarget_id`, `fk_chinodesource_id`, `fk_chinodemanytomanytarget_id`, `fk_chinodemanytomanysource_id`, `fk_name`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(540, 278, 292, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'generalization', NULL, NULL, '2012-05-11 08:51:02', 'admin', 'admin', '2012-05-11 08:51:02', NULL);
INSERT INTO `ChiAssociation` (`id`, `fk_chinodetarget_id`, `fk_chinodesource_id`, `fk_chinodemanytomanytarget_id`, `fk_chinodemanytomanysource_id`, `fk_name`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(541, 292, 292, NULL, NULL, NULL, 'ChildPage', '522', 'Navigable', 'ParentPage', '513', 'Navigable', 'composition', NULL, NULL, '2012-05-11 08:51:02', 'admin', 'admin', '2012-05-11 08:51:02', NULL);
INSERT INTO `ChiAssociation` (`id`, `fk_chinodetarget_id`, `fk_chinodesource_id`, `fk_chinodemanytomanytarget_id`, `fk_chinodemanytomanysource_id`, `fk_name`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(543, 284, 292, NULL, NULL, NULL, 'TitlePage', '513', 'Navigable', 'TitleImage', '542', 'Navigable', 'aggregation', NULL, NULL, '2012-05-11 08:51:02', 'admin', 'admin', '2012-05-11 08:51:02', NULL);
INSERT INTO `ChiAssociation` (`id`, `fk_chinodetarget_id`, `fk_chinodesource_id`, `fk_chinodemanytomanytarget_id`, `fk_chinodemanytomanysource_id`, `fk_name`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(544, 284, 292, NULL, NULL, NULL, 'NormalPage', '513', 'Navigable', 'NormalImage', '522', 'Navigable', 'aggregation', NULL, NULL, '2012-05-11 08:51:02', 'admin', 'admin', '2012-05-11 08:51:02', NULL);
INSERT INTO `ChiAssociation` (`id`, `fk_chinodetarget_id`, `fk_chinodesource_id`, `fk_chinodemanytomanytarget_id`, `fk_chinodemanytomanysource_id`, `fk_name`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(545, NULL, 292, NULL, 302, NULL, NULL, '513', 'Navigable', NULL, '522', 'Navigable', 'aggregation', NULL, NULL, '2012-05-11 08:51:02', 'admin', 'admin', '2012-05-11 08:51:02', NULL);
INSERT INTO `ChiAssociation` (`id`, `fk_chinodetarget_id`, `fk_chinodesource_id`, `fk_chinodemanytomanytarget_id`, `fk_chinodemanytomanysource_id`, `fk_name`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(558, 255, 311, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'generalization', NULL, NULL, '2012-05-11 08:51:08', 'admin', 'admin', '2012-05-11 08:51:08', NULL);
INSERT INTO `ChiAssociation` (`id`, `fk_chinodetarget_id`, `fk_chinodesource_id`, `fk_chinodemanytomanytarget_id`, `fk_chinodemanytomanysource_id`, `fk_name`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(559, 255, 313, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'generalization', NULL, NULL, '2012-05-11 08:51:10', 'admin', 'admin', '2012-05-11 08:51:10', NULL);
INSERT INTO `ChiAssociation` (`id`, `fk_chinodetarget_id`, `fk_chinodesource_id`, `fk_chinodemanytomanytarget_id`, `fk_chinodemanytomanysource_id`, `fk_name`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(562, 255, 317, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'generalization', NULL, NULL, '2012-05-11 08:51:11', 'admin', 'admin', '2012-05-11 08:51:11', NULL);
INSERT INTO `ChiAssociation` (`id`, `fk_chinodetarget_id`, `fk_chinodesource_id`, `fk_chinodemanytomanytarget_id`, `fk_chinodemanytomanysource_id`, `fk_name`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(566, NULL, 323, NULL, 344, NULL, NULL, '513', 'Navigable', NULL, '522', 'Navigable', 'composition', NULL, NULL, '2012-05-11 08:51:12', 'admin', 'admin', '2012-05-11 08:51:12', NULL);
INSERT INTO `ChiAssociation` (`id`, `fk_chinodetarget_id`, `fk_chinodesource_id`, `fk_chinodemanytomanytarget_id`, `fk_chinodemanytomanysource_id`, `fk_name`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(568, 255, 326, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'generalization', NULL, NULL, '2012-05-11 08:51:13', 'admin', 'admin', '2012-05-11 08:51:13', NULL);
INSERT INTO `ChiAssociation` (`id`, `fk_chinodetarget_id`, `fk_chinodesource_id`, `fk_chinodemanytomanytarget_id`, `fk_chinodemanytomanysource_id`, `fk_name`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(573, 255, 332, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'generalization', NULL, NULL, '2012-05-11 08:51:15', 'admin', 'admin', '2012-05-11 08:51:15', NULL);
INSERT INTO `ChiAssociation` (`id`, `fk_chinodetarget_id`, `fk_chinodesource_id`, `fk_chinodemanytomanytarget_id`, `fk_chinodemanytomanysource_id`, `fk_name`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(576, 317, 337, NULL, NULL, NULL, NULL, '513', 'Navigable', NULL, '522', 'Navigable', 'composition', NULL, NULL, '2012-05-11 08:51:17', 'admin', 'admin', '2012-05-11 08:51:17', NULL);
INSERT INTO `ChiAssociation` (`id`, `fk_chinodetarget_id`, `fk_chinodesource_id`, `fk_chinodemanytomanytarget_id`, `fk_chinodemanytomanysource_id`, `fk_name`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(577, NULL, 337, NULL, 344, NULL, NULL, '513', 'Navigable', NULL, '522', 'Navigable', 'composition', NULL, NULL, '2012-05-11 08:51:17', 'admin', 'admin', '2012-05-11 08:51:17', NULL);
INSERT INTO `ChiAssociation` (`id`, `fk_chinodetarget_id`, `fk_chinodesource_id`, `fk_chinodemanytomanytarget_id`, `fk_chinodemanytomanysource_id`, `fk_name`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(578, 332, 337, NULL, NULL, NULL, NULL, '513', 'Navigable', NULL, '522', 'Navigable', 'composition', NULL, NULL, '2012-05-11 08:51:17', 'admin', 'admin', '2012-05-11 08:51:17', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ChiAuthors`
--

CREATE TABLE IF NOT EXISTS `ChiAuthors` (
  `id` int(11) NOT NULL,
  `role` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ChiAuthors`
--

INSERT INTO `ChiAuthors` (`id`, `role`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(349, NULL, 'null', NULL, '2012-05-11 08:49:37', 'admin', 'admin', '2012-05-11 08:49:37', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ChiBaseStatus`
--

CREATE TABLE IF NOT EXISTS `ChiBaseStatus` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ChiBaseStatus`
--

INSERT INTO `ChiBaseStatus` (`id`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(350, 'null', NULL, '2012-05-11 08:49:37', 'admin', 'admin', '2012-05-11 08:49:37', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ChiBusinessPartner`
--

CREATE TABLE IF NOT EXISTS `ChiBusinessPartner` (
  `id` int(11) NOT NULL,
  `fk_chibusinesspartneractive_id` int(11) DEFAULT NULL,
  `fk_chibusinesspartnerpassive_id` int(11) DEFAULT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_chibusinesspartner_id` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chibusinesspartneractive_id` (`fk_chibusinesspartneractive_id`),
  KEY `fk_chibusinesspartnerpassive_id` (`fk_chibusinesspartnerpassive_id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_chibusinesspartner_id` (`fk_chibusinesspartner_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ChiBusinessPartnerActive`
--

CREATE TABLE IF NOT EXISTS `ChiBusinessPartnerActive` (
  `id` int(11) NOT NULL,
  `fk_chibusinesspartnerpassive_id` int(11) DEFAULT NULL,
  `fk_chibusinesspartner_id` int(11) DEFAULT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_chibusinesspartneractive_id` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chibusinesspartnerpassive_id` (`fk_chibusinesspartnerpassive_id`),
  KEY `fk_chibusinesspartner_id` (`fk_chibusinesspartner_id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_chibusinesspartneractive_id` (`fk_chibusinesspartneractive_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ChiBusinessPartnerPassive`
--

CREATE TABLE IF NOT EXISTS `ChiBusinessPartnerPassive` (
  `id` int(11) NOT NULL,
  `fk_chibusinesspartneractive_id` int(11) DEFAULT NULL,
  `fk_chibusinesspartner_id` int(11) DEFAULT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_chibusinesspartnerpassive_id` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chibusinesspartneractive_id` (`fk_chibusinesspartneractive_id`),
  KEY `fk_chibusinesspartner_id` (`fk_chibusinesspartner_id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_chibusinesspartnerpassive_id` (`fk_chibusinesspartnerpassive_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ChiBusinessProcess`
--

CREATE TABLE IF NOT EXISTS `ChiBusinessProcess` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ChiBusinessUseCase`
--

CREATE TABLE IF NOT EXISTS `ChiBusinessUseCase` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_chifeature_id` int(11) DEFAULT NULL,
  `fk_chibusinessprocess_id` int(11) DEFAULT NULL,
  `primaryactor` varchar(255) DEFAULT NULL,
  `otheractors` varchar(255) DEFAULT NULL,
  `goalincontext` varchar(255) DEFAULT NULL,
  `scope` varchar(255) DEFAULT NULL,
  `level` varchar(255) DEFAULT NULL,
  `stakeholders` varchar(255) DEFAULT NULL,
  `precondition` varchar(255) DEFAULT NULL,
  `trigger` varchar(255) DEFAULT NULL,
  `mainsuccessscenario` varchar(255) DEFAULT NULL,
  `extensions` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_chifeature_id` (`fk_chifeature_id`),
  KEY `fk_chibusinessprocess_id` (`fk_chibusinessprocess_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ChiBusinessUseCaseCore`
--

CREATE TABLE IF NOT EXISTS `ChiBusinessUseCaseCore` (
  `id` int(11) NOT NULL,
  `fk_chibusinessprocess_id` int(11) DEFAULT NULL,
  `fk_chifeature_id` int(11) DEFAULT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `primaryactor` varchar(255) DEFAULT NULL,
  `otheractors` varchar(255) DEFAULT NULL,
  `goalincontext` varchar(255) DEFAULT NULL,
  `scope` varchar(255) DEFAULT NULL,
  `level` varchar(255) DEFAULT NULL,
  `stakeholders` varchar(255) DEFAULT NULL,
  `precondition` varchar(255) DEFAULT NULL,
  `trigger` varchar(255) DEFAULT NULL,
  `mainsuccessscenario` varchar(255) DEFAULT NULL,
  `extensions` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chibusinessprocess_id` (`fk_chibusinessprocess_id`),
  KEY `fk_chifeature_id` (`fk_chifeature_id`),
  KEY `fk_package_id` (`fk_package_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ChiClass`
--

CREATE TABLE IF NOT EXISTS `ChiClass` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `visibility` varchar(255) DEFAULT NULL,
  `isabstract` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ChiController`
--

CREATE TABLE IF NOT EXISTS `ChiController` (
  `id` int(11) NOT NULL,
  `fk_chibusinessusecasecore_id` int(11) DEFAULT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_chibusinessusecase_id` int(11) DEFAULT NULL,
  `visibility` varchar(255) DEFAULT NULL,
  `isabstract` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chibusinessusecasecore_id` (`fk_chibusinessusecasecore_id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_chibusinessusecase_id` (`fk_chibusinessusecase_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ChiController`
--

INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(191, NULL, 190, NULL, NULL, 'false', '350', 'Chi043Contr', '349', 'null', 'ActionSetController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:28', NULL, 191);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(192, NULL, 190, NULL, NULL, 'false', '350', 'Chi044Contr', '349', 'null', 'AssociateController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:29', NULL, 192);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(193, NULL, 190, NULL, NULL, 'false', '350', 'Chi045Contr', '349', 'null', 'BatchController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:29', NULL, 193);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(194, NULL, 190, NULL, NULL, 'false', '350', 'Chi046Contr', '349', 'null', 'BatchDisplayController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:29', NULL, 194);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(195, NULL, 190, NULL, NULL, 'false', '350', 'Chi047Contr', '349', 'null', 'ConcurrencyController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:30', NULL, 195);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(196, NULL, 190, NULL, NULL, 'false', '350', 'Chi048Contr', '349', 'null', 'CopyController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:30', NULL, 196);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(197, NULL, 190, NULL, NULL, 'false', '350', 'Chi049Contr', '349', 'null', 'DeleteController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:31', NULL, 197);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(198, NULL, 190, NULL, NULL, 'false', '350', 'Chi050Contr', '349', 'null', 'DisplayController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:31', NULL, 198);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(199, NULL, 190, NULL, NULL, 'false', '350', 'Chi051Contr', '349', 'null', 'ElFinderController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:32', NULL, 199);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(200, NULL, 190, NULL, NULL, 'false', '350', 'Chi052Contr', '349', 'null', 'ExitController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:32', NULL, 200);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(201, NULL, 190, NULL, NULL, 'false', '350', 'Chi053Contr', '349', 'null', 'FailureController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:32', NULL, 201);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(202, NULL, 190, NULL, NULL, 'false', '350', 'Chi054Contr', '349', 'null', 'InsertController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:33', NULL, 202);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(203, NULL, 190, NULL, NULL, 'false', '350', 'Chi055Contr', '349', 'null', 'ListboxController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:33', NULL, 203);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(204, NULL, 190, NULL, NULL, 'false', '350', 'Chi056Contr', '349', 'null', 'ListController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:33', NULL, 204);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(205, NULL, 190, NULL, NULL, 'false', '350', 'Chi057Contr', '349', 'null', 'LoggingController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:34', NULL, 205);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(206, NULL, 190, NULL, NULL, 'false', '350', 'Chi058Contr', '349', 'null', 'LoginController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:34', NULL, 206);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(207, NULL, 190, NULL, NULL, 'false', '350', 'Chi059Contr', '349', 'null', 'LongTaskController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:34', NULL, 207);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(208, NULL, 190, NULL, NULL, 'false', '350', 'Chi060Contr', '349', 'null', 'PageExportController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:35', NULL, 208);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(209, NULL, 190, NULL, NULL, 'false', '350', 'Chi061Contr', '349', 'null', 'ResourceTreeController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:35', NULL, 209);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(210, NULL, 190, NULL, NULL, 'false', '350', 'Chi062Contr', '349', 'null', 'RESTController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:35', NULL, 210);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(211, NULL, 190, NULL, NULL, 'false', '350', 'Chi063Contr', '349', 'null', 'SaveController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:36', NULL, 211);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(212, NULL, 190, NULL, NULL, 'false', '350', 'Chi064Contr', '349', 'null', 'SearchController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:36', NULL, 212);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(213, NULL, 190, NULL, NULL, 'false', '350', 'Chi065Contr', '349', 'null', 'SimpleBatchController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:37', NULL, 213);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(214, NULL, 190, NULL, NULL, 'false', '350', 'Chi066Contr', '349', 'null', 'SimpleLongTaskController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:37', NULL, 214);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(215, NULL, 190, NULL, NULL, 'false', '350', 'Chi067Contr', '349', 'null', 'SOAPController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:37', NULL, 215);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(216, NULL, 190, NULL, NULL, 'false', '350', 'Chi068Contr', '349', 'null', 'SortController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:38', NULL, 216);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(217, NULL, 190, NULL, NULL, 'false', '350', 'Chi069Contr', '349', 'null', 'TerminateController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:38', NULL, 217);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(218, NULL, 190, NULL, NULL, 'false', '350', 'Chi070Contr', '349', 'null', 'TextilePreviewController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:39', NULL, 218);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(219, NULL, 190, NULL, NULL, 'false', '350', 'Chi071Contr', '349', 'null', 'TreeViewController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:39', NULL, 219);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(220, NULL, 190, NULL, NULL, 'false', '350', 'Chi072Contr', '349', 'null', 'UserController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:40', NULL, 220);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(221, NULL, 190, NULL, NULL, 'false', '350', 'Chi073Contr', '349', 'null', 'ViewController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:40', NULL, 221);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(222, NULL, 190, NULL, NULL, 'false', '350', 'Chi074Contr', '349', 'null', 'WCMFFrontendController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:40', NULL, 222);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(223, NULL, 190, NULL, NULL, 'false', '350', 'Chi075Contr', '349', 'null', 'XMLExportController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:41', NULL, 223);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(225, NULL, 224, NULL, NULL, 'false', '350', 'Chi076Contr', '349', 'null', 'AdminController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:41', NULL, 225);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(226, NULL, 224, NULL, NULL, 'false', '350', 'Chi077Contr', '349', 'null', 'BackupController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:42', NULL, 226);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(227, NULL, 224, NULL, NULL, 'false', '350', 'Chi078Contr', '349', 'null', 'ConfigController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:42', NULL, 227);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(228, NULL, 224, NULL, NULL, 'false', '350', 'Chi079Contr', '349', 'null', 'CreateInstanceController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:43', NULL, 228);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(229, NULL, 224, NULL, NULL, 'false', '350', 'Chi080Contr', '349', 'null', 'EditRightsController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:43', NULL, 229);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(230, NULL, 224, NULL, NULL, 'false', '350', 'Chi081Contr', '349', 'null', 'MySQLBackupController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:43', NULL, 230);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(231, NULL, 224, NULL, NULL, 'false', '350', 'Chi082Contr', '349', 'null', 'PrincipalController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:44', NULL, 231);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(232, NULL, 224, NULL, NULL, 'false', '350', 'Chi083Contr', '349', 'null', 'SearchIndexController', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:44', NULL, 232);
INSERT INTO `ChiController` (`id`, `fk_chibusinessusecasecore_id`, `fk_package_id`, `fk_chibusinessusecase_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(257, NULL, 256, NULL, NULL, 'false', '350', 'Chi084Contr', '349', 'null', 'Controller', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:50', NULL, 257);

-- --------------------------------------------------------

--
-- Table structure for table `ChiFeature`
--

CREATE TABLE IF NOT EXISTS `ChiFeature` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `proofreader` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ChiFeatureStatus`
--

CREATE TABLE IF NOT EXISTS `ChiFeatureStatus` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ChiGoal`
--

CREATE TABLE IF NOT EXISTS `ChiGoal` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_chigoal_id` int(11) DEFAULT NULL,
  `goaltype` varchar(255) DEFAULT NULL,
  `priority` varchar(255) DEFAULT NULL,
  `value_ammount` varchar(255) DEFAULT NULL,
  `value_goal` varchar(255) DEFAULT NULL,
  `value_name` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_chigoal_id` (`fk_chigoal_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ChiGoalType`
--

CREATE TABLE IF NOT EXISTS `ChiGoalType` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ChiIssue`
--

CREATE TABLE IF NOT EXISTS `ChiIssue` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_chirequirement_id` int(11) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `responsible` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_chirequirement_id` (`fk_chirequirement_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ChiNode`
--

CREATE TABLE IF NOT EXISTS `ChiNode` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_chicontroller_id` int(11) DEFAULT NULL,
  `display_value` varchar(255) DEFAULT NULL,
  `table_name` varchar(255) DEFAULT NULL,
  `is_ordered` varchar(255) DEFAULT NULL,
  `parent_order` varchar(255) DEFAULT NULL,
  `child_order` varchar(255) DEFAULT NULL,
  `pk_name` varchar(255) DEFAULT NULL,
  `is_searchable` varchar(255) DEFAULT NULL,
  `orderby` varchar(255) DEFAULT NULL,
  `is_soap` varchar(255) DEFAULT NULL,
  `initparams` varchar(255) DEFAULT NULL,
  `visibility` varchar(255) DEFAULT NULL,
  `isabstract` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_chicontroller_id` (`fk_chicontroller_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ChiNode`
--

INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(255, 254, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'false', 'none', 'false', 'database', '511', 'true', NULL, 'Chi040Nod', NULL, '1.0', 'Node', NULL, '2012-05-11 08:49:22', 'admin', 'admin', '2012-05-11 08:50:49', NULL, 255);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(264, 263, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'false', 'sortkey', 'false', 'database', '511', 'false', NULL, 'Chi041Nod', NULL, '1.0', 'Author', NULL, '2012-05-11 08:49:23', 'admin', 'admin', '2012-05-11 08:50:52', NULL, 264);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(271, 263, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'false', 'title DESC', 'false', 'database', '511', 'false', NULL, 'Chi042Nod', NULL, '1.0', 'Document', NULL, '2012-05-11 08:49:24', 'admin', 'admin', '2012-05-11 08:50:55', NULL, 271);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(278, 263, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'false', 'none', 'false', 'database', '511', 'true', NULL, 'Chi043Nod', NULL, '1.0', 'EntityBase', NULL, '2012-05-11 08:49:25', 'admin', 'admin', '2012-05-11 08:50:57', NULL, 278);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(284, 263, NULL, 'file', NULL, NULL, NULL, NULL, NULL, 'false', 'none', 'false', 'database', '511', 'false', NULL, 'Chi044Nod', NULL, '1.0', 'Image', NULL, '2012-05-11 08:49:26', 'admin', 'admin', '2012-05-11 08:50:59', NULL, 284);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(292, 263, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'false', 'sortkey', 'false', 'database', '511', 'false', NULL, 'Chi045Nod', NULL, '1.0', 'Page', NULL, '2012-05-11 08:49:27', 'admin', 'admin', '2012-05-11 08:51:01', NULL, 292);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(311, 310, NULL, 'name', 'adodbseq', NULL, NULL, NULL, NULL, 'false', 'none', 'false', 'database', '511', 'false', NULL, 'Chi046Nod', NULL, '1.0', 'Adodbseq', NULL, '2012-05-11 08:49:30', 'admin', 'admin', '2012-05-11 08:51:08', NULL, 311);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(313, 310, NULL, 'name', 'language', NULL, NULL, NULL, NULL, 'false', 'name', 'false', 'database', '511', 'false', NULL, 'Chi047Nod', NULL, '1.0', 'Language', 'A llanguage for which a translation of the model can be created. The code is arbitrary but it is recommended to use the ISO language codes (en, de, it, ...).', '2012-05-11 08:49:30', 'admin', 'admin', '2012-05-11 08:51:09', NULL, 313);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(317, 310, NULL, 'name', 'locktable', NULL, NULL, NULL, NULL, 'false', 'none', 'false', 'database', '511', 'false', NULL, 'Chi048Nod', NULL, '1.0', 'Locktable', NULL, '2012-05-11 08:49:30', 'admin', 'admin', '2012-05-11 08:51:11', NULL, 317);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(323, 310, NULL, 'name', 'role', NULL, NULL, NULL, NULL, 'false', 'name', 'false', 'database', '511', 'false', NULL, 'Chi049Nod', NULL, '1.0', 'RoleRDB', NULL, '2012-05-11 08:49:31', 'admin', 'admin', '2012-05-11 08:51:12', NULL, 323);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(326, 310, NULL, 'objectid|attribute|language', 'translation', NULL, NULL, NULL, NULL, 'false', 'none', 'false', 'database', '511', 'false', NULL, 'Chi050Nod', NULL, '1.0', 'Translation', 'Instances of this class are used to localize entity attributes. Each instance defines a translation of one attribute of one entity into one language.', '2012-05-11 08:49:32', 'admin', 'admin', '2012-05-11 08:51:13', NULL, 326);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(332, 310, NULL, 'name', 'user_config', NULL, NULL, NULL, NULL, 'false', 'none', 'false', 'database', '511', 'false', NULL, 'Chi051Nod', NULL, '1.0', 'UserConfig', NULL, '2012-05-11 08:49:33', 'admin', 'admin', '2012-05-11 08:51:15', NULL, 332);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(337, 310, NULL, 'login', 'user', NULL, NULL, NULL, NULL, 'false', 'name', 'false', 'database', '511', 'false', NULL, 'Chi052Nod', NULL, '1.0', 'UserRDB', NULL, '2012-05-11 08:49:33', 'admin', 'admin', '2012-05-11 08:51:17', NULL, 337);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(351, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi053Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:49:37', 'admin', 'admin', '2012-05-11 08:49:37', NULL, 351);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(352, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi054Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:49:37', 'admin', 'admin', '2012-05-11 08:49:37', NULL, 352);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(353, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi055Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:49:38', 'admin', 'admin', '2012-05-11 08:49:38', NULL, 353);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(354, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi056Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:49:38', 'admin', 'admin', '2012-05-11 08:49:39', NULL, 354);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(355, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi057Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:49:39', 'admin', 'admin', '2012-05-11 08:49:39', NULL, 355);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(356, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi058Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:49:39', 'admin', 'admin', '2012-05-11 08:49:39', NULL, 356);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(357, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi059Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:49:39', 'admin', 'admin', '2012-05-11 08:49:40', NULL, 357);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(358, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi060Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:49:40', 'admin', 'admin', '2012-05-11 08:49:40', NULL, 358);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(359, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi061Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:49:40', 'admin', 'admin', '2012-05-11 08:49:40', NULL, 359);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(360, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi062Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:49:41', 'admin', 'admin', '2012-05-11 08:49:41', NULL, 360);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(361, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi063Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:49:41', 'admin', 'admin', '2012-05-11 08:49:41', NULL, 361);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(362, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi064Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:49:42', 'admin', 'admin', '2012-05-11 08:49:42', NULL, 362);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(363, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi065Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:49:42', 'admin', 'admin', '2012-05-11 08:49:42', NULL, 363);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(364, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi066Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:49:42', 'admin', 'admin', '2012-05-11 08:49:42', NULL, 364);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(365, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi067Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:49:43', 'admin', 'admin', '2012-05-11 08:49:43', NULL, 365);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(366, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi068Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:49:43', 'admin', 'admin', '2012-05-11 08:49:43', NULL, 366);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(367, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi069Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:49:44', 'admin', 'admin', '2012-05-11 08:49:44', NULL, 367);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(368, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi070Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:49:44', 'admin', 'admin', '2012-05-11 08:49:44', NULL, 368);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(369, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi071Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:49:44', 'admin', 'admin', '2012-05-11 08:49:45', NULL, 369);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(370, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi072Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:49:46', 'admin', 'admin', '2012-05-11 08:49:46', NULL, 370);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(371, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi073Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:49:46', 'admin', 'admin', '2012-05-11 08:49:47', NULL, 371);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(372, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi074Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:49:47', 'admin', 'admin', '2012-05-11 08:49:47', NULL, 372);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(373, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi075Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:49:47', 'admin', 'admin', '2012-05-11 08:49:47', NULL, 373);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(374, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi076Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:49:47', 'admin', 'admin', '2012-05-11 08:49:47', NULL, 374);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(375, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi077Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:49:48', 'admin', 'admin', '2012-05-11 08:49:48', NULL, 375);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(376, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi078Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:49:48', 'admin', 'admin', '2012-05-11 08:49:48', NULL, 376);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(377, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi079Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:49:49', 'admin', 'admin', '2012-05-11 08:49:49', NULL, 377);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(378, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi080Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:49:49', 'admin', 'admin', '2012-05-11 08:49:49', NULL, 378);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(379, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi081Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:49:49', 'admin', 'admin', '2012-05-11 08:49:50', NULL, 379);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(380, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi082Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:49:50', 'admin', 'admin', '2012-05-11 08:49:50', NULL, 380);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(381, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi083Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:49:51', 'admin', 'admin', '2012-05-11 08:49:51', NULL, 381);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(382, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi084Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:49:52', 'admin', 'admin', '2012-05-11 08:49:52', NULL, 382);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(383, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi085Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:49:52', 'admin', 'admin', '2012-05-11 08:49:52', NULL, 383);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(384, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi086Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:49:52', 'admin', 'admin', '2012-05-11 08:49:53', NULL, 384);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(385, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi087Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:49:53', 'admin', 'admin', '2012-05-11 08:49:53', NULL, 385);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(386, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi088Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:49:53', 'admin', 'admin', '2012-05-11 08:49:53', NULL, 386);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(387, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi089Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:49:54', 'admin', 'admin', '2012-05-11 08:49:54', NULL, 387);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(388, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi090Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:49:55', 'admin', 'admin', '2012-05-11 08:49:55', NULL, 388);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(389, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi091Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:49:55', 'admin', 'admin', '2012-05-11 08:49:56', NULL, 389);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(390, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi092Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:49:56', 'admin', 'admin', '2012-05-11 08:49:56', NULL, 390);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(391, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi093Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:49:56', 'admin', 'admin', '2012-05-11 08:49:56', NULL, 391);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(392, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi094Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:49:57', 'admin', 'admin', '2012-05-11 08:49:57', NULL, 392);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(393, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi095Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:49:57', 'admin', 'admin', '2012-05-11 08:49:57', NULL, 393);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(394, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi096Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:49:57', 'admin', 'admin', '2012-05-11 08:49:57', NULL, 394);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(395, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi097Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:49:58', 'admin', 'admin', '2012-05-11 08:49:58', NULL, 395);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(396, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi098Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:49:58', 'admin', 'admin', '2012-05-11 08:49:58', NULL, 396);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(397, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi099Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:49:59', 'admin', 'admin', '2012-05-11 08:49:59', NULL, 397);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(398, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi100Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:49:59', 'admin', 'admin', '2012-05-11 08:49:59', NULL, 398);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(399, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi101Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:49:59', 'admin', 'admin', '2012-05-11 08:49:59', NULL, 399);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(400, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi102Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:00', 'admin', 'admin', '2012-05-11 08:50:00', NULL, 400);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(401, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi103Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:00', 'admin', 'admin', '2012-05-11 08:50:00', NULL, 401);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(402, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi104Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:01', 'admin', 'admin', '2012-05-11 08:50:01', NULL, 402);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(403, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi105Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:01', 'admin', 'admin', '2012-05-11 08:50:01', NULL, 403);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(404, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi106Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:02', 'admin', 'admin', '2012-05-11 08:50:02', NULL, 404);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(405, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi107Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:02', 'admin', 'admin', '2012-05-11 08:50:02', NULL, 405);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(406, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi108Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:03', 'admin', 'admin', '2012-05-11 08:50:03', NULL, 406);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(407, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi109Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:03', 'admin', 'admin', '2012-05-11 08:50:03', NULL, 407);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(408, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi110Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:03', 'admin', 'admin', '2012-05-11 08:50:04', NULL, 408);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(409, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi111Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:05', 'admin', 'admin', '2012-05-11 08:50:06', NULL, 409);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(410, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi112Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:06', 'admin', 'admin', '2012-05-11 08:50:06', NULL, 410);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(411, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi113Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:06', 'admin', 'admin', '2012-05-11 08:50:06', NULL, 411);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(412, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi114Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:07', 'admin', 'admin', '2012-05-11 08:50:07', NULL, 412);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(413, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi115Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:07', 'admin', 'admin', '2012-05-11 08:50:07', NULL, 413);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(414, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi116Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:07', 'admin', 'admin', '2012-05-11 08:50:08', NULL, 414);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(415, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi117Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:08', 'admin', 'admin', '2012-05-11 08:50:08', NULL, 415);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(416, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi118Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:08', 'admin', 'admin', '2012-05-11 08:50:08', NULL, 416);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(417, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi119Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:09', 'admin', 'admin', '2012-05-11 08:50:09', NULL, 417);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(418, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi120Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:09', 'admin', 'admin', '2012-05-11 08:50:09', NULL, 418);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(419, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi121Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:09', 'admin', 'admin', '2012-05-11 08:50:09', NULL, 419);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(420, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi122Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:10', 'admin', 'admin', '2012-05-11 08:50:10', NULL, 420);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(421, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi123Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:10', 'admin', 'admin', '2012-05-11 08:50:10', NULL, 421);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(422, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi124Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:11', 'admin', 'admin', '2012-05-11 08:50:11', NULL, 422);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(423, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi125Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:11', 'admin', 'admin', '2012-05-11 08:50:11', NULL, 423);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(424, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi126Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:11', 'admin', 'admin', '2012-05-11 08:50:11', NULL, 424);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(425, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi127Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:11', 'admin', 'admin', '2012-05-11 08:50:12', NULL, 425);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(426, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi128Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:12', 'admin', 'admin', '2012-05-11 08:50:12', NULL, 426);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(427, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi129Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:12', 'admin', 'admin', '2012-05-11 08:50:12', NULL, 427);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(428, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi130Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:12', 'admin', 'admin', '2012-05-11 08:50:13', NULL, 428);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(429, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi131Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:13', 'admin', 'admin', '2012-05-11 08:50:13', NULL, 429);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(430, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi132Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:13', 'admin', 'admin', '2012-05-11 08:50:13', NULL, 430);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(431, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi133Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:13', 'admin', 'admin', '2012-05-11 08:50:13', NULL, 431);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(432, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi134Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:14', 'admin', 'admin', '2012-05-11 08:50:14', NULL, 432);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(433, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi135Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:14', 'admin', 'admin', '2012-05-11 08:50:14', NULL, 433);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(434, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi136Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:14', 'admin', 'admin', '2012-05-11 08:50:14', NULL, 434);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(435, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi137Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:15', 'admin', 'admin', '2012-05-11 08:50:15', NULL, 435);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(436, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi138Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:15', 'admin', 'admin', '2012-05-11 08:50:15', NULL, 436);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(437, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi139Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:15', 'admin', 'admin', '2012-05-11 08:50:15', NULL, 437);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(438, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi140Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:15', 'admin', 'admin', '2012-05-11 08:50:16', NULL, 438);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(439, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi141Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:16', 'admin', 'admin', '2012-05-11 08:50:16', NULL, 439);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(440, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi142Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:16', 'admin', 'admin', '2012-05-11 08:50:16', NULL, 440);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(441, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi143Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:16', 'admin', 'admin', '2012-05-11 08:50:16', NULL, 441);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(442, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi144Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:17', 'admin', 'admin', '2012-05-11 08:50:17', NULL, 442);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(443, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi145Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:17', 'admin', 'admin', '2012-05-11 08:50:17', NULL, 443);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(444, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi146Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:17', 'admin', 'admin', '2012-05-11 08:50:17', NULL, 444);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(445, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi147Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:18', 'admin', 'admin', '2012-05-11 08:50:18', NULL, 445);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(446, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi148Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:18', 'admin', 'admin', '2012-05-11 08:50:18', NULL, 446);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(447, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi149Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:19', 'admin', 'admin', '2012-05-11 08:50:19', NULL, 447);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(448, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi150Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:19', 'admin', 'admin', '2012-05-11 08:50:19', NULL, 448);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(449, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi151Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:20', 'admin', 'admin', '2012-05-11 08:50:20', NULL, 449);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(450, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi152Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:20', 'admin', 'admin', '2012-05-11 08:50:20', NULL, 450);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(451, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi153Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:20', 'admin', 'admin', '2012-05-11 08:50:21', NULL, 451);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(452, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi154Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:21', 'admin', 'admin', '2012-05-11 08:50:21', NULL, 452);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(453, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi155Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:21', 'admin', 'admin', '2012-05-11 08:50:21', NULL, 453);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(454, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi156Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:21', 'admin', 'admin', '2012-05-11 08:50:22', NULL, 454);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(455, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi157Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:22', 'admin', 'admin', '2012-05-11 08:50:22', NULL, 455);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(456, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi158Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:22', 'admin', 'admin', '2012-05-11 08:50:22', NULL, 456);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(457, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi159Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:22', 'admin', 'admin', '2012-05-11 08:50:23', NULL, 457);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(458, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi160Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:23', 'admin', 'admin', '2012-05-11 08:50:23', NULL, 458);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(459, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi161Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:23', 'admin', 'admin', '2012-05-11 08:50:23', NULL, 459);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(460, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi162Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:24', 'admin', 'admin', '2012-05-11 08:50:24', NULL, 460);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(461, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi163Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:24', 'admin', 'admin', '2012-05-11 08:50:24', NULL, 461);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(462, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi164Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:24', 'admin', 'admin', '2012-05-11 08:50:25', NULL, 462);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(463, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi165Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:25', 'admin', 'admin', '2012-05-11 08:50:25', NULL, 463);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(464, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi166Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:25', 'admin', 'admin', '2012-05-11 08:50:25', NULL, 464);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(465, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi167Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:26', 'admin', 'admin', '2012-05-11 08:50:26', NULL, 465);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(466, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi168Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:26', 'admin', 'admin', '2012-05-11 08:50:26', NULL, 466);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(467, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi169Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:26', 'admin', 'admin', '2012-05-11 08:50:26', NULL, 467);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(468, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi170Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:27', 'admin', 'admin', '2012-05-11 08:50:27', NULL, 468);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(469, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi171Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:27', 'admin', 'admin', '2012-05-11 08:50:27', NULL, 469);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(516, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi172Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:52', 'admin', 'admin', '2012-05-11 08:50:52', NULL, 516);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(517, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi173Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:53', 'admin', 'admin', '2012-05-11 08:50:53', NULL, 517);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(518, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi174Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:53', 'admin', 'admin', '2012-05-11 08:50:53', NULL, 518);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(519, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi175Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:53', 'admin', 'admin', '2012-05-11 08:50:53', NULL, 519);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(520, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi176Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:54', 'admin', 'admin', '2012-05-11 08:50:54', NULL, 520);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(524, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi177Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:55', 'admin', 'admin', '2012-05-11 08:50:55', NULL, 524);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(525, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi178Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:55', 'admin', 'admin', '2012-05-11 08:50:55', NULL, 525);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(526, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi179Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:56', 'admin', 'admin', '2012-05-11 08:50:56', NULL, 526);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(527, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi180Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:56', 'admin', 'admin', '2012-05-11 08:50:56', NULL, 527);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(528, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi181Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:56', 'admin', 'admin', '2012-05-11 08:50:56', NULL, 528);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(530, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi182Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:57', 'admin', 'admin', '2012-05-11 08:50:57', NULL, 530);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(531, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi183Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:57', 'admin', 'admin', '2012-05-11 08:50:57', NULL, 531);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(532, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi184Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:58', 'admin', 'admin', '2012-05-11 08:50:58', NULL, 532);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(533, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi185Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:58', 'admin', 'admin', '2012-05-11 08:50:58', NULL, 533);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(535, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi186Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:59', 'admin', 'admin', '2012-05-11 08:50:59', NULL, 535);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(536, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi187Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:50:59', 'admin', 'admin', '2012-05-11 08:51:00', NULL, 536);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(537, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi188Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:51:00', 'admin', 'admin', '2012-05-11 08:51:00', NULL, 537);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(538, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi189Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:51:00', 'admin', 'admin', '2012-05-11 08:51:00', NULL, 538);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(539, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi190Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:51:01', 'admin', 'admin', '2012-05-11 08:51:01', NULL, 539);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(546, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi191Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:51:03', 'admin', 'admin', '2012-05-11 08:51:03', NULL, 546);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(547, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi192Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:51:03', 'admin', 'admin', '2012-05-11 08:51:03', NULL, 547);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(548, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi193Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:51:03', 'admin', 'admin', '2012-05-11 08:51:03', NULL, 548);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(549, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi194Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:51:04', 'admin', 'admin', '2012-05-11 08:51:04', NULL, 549);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(550, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi195Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:51:04', 'admin', 'admin', '2012-05-11 08:51:04', NULL, 550);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(551, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi196Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:51:04', 'admin', 'admin', '2012-05-11 08:51:04', NULL, 551);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(554, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi197Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:51:06', 'admin', 'admin', '2012-05-11 08:51:06', NULL, 554);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(555, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi198Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:51:06', 'admin', 'admin', '2012-05-11 08:51:06', NULL, 555);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(556, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi199Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:51:06', 'admin', 'admin', '2012-05-11 08:51:07', NULL, 556);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(557, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi200Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:51:07', 'admin', 'admin', '2012-05-11 08:51:07', NULL, 557);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(560, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi201Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:51:10', 'admin', 'admin', '2012-05-11 08:51:10', NULL, 560);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(561, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi202Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:51:10', 'admin', 'admin', '2012-05-11 08:51:11', NULL, 561);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(563, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi203Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:51:11', 'admin', 'admin', '2012-05-11 08:51:11', NULL, 563);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(564, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi204Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:51:12', 'admin', 'admin', '2012-05-11 08:51:12', NULL, 564);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(565, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi205Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:51:12', 'admin', 'admin', '2012-05-11 08:51:12', NULL, 565);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(567, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi206Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:51:13', 'admin', 'admin', '2012-05-11 08:51:13', NULL, 567);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(569, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi207Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:51:13', 'admin', 'admin', '2012-05-11 08:51:13', NULL, 569);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(570, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi208Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:51:14', 'admin', 'admin', '2012-05-11 08:51:14', NULL, 570);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(571, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi209Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:51:14', 'admin', 'admin', '2012-05-11 08:51:14', NULL, 571);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(572, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi210Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:51:14', 'admin', 'admin', '2012-05-11 08:51:15', NULL, 572);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(574, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi211Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:51:16', 'admin', 'admin', '2012-05-11 08:51:16', NULL, 574);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(575, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi212Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:51:16', 'admin', 'admin', '2012-05-11 08:51:16', NULL, 575);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(579, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi213Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:51:17', 'admin', 'admin', '2012-05-11 08:51:17', NULL, 579);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(580, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi214Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:51:17', 'admin', 'admin', '2012-05-11 08:51:17', NULL, 580);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(581, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi215Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:51:18', 'admin', 'admin', '2012-05-11 08:51:18', NULL, 581);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(582, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi216Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:51:18', 'admin', 'admin', '2012-05-11 08:51:18', NULL, 582);
INSERT INTO `ChiNode` (`id`, `fk_package_id`, `fk_chicontroller_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(583, NULL, NULL, 'name', NULL, NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, 'false', '350', 'Chi217Nod', NULL, '1.0', NULL, NULL, '2012-05-11 08:51:18', 'admin', 'admin', '2012-05-11 08:51:18', NULL, 583);

-- --------------------------------------------------------

--
-- Table structure for table `ChiNodeManyToMany`
--

CREATE TABLE IF NOT EXISTS `ChiNodeManyToMany` (
  `id` int(11) NOT NULL,
  `fk_chicontroller_id` int(11) DEFAULT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `display_value` varchar(255) DEFAULT NULL,
  `table_name` varchar(255) DEFAULT NULL,
  `is_ordered` varchar(255) DEFAULT NULL,
  `parent_order` varchar(255) DEFAULT NULL,
  `child_order` varchar(255) DEFAULT NULL,
  `pk_name` varchar(255) DEFAULT NULL,
  `is_searchable` varchar(255) DEFAULT NULL,
  `orderby` varchar(255) DEFAULT NULL,
  `is_soap` varchar(255) DEFAULT NULL,
  `initparams` varchar(255) DEFAULT NULL,
  `visibility` varchar(255) DEFAULT NULL,
  `isabstract` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chicontroller_id` (`fk_chicontroller_id`),
  KEY `fk_package_id` (`fk_package_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ChiNodeManyToMany`
--

INSERT INTO `ChiNodeManyToMany` (`id`, `fk_chicontroller_id`, `fk_package_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(302, NULL, 263, 'name', NULL, NULL, NULL, NULL, NULL, 'false', 'sortkey', 'false', 'database', NULL, 'false', NULL, 'Chi001', NULL, '1.0', 'NMPageDocument', NULL, '2012-05-11 08:49:28', 'admin', 'admin', '2012-05-11 08:51:05', NULL, 302);
INSERT INTO `ChiNodeManyToMany` (`id`, `fk_chicontroller_id`, `fk_package_id`, `display_value`, `table_name`, `is_ordered`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(344, NULL, 310, 'name', 'nm_user_role', NULL, NULL, NULL, 'fk_user_id|fk_role_id', 'false', 'none', 'false', 'database', NULL, 'false', NULL, 'Chi001', NULL, '1.0', 'NMUserRole', NULL, '2012-05-11 08:49:35', 'admin', 'admin', '2012-05-11 08:51:19', NULL, 344);

-- --------------------------------------------------------

--
-- Table structure for table `ChiObject`
--

CREATE TABLE IF NOT EXISTS `ChiObject` (
  `id` int(11) NOT NULL,
  `fk_chinodemanytomany_id` int(11) DEFAULT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_chinode_id` int(11) DEFAULT NULL,
  `fk_productionruleset_id` int(11) DEFAULT NULL,
  `fk_activityset_id` int(11) DEFAULT NULL,
  `object_status` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chinodemanytomany_id` (`fk_chinodemanytomany_id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_chinode_id` (`fk_chinode_id`),
  KEY `fk_productionruleset_id` (`fk_productionruleset_id`),
  KEY `fk_activityset_id` (`fk_activityset_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ChiRequirement`
--

CREATE TABLE IF NOT EXISTS `ChiRequirement` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_chirequirement_id` int(11) DEFAULT NULL,
  `fk_chigoal_id` int(11) DEFAULT NULL,
  `reqtype` varchar(255) DEFAULT NULL,
  `priority` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `proofreader` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_chirequirement_id` (`fk_chirequirement_id`),
  KEY `fk_chigoal_id` (`fk_chigoal_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ChiRequirementStatus`
--

CREATE TABLE IF NOT EXISTS `ChiRequirementStatus` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ChiRequirementType`
--

CREATE TABLE IF NOT EXISTS `ChiRequirementType` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ChiSystem`
--

CREATE TABLE IF NOT EXISTS `ChiSystem` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `config` varchar(255) DEFAULT NULL,
  `plattform` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ChiSystem`
--

INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(9, 8, 'null', 'wcmf', '350', 'Chi057Syst', '349', 'null', 'Config', '?', 'null', 'null', 'admin', '2012-05-11 08:52:02', NULL, 9);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(11, 8, 'null', 'wcmf', '350', 'Chi058Syst', '349', 'null', 'ActionMapping', '?', 'null', 'null', 'admin', '2012-05-11 08:52:04', NULL, 11);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(13, 8, 'null', 'wcmf', '350', 'Chi059Syst', '349', 'null', 'Views', '?', 'null', 'null', 'admin', '2012-05-11 08:52:08', NULL, 13);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(14, 8, 'null', 'wcmf', '350', 'Chi060Syst', '349', 'null', 'TypeMapping', '?', 'null', 'null', 'admin', '2012-05-11 08:52:13', NULL, 14);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(15, 8, 'null', 'wcmf', '350', 'Chi061Syst', '349', 'null', 'Application', '?', 'null', 'null', 'admin', '2012-05-11 08:52:17', NULL, 15);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(23, 8, 'null', 'wcmf', '350', 'Chi062Syst', '349', 'null', 'Media', '?', 'null', 'null', 'admin', '2012-05-11 08:52:31', NULL, 23);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(25, 8, 'null', 'wcmf', '350', 'Chi063Syst', '349', 'null', 'RoleConfig', NULL, 'null', 'null', 'admin', '2012-05-11 08:49:41', NULL, 25);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(27, 8, 'null', 'wcmf', '350', 'Chi064Syst', '349', 'null', 'Authorization', NULL, 'null', 'null', 'admin', '2012-05-11 08:49:42', NULL, 27);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(28, 8, 'null', 'wcmf', '350', 'Chi065Syst', '349', 'null', 'I18N', NULL, 'null', 'null', 'admin', '2012-05-11 08:49:42', NULL, 28);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(34, 8, 'null', 'wcmf', '350', 'Chi066Syst', '349', 'null', 'Search', '?', 'null', 'null', 'admin', '2012-05-11 08:51:56', NULL, 34);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(36, 8, 'null', 'wcmf', '350', 'Chi067Syst', '349', 'null', 'Boolean', '?', 'null', 'null', 'admin', '2012-05-11 08:51:58', NULL, 36);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(40, 39, 'admin.ini', 'wcmf', '350', 'Chi068Syst', '349', 'null', 'Application', NULL, 'null', 'null', 'admin', '2012-05-11 08:49:45', NULL, 40);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(43, 42, 'server.ini', 'wcmf', '350', 'Chi069Syst', '349', 'null', 'Database', NULL, 'null', 'null', 'admin', '2012-05-11 08:49:46', NULL, 43);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(49, 42, 'server.ini', 'wcmf', '350', 'Chi070Syst', '349', 'null', 'I18N', NULL, 'null', 'null', 'admin', '2012-05-11 08:49:48', NULL, 49);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(51, 42, 'server.ini', 'wcmf', '350', 'Chi071Syst', '349', 'null', 'Languages', NULL, 'null', 'null', 'admin', '2012-05-11 08:49:48', NULL, 51);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(54, 42, 'server.ini', 'wcmf', '350', 'Chi072Syst', '349', 'null', 'NewInstance', NULL, 'null', 'null', 'admin', '2012-05-11 08:49:49', NULL, 54);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(57, 42, 'server.ini', 'wcmf', '350', 'Chi073Syst', '349', 'null', 'RemoteServer', NULL, 'null', 'null', 'admin', '2012-05-11 08:49:50', NULL, 57);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(58, 42, 'server.ini', 'wcmf', '350', 'Chi074Syst', '349', 'null', 'RemoteUser', NULL, 'null', 'null', 'admin', '2012-05-11 08:49:51', NULL, 58);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(60, 59, 'persistence.ini', 'wcmf', '350', 'Chi075Syst', '349', 'null', 'PersistenceFacade', 'PersistenceFacade implementation', 'null', 'null', 'admin', '2012-05-11 08:49:51', NULL, 60);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(65, 59, 'persistence.ini', 'wcmf', '350', 'Chi076Syst', '349', 'null', 'AuditingLogStragegy', NULL, 'null', 'null', 'admin', '2012-05-11 08:49:53', NULL, 65);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(67, 59, 'persistence.ini', 'wcmf', '350', 'Chi077Syst', '349', 'null', 'Transaction', 'Transaction implementation', 'null', 'null', 'admin', '2012-05-11 08:49:53', NULL, 67);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(69, 59, 'persistence.ini', 'wcmf', '350', 'Chi078Syst', '349', 'null', 'Converter', NULL, 'null', 'null', 'admin', '2012-05-11 08:49:54', NULL, 69);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(70, 59, 'persistence.ini', 'wcmf', '350', 'Chi079Syst', '349', 'null', 'LockHandler', 'LockHandler implementation', 'null', 'null', 'admin', '2012-05-11 08:49:54', NULL, 70);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(72, 59, 'persistence.ini', 'wcmf', '350', 'Chi080Syst', '349', 'null', 'UserManager', 'UserManager implementation', 'null', 'null', 'admin', '2012-05-11 08:49:55', NULL, 72);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(75, 74, 'presentation.ini', 'wcmf', '350', 'Chi081Syst', '349', 'null', 'View', NULL, 'null', 'null', 'admin', '2012-05-11 08:49:55', NULL, 75);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(83, 74, 'presentation.ini', 'wcmf', '350', 'Chi082Syst', '349', 'null', 'Formats', NULL, 'null', 'null', 'admin', '2012-05-11 08:49:58', NULL, 83);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(88, 74, 'presentation.ini', 'wcmf', '350', 'Chi083Syst', '349', 'null', 'HtmlFormat', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:00', NULL, 88);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(90, 74, 'presentation.ini', 'wcmf', '350', 'Chi084Syst', '349', 'null', 'JsonFormat', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:00', NULL, 90);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(92, 74, 'presentation.ini', 'wcmf', '350', 'Chi085Syst', '349', 'null', 'SoapFormat', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:01', NULL, 92);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(94, 74, 'presentation.ini', 'wcmf', '350', 'Chi086Syst', '349', 'null', 'NullFormat', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:01', NULL, 94);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(96, 74, 'presentation.ini', 'wcmf', '350', 'Chi087Syst', '349', 'null', 'ListStrategies', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:02', NULL, 96);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(102, 74, 'presentation.ini', 'wcmf', '350', 'Chi088Syst', '349', 'null', 'FixedListStrategy', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:05', NULL, 102);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(104, 74, 'presentation.ini', 'wcmf', '350', 'Chi089Syst', '349', 'null', 'FunctionListStrategy', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:06', NULL, 104);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(106, 74, 'presentation.ini', 'wcmf', '350', 'Chi090Syst', '349', 'null', 'ConfigListStrategy', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:06', NULL, 106);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(108, 74, 'presentation.ini', 'wcmf', '350', 'Chi091Syst', '349', 'null', 'AsyncListStrategy', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:07', NULL, 108);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(110, 74, 'presentation.ini', 'wcmf', '350', 'Chi092Syst', '349', 'null', 'AsyncMultListStrategy', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:07', NULL, 110);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(112, 74, 'presentation.ini', 'wcmf', '350', 'Chi093Syst', '349', 'null', 'ValueRenderer', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:07', NULL, 112);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(115, 74, 'presentation.ini', 'wcmf', '350', 'Chi094Syst', '349', 'null', 'DisplayTypes', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:08', NULL, 115);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(119, 74, 'presentation.ini', 'wcmf', '350', 'Chi095Syst', '349', 'null', 'TextDisplayType', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:09', NULL, 119);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(122, 74, 'presentation.ini', 'wcmf', '350', 'Chi096Syst', '349', 'null', 'ImageDisplayType', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:10', NULL, 122);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(125, 74, 'presentation.ini', 'wcmf', '350', 'Chi097Syst', '349', 'null', 'LinkDisplayType', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:11', NULL, 125);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(128, 74, 'presentation.ini', 'wcmf', '350', 'Chi098Syst', '349', 'null', 'ControlRenderer', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:11', NULL, 128);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(132, 74, 'presentation.ini', 'wcmf', '350', 'Chi099Syst', '349', 'null', 'Controls', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:12', NULL, 132);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(146, 74, 'presentation.ini', 'wcmf', '350', 'Chi100Syst', '349', 'null', 'CheckboxControl', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:16', NULL, 146);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(149, 74, 'presentation.ini', 'wcmf', '350', 'Chi101Syst', '349', 'null', 'CkeditorControl', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:17', NULL, 149);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(152, 74, 'presentation.ini', 'wcmf', '350', 'Chi102Syst', '349', 'null', 'DateControl', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:18', NULL, 152);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(155, 74, 'presentation.ini', 'wcmf', '350', 'Chi103Syst', '349', 'null', 'FilebrowserControl', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:19', NULL, 155);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(158, 74, 'presentation.ini', 'wcmf', '350', 'Chi104Syst', '349', 'null', 'LinkbrowserControl', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:19', NULL, 158);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(161, 74, 'presentation.ini', 'wcmf', '350', 'Chi105Syst', '349', 'null', 'PasswordControl', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:20', NULL, 161);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(164, 74, 'presentation.ini', 'wcmf', '350', 'Chi106Syst', '349', 'null', 'RadioControl', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:21', NULL, 164);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(168, 74, 'presentation.ini', 'wcmf', '350', 'Chi107Syst', '349', 'null', 'SelectControl', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:22', NULL, 168);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(172, 74, 'presentation.ini', 'wcmf', '350', 'Chi108Syst', '349', 'null', 'SelectAsyncControl', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:23', NULL, 172);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(176, 74, 'presentation.ini', 'wcmf', '350', 'Chi109Syst', '349', 'null', 'TextControl', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:24', NULL, 176);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(179, 74, 'presentation.ini', 'wcmf', '350', 'Chi110Syst', '349', 'null', 'TextareaControl', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:25', NULL, 179);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(182, 74, 'presentation.ini', 'wcmf', '350', 'Chi111Syst', '349', 'null', 'TextileControl', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:26', NULL, 182);
INSERT INTO `ChiSystem` (`id`, `fk_package_id`, `config`, `plattform`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(185, 74, 'presentation.ini', 'wcmf', '350', 'Chi112Syst', '349', 'null', 'BinaryCheckboxControl', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:27', NULL, 185);

-- --------------------------------------------------------

--
-- Table structure for table `ChiValue`
--

CREATE TABLE IF NOT EXISTS `ChiValue` (
  `id` int(11) NOT NULL,
  `fk_chicontroller_id` int(11) DEFAULT NULL,
  `fk_chisystem_id` int(11) DEFAULT NULL,
  `fk_chinodemanytomany_id` int(11) DEFAULT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_chinode_id` int(11) DEFAULT NULL,
  `column_name` varchar(255) DEFAULT NULL,
  `display_type` varchar(255) DEFAULT NULL,
  `restrictions_description` varchar(255) DEFAULT NULL,
  `restrictions_match` varchar(255) DEFAULT NULL,
  `restrictions_not_match` varchar(255) DEFAULT NULL,
  `input_type` varchar(255) DEFAULT NULL,
  `app_data_type` varchar(255) DEFAULT NULL,
  `db_data_type` varchar(255) DEFAULT NULL,
  `is_editable` varchar(255) DEFAULT NULL,
  `default` varchar(255) DEFAULT NULL,
  `propertytype` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chicontroller_id` (`fk_chicontroller_id`),
  KEY `fk_chisystem_id` (`fk_chisystem_id`),
  KEY `fk_chinodemanytomany_id` (`fk_chinodemanytomany_id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_chinode_id` (`fk_chinode_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ChiValue`
--

INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(10, NULL, 9, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '351', NULL, 'Chi027Val', NULL, '1.0', 'include', NULL, '2012-05-11 08:48:46', 'admin', 'admin', '2012-05-11 08:49:37', NULL, 10);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(12, NULL, 11, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '352', NULL, 'Chi028Val', NULL, '1.0', '??fatal', NULL, '2012-05-11 08:48:46', 'admin', 'admin', '2012-05-11 08:49:37', NULL, 12);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(16, NULL, 15, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '353', NULL, 'Chi029Val', NULL, '1.0', 'applicationTitle', NULL, '2012-05-11 08:48:47', 'admin', 'admin', '2012-05-11 08:49:38', NULL, 16);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(17, NULL, 15, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '354', NULL, 'Chi030Val', NULL, '1.0', 'libDir', NULL, '2012-05-11 08:48:47', 'admin', 'admin', '2012-05-11 08:49:39', NULL, 17);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(18, NULL, 15, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '355', NULL, 'Chi031Val', NULL, '1.0', 'exportDir', NULL, '2012-05-11 08:48:47', 'admin', 'admin', '2012-05-11 08:49:39', NULL, 18);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(19, NULL, 15, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '356', NULL, 'Chi032Val', NULL, '1.0', 'backupDir', NULL, '2012-05-11 08:48:47', 'admin', 'admin', '2012-05-11 08:49:39', NULL, 19);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(20, NULL, 15, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '357', NULL, 'Chi033Val', NULL, '1.0', 'logExecuteTime', NULL, '2012-05-11 08:48:47', 'admin', 'admin', '2012-05-11 08:49:40', NULL, 20);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(21, NULL, 15, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '358', NULL, 'Chi034Val', NULL, '1.0', 'anonymous', NULL, '2012-05-11 08:48:47', 'admin', 'admin', '2012-05-11 08:49:40', NULL, 21);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(22, NULL, 15, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '359', NULL, 'Chi035Val', NULL, '1.0', 'rootTypes', NULL, '2012-05-11 08:48:47', 'admin', 'admin', '2012-05-11 08:49:40', NULL, 22);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(24, NULL, 23, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '360', NULL, 'Chi036Val', NULL, '1.0', 'uploadDir', NULL, '2012-05-11 08:48:48', 'admin', 'admin', '2012-05-11 08:49:41', NULL, 24);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(26, NULL, 25, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '361', NULL, 'Chi037Val', NULL, '1.0', 'administrators', NULL, '2012-05-11 08:48:48', 'admin', 'admin', '2012-05-11 08:49:41', NULL, 26);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(29, NULL, 28, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '362', NULL, 'Chi038Val', NULL, '1.0', 'localeDir', NULL, '2012-05-11 08:48:48', 'admin', 'admin', '2012-05-11 08:49:42', NULL, 29);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(30, NULL, 28, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '363', NULL, 'Chi039Val', NULL, '1.0', 'language', NULL, '2012-05-11 08:48:49', 'admin', 'admin', '2012-05-11 08:49:42', NULL, 30);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(31, NULL, 28, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '364', NULL, 'Chi040Val', NULL, '1.0', 'inputTypes', NULL, '2012-05-11 08:48:49', 'admin', 'admin', '2012-05-11 08:49:43', NULL, 31);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(32, NULL, 28, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '365', NULL, 'Chi041Val', NULL, '1.0', 'languageType', NULL, '2012-05-11 08:48:49', 'admin', 'admin', '2012-05-11 08:49:43', NULL, 32);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(33, NULL, 28, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '366', NULL, 'Chi042Val', NULL, '1.0', 'translationType', NULL, '2012-05-11 08:48:49', 'admin', 'admin', '2012-05-11 08:49:43', NULL, 33);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(35, NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '367', NULL, 'Chi043Val', NULL, '1.0', 'indexPath', NULL, '2012-05-11 08:48:50', 'admin', 'admin', '2012-05-11 08:49:44', NULL, 35);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(37, NULL, 36, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '368', NULL, 'Chi044Val', NULL, '1.0', '0', NULL, '2012-05-11 08:48:50', 'admin', 'admin', '2012-05-11 08:49:44', NULL, 37);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(38, NULL, 36, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '369', NULL, 'Chi045Val', NULL, '1.0', '1', NULL, '2012-05-11 08:48:50', 'admin', 'admin', '2012-05-11 08:49:45', NULL, 38);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(41, NULL, 40, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '370', NULL, 'Chi046Val', NULL, '1.0', 'rootTypes', NULL, '2012-05-11 08:48:50', 'admin', 'admin', '2012-05-11 08:49:46', NULL, 41);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(44, NULL, 43, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '371', NULL, 'Chi047Val', NULL, '1.0', 'dbType', NULL, '2012-05-11 08:48:51', 'admin', 'admin', '2012-05-11 08:49:47', NULL, 44);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(45, NULL, 43, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '372', NULL, 'Chi048Val', NULL, '1.0', 'dbHostName', NULL, '2012-05-11 08:48:51', 'admin', 'admin', '2012-05-11 08:49:47', NULL, 45);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(46, NULL, 43, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '373', NULL, 'Chi049Val', NULL, '1.0', 'dbName', NULL, '2012-05-11 08:48:51', 'admin', 'admin', '2012-05-11 08:49:47', NULL, 46);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(47, NULL, 43, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '374', NULL, 'Chi050Val', NULL, '1.0', 'dbUserName', NULL, '2012-05-11 08:48:51', 'admin', 'admin', '2012-05-11 08:49:47', NULL, 47);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(48, NULL, 43, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '375', NULL, 'Chi051Val', NULL, '1.0', 'dbPassword', NULL, '2012-05-11 08:48:51', 'admin', 'admin', '2012-05-11 08:49:48', NULL, 48);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(50, NULL, 49, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '376', NULL, 'Chi052Val', NULL, '1.0', 'defaultLanguage', NULL, '2012-05-11 08:48:51', 'admin', 'admin', '2012-05-11 08:49:48', NULL, 50);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(52, NULL, 51, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '377', NULL, 'Chi053Val', NULL, '1.0', 'de', NULL, '2012-05-11 08:48:52', 'admin', 'admin', '2012-05-11 08:49:49', NULL, 52);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(53, NULL, 51, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '378', NULL, 'Chi054Val', NULL, '1.0', 'en', NULL, '2012-05-11 08:48:52', 'admin', 'admin', '2012-05-11 08:49:49', NULL, 53);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(55, NULL, 54, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '379', NULL, 'Chi055Val', NULL, '1.0', 'dbPrefix', NULL, '2012-05-11 08:48:52', 'admin', 'admin', '2012-05-11 08:49:50', NULL, 55);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(56, NULL, 54, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '380', NULL, 'Chi056Val', NULL, '1.0', 'targetDir', NULL, '2012-05-11 08:48:52', 'admin', 'admin', '2012-05-11 08:49:50', NULL, 56);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(61, NULL, 60, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '381', NULL, 'Chi057Val', NULL, '1.0', '__class', NULL, '2012-05-11 08:48:53', 'admin', 'admin', '2012-05-11 08:49:52', NULL, 61);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(62, NULL, 60, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '382', NULL, 'Chi058Val', NULL, '1.0', 'mappers', NULL, '2012-05-11 08:48:53', 'admin', 'admin', '2012-05-11 08:49:52', NULL, 62);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(63, NULL, 60, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '383', NULL, 'Chi059Val', NULL, '1.0', 'logging', NULL, '2012-05-11 08:48:53', 'admin', 'admin', '2012-05-11 08:49:52', NULL, 63);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(64, NULL, 60, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '384', NULL, 'Chi060Val', NULL, '1.0', 'logStrategy', NULL, '2012-05-11 08:48:54', 'admin', 'admin', '2012-05-11 08:49:53', NULL, 64);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(66, NULL, 65, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '385', NULL, 'Chi061Val', NULL, '1.0', '__class', NULL, '2012-05-11 08:48:54', 'admin', 'admin', '2012-05-11 08:49:53', NULL, 66);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(68, NULL, 67, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '386', NULL, 'Chi062Val', NULL, '1.0', '__class', NULL, '2012-05-11 08:48:54', 'admin', 'admin', '2012-05-11 08:49:54', NULL, 68);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(71, NULL, 70, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '387', NULL, 'Chi063Val', NULL, '1.0', '__class', NULL, '2012-05-11 08:48:55', 'admin', 'admin', '2012-05-11 08:49:54', NULL, 71);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(73, NULL, 72, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '388', NULL, 'Chi064Val', NULL, '1.0', '__class', NULL, '2012-05-11 08:48:55', 'admin', 'admin', '2012-05-11 08:49:55', NULL, 73);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(76, NULL, 75, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '389', NULL, 'Chi065Val', NULL, '1.0', '__class', NULL, '2012-05-11 08:48:55', 'admin', 'admin', '2012-05-11 08:49:56', NULL, 76);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(77, NULL, 75, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '390', NULL, 'Chi066Val', NULL, '1.0', '__shared', NULL, '2012-05-11 08:48:55', 'admin', 'admin', '2012-05-11 08:49:56', NULL, 77);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(78, NULL, 75, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '391', NULL, 'Chi067Val', NULL, '1.0', 'templateDir', NULL, '2012-05-11 08:48:56', 'admin', 'admin', '2012-05-11 08:49:56', NULL, 78);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(79, NULL, 75, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '392', NULL, 'Chi068Val', NULL, '1.0', 'compileCheck', NULL, '2012-05-11 08:48:56', 'admin', 'admin', '2012-05-11 08:49:57', NULL, 79);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(80, NULL, 75, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '393', NULL, 'Chi069Val', NULL, '1.0', 'debugView', NULL, '2012-05-11 08:48:56', 'admin', 'admin', '2012-05-11 08:49:57', NULL, 80);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(81, NULL, 75, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '394', NULL, 'Chi070Val', NULL, '1.0', 'caching', NULL, '2012-05-11 08:48:56', 'admin', 'admin', '2012-05-11 08:49:58', NULL, 81);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(82, NULL, 75, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '395', NULL, 'Chi071Val', NULL, '1.0', 'cacheLifetime', NULL, '2012-05-11 08:48:56', 'admin', 'admin', '2012-05-11 08:49:58', NULL, 82);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(84, NULL, 83, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '396', NULL, 'Chi072Val', NULL, '1.0', 'html', NULL, '2012-05-11 08:48:56', 'admin', 'admin', '2012-05-11 08:49:59', NULL, 84);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(85, NULL, 83, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '397', NULL, 'Chi073Val', NULL, '1.0', 'json', NULL, '2012-05-11 08:48:57', 'admin', 'admin', '2012-05-11 08:49:59', NULL, 85);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(86, NULL, 83, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '398', NULL, 'Chi074Val', NULL, '1.0', 'soap', NULL, '2012-05-11 08:48:57', 'admin', 'admin', '2012-05-11 08:49:59', NULL, 86);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(87, NULL, 83, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '399', NULL, 'Chi075Val', NULL, '1.0', 'null', NULL, '2012-05-11 08:48:57', 'admin', 'admin', '2012-05-11 08:50:00', NULL, 87);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(89, NULL, 88, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '400', NULL, 'Chi076Val', NULL, '1.0', '__class', NULL, '2012-05-11 08:48:57', 'admin', 'admin', '2012-05-11 08:50:00', NULL, 89);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(91, NULL, 90, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '401', NULL, 'Chi077Val', NULL, '1.0', '__class', NULL, '2012-05-11 08:48:58', 'admin', 'admin', '2012-05-11 08:50:00', NULL, 91);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(93, NULL, 92, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '402', NULL, 'Chi078Val', NULL, '1.0', '__class', NULL, '2012-05-11 08:48:58', 'admin', 'admin', '2012-05-11 08:50:01', NULL, 93);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(95, NULL, 94, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '403', NULL, 'Chi079Val', NULL, '1.0', '__class', NULL, '2012-05-11 08:48:58', 'admin', 'admin', '2012-05-11 08:50:02', NULL, 95);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(97, NULL, 96, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '404', NULL, 'Chi080Val', NULL, '1.0', 'fix', NULL, '2012-05-11 08:48:59', 'admin', 'admin', '2012-05-11 08:50:02', NULL, 97);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(98, NULL, 96, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '405', NULL, 'Chi081Val', NULL, '1.0', 'function', NULL, '2012-05-11 08:48:59', 'admin', 'admin', '2012-05-11 08:50:03', NULL, 98);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(99, NULL, 96, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '406', NULL, 'Chi082Val', NULL, '1.0', 'config', NULL, '2012-05-11 08:48:59', 'admin', 'admin', '2012-05-11 08:50:03', NULL, 99);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(100, NULL, 96, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '407', NULL, 'Chi083Val', NULL, '1.0', 'async', NULL, '2012-05-11 08:48:59', 'admin', 'admin', '2012-05-11 08:50:03', NULL, 100);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(101, NULL, 96, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '408', NULL, 'Chi084Val', NULL, '1.0', 'asyncmult', NULL, '2012-05-11 08:48:59', 'admin', 'admin', '2012-05-11 08:50:04', NULL, 101);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(103, NULL, 102, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '409', NULL, 'Chi085Val', NULL, '1.0', '__class', NULL, '2012-05-11 08:49:00', 'admin', 'admin', '2012-05-11 08:50:06', NULL, 103);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(105, NULL, 104, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '410', NULL, 'Chi086Val', NULL, '1.0', '__class', NULL, '2012-05-11 08:49:00', 'admin', 'admin', '2012-05-11 08:50:06', NULL, 105);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(107, NULL, 106, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '411', NULL, 'Chi087Val', NULL, '1.0', '__class', NULL, '2012-05-11 08:49:00', 'admin', 'admin', '2012-05-11 08:50:06', NULL, 107);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(109, NULL, 108, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '412', NULL, 'Chi088Val', NULL, '1.0', '__class', NULL, '2012-05-11 08:49:00', 'admin', 'admin', '2012-05-11 08:50:07', NULL, 109);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(111, NULL, 110, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '413', NULL, 'Chi089Val', NULL, '1.0', '__class', NULL, '2012-05-11 08:49:01', 'admin', 'admin', '2012-05-11 08:50:07', NULL, 111);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(113, NULL, 112, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '414', NULL, 'Chi090Val', NULL, '1.0', '__class', NULL, '2012-05-11 08:49:01', 'admin', 'admin', '2012-05-11 08:50:08', NULL, 113);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(114, NULL, 112, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '415', NULL, 'Chi091Val', NULL, '1.0', 'displayTypes', NULL, '2012-05-11 08:49:01', 'admin', 'admin', '2012-05-11 08:50:08', NULL, 114);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(116, NULL, 115, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '416', NULL, 'Chi092Val', NULL, '1.0', 'text', NULL, '2012-05-11 08:49:02', 'admin', 'admin', '2012-05-11 08:50:08', NULL, 116);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(117, NULL, 115, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '417', NULL, 'Chi093Val', NULL, '1.0', 'image', NULL, '2012-05-11 08:49:02', 'admin', 'admin', '2012-05-11 08:50:09', NULL, 117);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(118, NULL, 115, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '418', NULL, 'Chi094Val', NULL, '1.0', 'link', NULL, '2012-05-11 08:49:02', 'admin', 'admin', '2012-05-11 08:50:09', NULL, 118);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(120, NULL, 119, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '419', NULL, 'Chi095Val', NULL, '1.0', '__class', NULL, '2012-05-11 08:49:02', 'admin', 'admin', '2012-05-11 08:50:10', NULL, 120);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(121, NULL, 119, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '420', NULL, 'Chi096Val', NULL, '1.0', 'viewTpl', NULL, '2012-05-11 08:49:02', 'admin', 'admin', '2012-05-11 08:50:10', NULL, 121);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(123, NULL, 122, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '421', NULL, 'Chi097Val', NULL, '1.0', '__class', NULL, '2012-05-11 08:49:03', 'admin', 'admin', '2012-05-11 08:50:10', NULL, 123);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(124, NULL, 122, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '422', NULL, 'Chi098Val', NULL, '1.0', 'viewTpl', NULL, '2012-05-11 08:49:03', 'admin', 'admin', '2012-05-11 08:50:11', NULL, 124);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(126, NULL, 125, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '423', NULL, 'Chi099Val', NULL, '1.0', '__class', NULL, '2012-05-11 08:49:03', 'admin', 'admin', '2012-05-11 08:50:11', NULL, 126);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(127, NULL, 125, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '424', NULL, 'Chi100Val', NULL, '1.0', 'viewTpl', NULL, '2012-05-11 08:49:03', 'admin', 'admin', '2012-05-11 08:50:11', NULL, 127);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(129, NULL, 128, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '425', NULL, 'Chi101Val', NULL, '1.0', '__class', NULL, '2012-05-11 08:49:04', 'admin', 'admin', '2012-05-11 08:50:12', NULL, 129);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(130, NULL, 128, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '426', NULL, 'Chi102Val', NULL, '1.0', 'controls', NULL, '2012-05-11 08:49:04', 'admin', 'admin', '2012-05-11 08:50:12', NULL, 130);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(131, NULL, 128, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '427', NULL, 'Chi103Val', NULL, '1.0', 'inputFieldDelimiter', NULL, '2012-05-11 08:49:04', 'admin', 'admin', '2012-05-11 08:50:12', NULL, 131);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(133, NULL, 132, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '428', NULL, 'Chi104Val', NULL, '1.0', 'checkbox', NULL, '2012-05-11 08:49:05', 'admin', 'admin', '2012-05-11 08:50:13', NULL, 133);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(134, NULL, 132, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '429', NULL, 'Chi105Val', NULL, '1.0', 'ckeditor', NULL, '2012-05-11 08:49:05', 'admin', 'admin', '2012-05-11 08:50:13', NULL, 134);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(135, NULL, 132, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '430', NULL, 'Chi106Val', NULL, '1.0', 'date', NULL, '2012-05-11 08:49:05', 'admin', 'admin', '2012-05-11 08:50:13', NULL, 135);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(136, NULL, 132, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '431', NULL, 'Chi107Val', NULL, '1.0', 'filebrowser', NULL, '2012-05-11 08:49:05', 'admin', 'admin', '2012-05-11 08:50:14', NULL, 136);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(137, NULL, 132, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '432', NULL, 'Chi108Val', NULL, '1.0', 'linkbrowser', NULL, '2012-05-11 08:49:05', 'admin', 'admin', '2012-05-11 08:50:14', NULL, 137);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(138, NULL, 132, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '433', NULL, 'Chi109Val', NULL, '1.0', 'password', NULL, '2012-05-11 08:49:05', 'admin', 'admin', '2012-05-11 08:50:14', NULL, 138);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(139, NULL, 132, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '434', NULL, 'Chi110Val', NULL, '1.0', 'radio', NULL, '2012-05-11 08:49:05', 'admin', 'admin', '2012-05-11 08:50:14', NULL, 139);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(140, NULL, 132, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '435', NULL, 'Chi111Val', NULL, '1.0', 'select', NULL, '2012-05-11 08:49:06', 'admin', 'admin', '2012-05-11 08:50:15', NULL, 140);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(141, NULL, 132, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '436', NULL, 'Chi112Val', NULL, '1.0', 'select#async', NULL, '2012-05-11 08:49:06', 'admin', 'admin', '2012-05-11 08:50:15', NULL, 141);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(142, NULL, 132, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '437', NULL, 'Chi113Val', NULL, '1.0', 'text', NULL, '2012-05-11 08:49:06', 'admin', 'admin', '2012-05-11 08:50:15', NULL, 142);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(143, NULL, 132, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '438', NULL, 'Chi114Val', NULL, '1.0', 'textarea', NULL, '2012-05-11 08:49:06', 'admin', 'admin', '2012-05-11 08:50:16', NULL, 143);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(144, NULL, 132, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '439', NULL, 'Chi115Val', NULL, '1.0', 'textile', NULL, '2012-05-11 08:49:06', 'admin', 'admin', '2012-05-11 08:50:16', NULL, 144);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(145, NULL, 132, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '440', NULL, 'Chi116Val', NULL, '1.0', 'binarycheckbox', NULL, '2012-05-11 08:49:06', 'admin', 'admin', '2012-05-11 08:50:16', NULL, 145);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(147, NULL, 146, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '441', NULL, 'Chi117Val', NULL, '1.0', '__class', NULL, '2012-05-11 08:49:07', 'admin', 'admin', '2012-05-11 08:50:17', NULL, 147);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(148, NULL, 146, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '442', NULL, 'Chi118Val', NULL, '1.0', 'viewTpl', NULL, '2012-05-11 08:49:07', 'admin', 'admin', '2012-05-11 08:50:17', NULL, 148);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(150, NULL, 149, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '443', NULL, 'Chi119Val', NULL, '1.0', '__class', NULL, '2012-05-11 08:49:07', 'admin', 'admin', '2012-05-11 08:50:17', NULL, 150);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(151, NULL, 149, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '444', NULL, 'Chi120Val', NULL, '1.0', 'viewTpl', NULL, '2012-05-11 08:49:07', 'admin', 'admin', '2012-05-11 08:50:18', NULL, 151);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(153, NULL, 152, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '445', NULL, 'Chi121Val', NULL, '1.0', '__class', NULL, '2012-05-11 08:49:07', 'admin', 'admin', '2012-05-11 08:50:18', NULL, 153);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(154, NULL, 152, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '446', NULL, 'Chi122Val', NULL, '1.0', 'viewTpl', NULL, '2012-05-11 08:49:08', 'admin', 'admin', '2012-05-11 08:50:18', NULL, 154);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(156, NULL, 155, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '447', NULL, 'Chi123Val', NULL, '1.0', '__class', NULL, '2012-05-11 08:49:08', 'admin', 'admin', '2012-05-11 08:50:19', NULL, 156);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(157, NULL, 155, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '448', NULL, 'Chi124Val', NULL, '1.0', 'viewTpl', NULL, '2012-05-11 08:49:08', 'admin', 'admin', '2012-05-11 08:50:19', NULL, 157);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(159, NULL, 158, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '449', NULL, 'Chi125Val', NULL, '1.0', '__class', NULL, '2012-05-11 08:49:08', 'admin', 'admin', '2012-05-11 08:50:20', NULL, 159);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(160, NULL, 158, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '450', NULL, 'Chi126Val', NULL, '1.0', 'viewTpl', NULL, '2012-05-11 08:49:09', 'admin', 'admin', '2012-05-11 08:50:20', NULL, 160);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(162, NULL, 161, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '451', NULL, 'Chi127Val', NULL, '1.0', '__class', NULL, '2012-05-11 08:49:09', 'admin', 'admin', '2012-05-11 08:50:21', NULL, 162);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(163, NULL, 161, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '452', NULL, 'Chi128Val', NULL, '1.0', 'viewTpl', NULL, '2012-05-11 08:49:09', 'admin', 'admin', '2012-05-11 08:50:21', NULL, 163);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(165, NULL, 164, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '453', NULL, 'Chi129Val', NULL, '1.0', '__class', NULL, '2012-05-11 08:49:09', 'admin', 'admin', '2012-05-11 08:50:21', NULL, 165);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(166, NULL, 164, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '454', NULL, 'Chi130Val', NULL, '1.0', 'viewTpl', NULL, '2012-05-11 08:49:10', 'admin', 'admin', '2012-05-11 08:50:22', NULL, 166);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(167, NULL, 164, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '455', NULL, 'Chi131Val', NULL, '1.0', 'listStrategies', NULL, '2012-05-11 08:49:11', 'admin', 'admin', '2012-05-11 08:50:22', NULL, 167);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(169, NULL, 168, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '456', NULL, 'Chi132Val', NULL, '1.0', '__class', NULL, '2012-05-11 08:49:11', 'admin', 'admin', '2012-05-11 08:50:22', NULL, 169);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(170, NULL, 168, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '457', NULL, 'Chi133Val', NULL, '1.0', 'viewTpl', NULL, '2012-05-11 08:49:11', 'admin', 'admin', '2012-05-11 08:50:23', NULL, 170);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(171, NULL, 168, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '458', NULL, 'Chi134Val', NULL, '1.0', 'listStrategies', NULL, '2012-05-11 08:49:12', 'admin', 'admin', '2012-05-11 08:50:23', NULL, 171);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(173, NULL, 172, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '459', NULL, 'Chi135Val', NULL, '1.0', '__class', NULL, '2012-05-11 08:49:12', 'admin', 'admin', '2012-05-11 08:50:23', NULL, 173);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(174, NULL, 172, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '460', NULL, 'Chi136Val', NULL, '1.0', 'viewTpl', NULL, '2012-05-11 08:49:12', 'admin', 'admin', '2012-05-11 08:50:24', NULL, 174);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(175, NULL, 172, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '461', NULL, 'Chi137Val', NULL, '1.0', 'listStrategies', NULL, '2012-05-11 08:49:12', 'admin', 'admin', '2012-05-11 08:50:24', NULL, 175);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(177, NULL, 176, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '462', NULL, 'Chi138Val', NULL, '1.0', '__class', NULL, '2012-05-11 08:49:12', 'admin', 'admin', '2012-05-11 08:50:25', NULL, 177);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(178, NULL, 176, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '463', NULL, 'Chi139Val', NULL, '1.0', 'viewTpl', NULL, '2012-05-11 08:49:12', 'admin', 'admin', '2012-05-11 08:50:25', NULL, 178);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(180, NULL, 179, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '464', NULL, 'Chi140Val', NULL, '1.0', '__class', NULL, '2012-05-11 08:49:12', 'admin', 'admin', '2012-05-11 08:50:26', NULL, 180);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(181, NULL, 179, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '465', NULL, 'Chi141Val', NULL, '1.0', 'viewTpl', NULL, '2012-05-11 08:49:13', 'admin', 'admin', '2012-05-11 08:50:26', NULL, 181);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(183, NULL, 182, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '466', NULL, 'Chi142Val', NULL, '1.0', '__class', NULL, '2012-05-11 08:49:13', 'admin', 'admin', '2012-05-11 08:50:26', NULL, 183);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(184, NULL, 182, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '467', NULL, 'Chi143Val', NULL, '1.0', 'viewTpl', NULL, '2012-05-11 08:49:13', 'admin', 'admin', '2012-05-11 08:50:26', NULL, 184);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(186, NULL, 185, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '468', NULL, 'Chi144Val', NULL, '1.0', '__class', NULL, '2012-05-11 08:49:13', 'admin', 'admin', '2012-05-11 08:50:27', NULL, 186);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(187, NULL, 185, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '469', NULL, 'Chi145Val', NULL, '1.0', 'viewTpl', NULL, '2012-05-11 08:49:13', 'admin', 'admin', '2012-05-11 08:50:27', NULL, 187);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(265, NULL, NULL, NULL, NULL, 264, 'id', NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'INT(11) NOT NULL', 'false', NULL, NULL, NULL, 'Chi146Val', NULL, '1.0', 'id', NULL, '2012-05-11 08:49:23', 'admin', 'admin', '2012-05-11 08:50:52', NULL, 265);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(266, NULL, NULL, NULL, NULL, 264, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '516', NULL, 'Chi147Val', NULL, '1.0', 'name', NULL, '2012-05-11 08:49:23', 'admin', 'admin', '2012-05-11 08:50:53', NULL, 266);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(267, NULL, NULL, NULL, NULL, 264, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '517', NULL, 'Chi148Val', NULL, '1.0', 'created', NULL, '2012-05-11 08:49:23', 'admin', 'admin', '2012-05-11 08:50:53', NULL, 267);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(268, NULL, NULL, NULL, NULL, 264, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '518', NULL, 'Chi149Val', NULL, '1.0', 'creator', NULL, '2012-05-11 08:49:23', 'admin', 'admin', '2012-05-11 08:50:53', NULL, 268);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(269, NULL, NULL, NULL, NULL, 264, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '519', NULL, 'Chi150Val', NULL, '1.0', 'modified', NULL, '2012-05-11 08:49:24', 'admin', 'admin', '2012-05-11 08:50:54', NULL, 269);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(270, NULL, NULL, NULL, NULL, 264, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '520', NULL, 'Chi151Val', NULL, '1.0', 'last_editor', NULL, '2012-05-11 08:49:24', 'admin', 'admin', '2012-05-11 08:50:54', NULL, 270);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(272, NULL, NULL, NULL, NULL, 271, 'id', NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'INT(11) NOT NULL', 'false', NULL, NULL, NULL, 'Chi152Val', NULL, '1.0', 'id', NULL, '2012-05-11 08:49:24', 'admin', 'admin', '2012-05-11 08:50:55', NULL, 272);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(273, NULL, NULL, NULL, NULL, 271, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '524', NULL, 'Chi153Val', NULL, '1.0', 'title', NULL, '2012-05-11 08:49:24', 'admin', 'admin', '2012-05-11 08:50:55', NULL, 273);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(274, NULL, NULL, NULL, NULL, 271, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '525', NULL, 'Chi154Val', NULL, '1.0', 'created', NULL, '2012-05-11 08:49:24', 'admin', 'admin', '2012-05-11 08:50:55', NULL, 274);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(275, NULL, NULL, NULL, NULL, 271, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '526', NULL, 'Chi155Val', NULL, '1.0', 'creator', NULL, '2012-05-11 08:49:25', 'admin', 'admin', '2012-05-11 08:50:56', NULL, 275);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(276, NULL, NULL, NULL, NULL, 271, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '527', NULL, 'Chi156Val', NULL, '1.0', 'modified', NULL, '2012-05-11 08:49:25', 'admin', 'admin', '2012-05-11 08:50:56', NULL, 276);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(277, NULL, NULL, NULL, NULL, 271, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '528', NULL, 'Chi157Val', NULL, '1.0', 'last_editor', NULL, '2012-05-11 08:49:25', 'admin', 'admin', '2012-05-11 08:50:56', NULL, 277);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(279, NULL, NULL, NULL, NULL, 278, 'id', NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'INT(11) NOT NULL', 'false', NULL, NULL, NULL, 'Chi158Val', NULL, '1.0', 'id', NULL, '2012-05-11 08:49:25', 'admin', 'admin', '2012-05-11 08:50:57', NULL, 279);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(280, NULL, NULL, NULL, NULL, 278, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '530', NULL, 'Chi159Val', NULL, '1.0', 'created', NULL, '2012-05-11 08:49:25', 'admin', 'admin', '2012-05-11 08:50:57', NULL, 280);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(281, NULL, NULL, NULL, NULL, 278, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '531', NULL, 'Chi160Val', NULL, '1.0', 'creator', NULL, '2012-05-11 08:49:25', 'admin', 'admin', '2012-05-11 08:50:58', NULL, 281);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(282, NULL, NULL, NULL, NULL, 278, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '532', NULL, 'Chi161Val', NULL, '1.0', 'modified', NULL, '2012-05-11 08:49:25', 'admin', 'admin', '2012-05-11 08:50:58', NULL, 282);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(283, NULL, NULL, NULL, NULL, 278, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '533', NULL, 'Chi162Val', NULL, '1.0', 'last_editor', NULL, '2012-05-11 08:49:25', 'admin', 'admin', '2012-05-11 08:50:58', NULL, 283);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(285, NULL, NULL, NULL, NULL, 284, 'id', NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'INT(11) NOT NULL', 'false', NULL, NULL, NULL, 'Chi163Val', NULL, '1.0', 'id', NULL, '2012-05-11 08:49:26', 'admin', 'admin', '2012-05-11 08:50:59', NULL, 285);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(286, NULL, NULL, NULL, NULL, 284, 'fk_page_id', NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'INT(11)', 'false', NULL, NULL, NULL, 'Chi164Val', NULL, '1.0', 'fk_page_id', NULL, '2012-05-11 08:49:26', 'admin', 'admin', '2012-05-11 08:50:59', NULL, 286);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(287, NULL, NULL, NULL, NULL, 284, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '535', NULL, 'Chi165Val', NULL, '1.0', 'filename', NULL, '2012-05-11 08:49:26', 'admin', 'admin', '2012-05-11 08:50:59', NULL, 287);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(288, NULL, NULL, NULL, NULL, 284, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '536', NULL, 'Chi166Val', NULL, '1.0', 'created', NULL, '2012-05-11 08:49:26', 'admin', 'admin', '2012-05-11 08:51:00', NULL, 288);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(289, NULL, NULL, NULL, NULL, 284, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '537', NULL, 'Chi167Val', NULL, '1.0', 'creator', NULL, '2012-05-11 08:49:26', 'admin', 'admin', '2012-05-11 08:51:00', NULL, 289);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(290, NULL, NULL, NULL, NULL, 284, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '538', NULL, 'Chi168Val', NULL, '1.0', 'modified', NULL, '2012-05-11 08:49:26', 'admin', 'admin', '2012-05-11 08:51:01', NULL, 290);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(291, NULL, NULL, NULL, NULL, 284, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '539', NULL, 'Chi169Val', NULL, '1.0', 'last_editor', NULL, '2012-05-11 08:49:27', 'admin', 'admin', '2012-05-11 08:51:01', NULL, 291);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(293, NULL, NULL, NULL, NULL, 292, 'id', NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'INT(11) NOT NULL', 'false', NULL, NULL, NULL, 'Chi170Val', NULL, '1.0', 'id', NULL, '2012-05-11 08:49:27', 'admin', 'admin', '2012-05-11 08:51:02', NULL, 293);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(294, NULL, NULL, NULL, NULL, 292, 'fk_page_id', NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'INT(11)', 'false', NULL, NULL, NULL, 'Chi171Val', NULL, '1.0', 'fk_page_id', NULL, '2012-05-11 08:49:27', 'admin', 'admin', '2012-05-11 08:51:02', NULL, 294);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(295, NULL, NULL, NULL, NULL, 292, 'fk_author_id', NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'INT(11)', 'false', NULL, NULL, NULL, 'Chi172Val', NULL, '1.0', 'fk_author_id', NULL, '2012-05-11 08:49:27', 'admin', 'admin', '2012-05-11 08:51:03', NULL, 295);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(296, NULL, NULL, NULL, NULL, 292, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '546', NULL, 'Chi173Val', NULL, '1.0', 'author_name', NULL, '2012-05-11 08:49:27', 'admin', 'admin', '2012-05-11 08:51:03', NULL, 296);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(297, NULL, NULL, NULL, NULL, 292, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '547', NULL, 'Chi174Val', NULL, '1.0', 'name', NULL, '2012-05-11 08:49:28', 'admin', 'admin', '2012-05-11 08:51:03', NULL, 297);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(298, NULL, NULL, NULL, NULL, 292, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '548', NULL, 'Chi175Val', NULL, '1.0', 'created', NULL, '2012-05-11 08:49:28', 'admin', 'admin', '2012-05-11 08:51:03', NULL, 298);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(299, NULL, NULL, NULL, NULL, 292, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '549', NULL, 'Chi176Val', NULL, '1.0', 'creator', NULL, '2012-05-11 08:49:28', 'admin', 'admin', '2012-05-11 08:51:04', NULL, 299);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(300, NULL, NULL, NULL, NULL, 292, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '550', NULL, 'Chi177Val', NULL, '1.0', 'modified', NULL, '2012-05-11 08:49:28', 'admin', 'admin', '2012-05-11 08:51:04', NULL, 300);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(301, NULL, NULL, NULL, NULL, 292, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '551', NULL, 'Chi178Val', NULL, '1.0', 'last_editor', NULL, '2012-05-11 08:49:28', 'admin', 'admin', '2012-05-11 08:51:05', NULL, 301);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(303, NULL, NULL, 302, NULL, NULL, 'id', NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'INT(11) NOT NULL', 'false', NULL, NULL, NULL, 'Chi179Val', NULL, '1.0', 'id', NULL, '2012-05-11 08:49:28', 'admin', 'admin', '2012-05-11 08:51:05', NULL, 303);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(304, NULL, NULL, 302, NULL, NULL, 'fk_page_id', NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'INT(11)', 'false', NULL, NULL, NULL, 'Chi180Val', NULL, '1.0', 'fk_page_id', NULL, '2012-05-11 08:49:29', 'admin', 'admin', '2012-05-11 08:51:05', NULL, 304);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(305, NULL, NULL, 302, NULL, NULL, 'fk_document_id', NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'INT(11)', 'false', NULL, NULL, NULL, 'Chi181Val', NULL, '1.0', 'fk_document_id', NULL, '2012-05-11 08:49:29', 'admin', 'admin', '2012-05-11 08:51:06', NULL, 305);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(306, NULL, NULL, 302, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '554', NULL, 'Chi182Val', NULL, '1.0', 'created', NULL, '2012-05-11 08:49:29', 'admin', 'admin', '2012-05-11 08:51:06', NULL, 306);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(307, NULL, NULL, 302, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '555', NULL, 'Chi183Val', NULL, '1.0', 'creator', NULL, '2012-05-11 08:49:29', 'admin', 'admin', '2012-05-11 08:51:06', NULL, 307);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(308, NULL, NULL, 302, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '556', NULL, 'Chi184Val', NULL, '1.0', 'modified', NULL, '2012-05-11 08:49:29', 'admin', 'admin', '2012-05-11 08:51:07', NULL, 308);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(309, NULL, NULL, 302, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '557', NULL, 'Chi185Val', NULL, '1.0', 'last_editor', NULL, '2012-05-11 08:49:30', 'admin', 'admin', '2012-05-11 08:51:07', NULL, 309);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(312, NULL, NULL, NULL, NULL, 311, 'id', NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'INT(11) NOT NULL', 'false', NULL, NULL, NULL, 'Chi186Val', NULL, '1.0', 'id', NULL, '2012-05-11 08:49:30', 'admin', 'admin', '2012-05-11 08:51:08', NULL, 312);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(314, NULL, NULL, NULL, NULL, 313, 'id', NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'INT(11) NOT NULL', 'false', NULL, NULL, NULL, 'Chi187Val', NULL, '1.0', 'id', NULL, '2012-05-11 08:49:30', 'admin', 'admin', '2012-05-11 08:51:10', NULL, 314);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(315, NULL, NULL, NULL, NULL, 313, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '560', NULL, 'Chi188Val', NULL, '1.0', 'name', NULL, '2012-05-11 08:49:30', 'admin', 'admin', '2012-05-11 08:51:10', NULL, 315);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(316, NULL, NULL, NULL, NULL, 313, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '561', NULL, 'Chi189Val', NULL, '1.0', 'code', NULL, '2012-05-11 08:49:30', 'admin', 'admin', '2012-05-11 08:51:11', NULL, 316);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(318, NULL, NULL, NULL, NULL, 317, 'id', NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'INT(11) NOT NULL', 'false', NULL, NULL, NULL, 'Chi190Val', NULL, '1.0', 'id', NULL, '2012-05-11 08:49:31', 'admin', 'admin', '2012-05-11 08:51:11', NULL, 318);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(319, NULL, NULL, NULL, NULL, 317, 'fk_userrdb_id', NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'INT(11)', 'false', NULL, NULL, NULL, 'Chi191Val', NULL, '1.0', 'fk_userrdb_id', NULL, '2012-05-11 08:49:31', 'admin', 'admin', '2012-05-11 08:51:11', NULL, 319);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(320, NULL, NULL, NULL, NULL, 317, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '563', NULL, 'Chi192Val', NULL, '1.0', 'objectid', NULL, '2012-05-11 08:49:31', 'admin', 'admin', '2012-05-11 08:51:11', NULL, 320);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(321, NULL, NULL, NULL, NULL, 317, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '564', NULL, 'Chi193Val', NULL, '1.0', 'sessionid', NULL, '2012-05-11 08:49:31', 'admin', 'admin', '2012-05-11 08:51:12', NULL, 321);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(322, NULL, NULL, NULL, NULL, 317, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '565', NULL, 'Chi194Val', NULL, '1.0', 'since', NULL, '2012-05-11 08:49:31', 'admin', 'admin', '2012-05-11 08:51:12', NULL, 322);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(324, NULL, NULL, NULL, NULL, 323, 'id', NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'INT(11) NOT NULL', 'false', NULL, NULL, NULL, 'Chi195Val', NULL, '1.0', 'id', NULL, '2012-05-11 08:49:31', 'admin', 'admin', '2012-05-11 08:51:12', NULL, 324);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(325, NULL, NULL, NULL, NULL, 323, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '567', NULL, 'Chi196Val', NULL, '1.0', 'name', NULL, '2012-05-11 08:49:32', 'admin', 'admin', '2012-05-11 08:51:13', NULL, 325);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(327, NULL, NULL, NULL, NULL, 326, 'id', NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'INT(11) NOT NULL', 'false', NULL, NULL, NULL, 'Chi197Val', NULL, '1.0', 'id', NULL, '2012-05-11 08:49:32', 'admin', 'admin', '2012-05-11 08:51:13', NULL, 327);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(328, NULL, NULL, NULL, NULL, 326, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '569', NULL, 'Chi198Val', NULL, '1.0', 'objectid', 'The object id of the object to which the translation belongs', '2012-05-11 08:49:32', 'admin', 'admin', '2012-05-11 08:51:14', NULL, 328);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(329, NULL, NULL, NULL, NULL, 326, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '570', NULL, 'Chi199Val', NULL, '1.0', 'attribute', 'The attribute of the object that is translated', '2012-05-11 08:49:32', 'admin', 'admin', '2012-05-11 08:51:14', NULL, 329);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(330, NULL, NULL, NULL, NULL, 326, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '571', NULL, 'Chi200Val', NULL, '1.0', 'translation', 'The translation', '2012-05-11 08:49:32', 'admin', 'admin', '2012-05-11 08:51:14', NULL, 330);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(331, NULL, NULL, NULL, NULL, 326, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '572', NULL, 'Chi201Val', NULL, '1.0', 'language', 'The language of the translation', '2012-05-11 08:49:32', 'admin', 'admin', '2012-05-11 08:51:15', NULL, 331);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(333, NULL, NULL, NULL, NULL, 332, 'id', NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'INT(11) NOT NULL', 'false', NULL, NULL, NULL, 'Chi202Val', NULL, '1.0', 'id', NULL, '2012-05-11 08:49:33', 'admin', 'admin', '2012-05-11 08:51:15', NULL, 333);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(334, NULL, NULL, NULL, NULL, 332, 'fk_userrdb_id', NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'INT(11)', 'false', NULL, NULL, NULL, 'Chi203Val', NULL, '1.0', 'fk_userrdb_id', NULL, '2012-05-11 08:49:33', 'admin', 'admin', '2012-05-11 08:51:15', NULL, 334);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(335, NULL, NULL, NULL, NULL, 332, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '574', NULL, 'Chi204Val', NULL, '1.0', 'key', NULL, '2012-05-11 08:49:33', 'admin', 'admin', '2012-05-11 08:51:16', NULL, 335);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(336, NULL, NULL, NULL, NULL, 332, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '575', NULL, 'Chi205Val', NULL, '1.0', 'val', NULL, '2012-05-11 08:49:33', 'admin', 'admin', '2012-05-11 08:51:16', NULL, 336);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(338, NULL, NULL, NULL, NULL, 337, 'id', NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'INT(11) NOT NULL', 'false', NULL, NULL, NULL, 'Chi206Val', NULL, '1.0', 'id', NULL, '2012-05-11 08:49:34', 'admin', 'admin', '2012-05-11 08:51:17', NULL, 338);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(339, NULL, NULL, NULL, NULL, 337, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '579', NULL, 'Chi207Val', NULL, '1.0', 'login', NULL, '2012-05-11 08:49:34', 'admin', 'admin', '2012-05-11 08:51:17', NULL, 339);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(340, NULL, NULL, NULL, NULL, 337, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '580', NULL, 'Chi208Val', NULL, '1.0', 'password', NULL, '2012-05-11 08:49:34', 'admin', 'admin', '2012-05-11 08:51:18', NULL, 340);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(341, NULL, NULL, NULL, NULL, 337, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '581', NULL, 'Chi209Val', NULL, '1.0', 'name', NULL, '2012-05-11 08:49:34', 'admin', 'admin', '2012-05-11 08:51:18', NULL, 341);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(342, NULL, NULL, NULL, NULL, 337, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '582', NULL, 'Chi210Val', NULL, '1.0', 'firstname', NULL, '2012-05-11 08:49:34', 'admin', 'admin', '2012-05-11 08:51:18', NULL, 342);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(343, NULL, NULL, NULL, NULL, 337, NULL, NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'false', NULL, '583', NULL, 'Chi211Val', NULL, '1.0', 'config', NULL, '2012-05-11 08:49:34', 'admin', 'admin', '2012-05-11 08:51:18', NULL, 343);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(345, NULL, NULL, 344, NULL, NULL, 'fk_role_id', NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'INT(11) NOT NULL', 'false', NULL, NULL, NULL, 'Chi212Val', NULL, '1.0', 'fk_role_id', NULL, '2012-05-11 08:49:35', 'admin', 'admin', '2012-05-11 08:51:19', NULL, 345);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(346, NULL, NULL, 344, NULL, NULL, 'fk_user_id', NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'INT(11) NOT NULL', 'false', NULL, NULL, NULL, 'Chi213Val', NULL, '1.0', 'fk_user_id', NULL, '2012-05-11 08:49:35', 'admin', 'admin', '2012-05-11 08:51:19', NULL, 346);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(347, NULL, NULL, 344, NULL, NULL, 'fk_userrdb_id', NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'INT(11)', 'false', NULL, NULL, NULL, 'Chi214Val', NULL, '1.0', 'fk_userrdb_id', NULL, '2012-05-11 08:49:35', 'admin', 'admin', '2012-05-11 08:51:19', NULL, 347);
INSERT INTO `ChiValue` (`id`, `fk_chicontroller_id`, `fk_chisystem_id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `column_name`, `display_type`, `restrictions_description`, `restrictions_match`, `restrictions_not_match`, `input_type`, `app_data_type`, `db_data_type`, `is_editable`, `default`, `propertytype`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(348, NULL, NULL, 344, NULL, NULL, 'fk_rolerdb_id', NULL, NULL, NULL, NULL, NULL, 'DATATYPE_ATTRIBUTE', 'INT(11)', 'false', NULL, NULL, NULL, 'Chi215Val', NULL, '1.0', 'fk_rolerdb_id', NULL, '2012-05-11 08:49:35', 'admin', 'admin', '2012-05-11 08:51:19', NULL, 348);

-- --------------------------------------------------------

--
-- Table structure for table `ChiValueRef`
--

CREATE TABLE IF NOT EXISTS `ChiValueRef` (
  `id` int(11) NOT NULL,
  `fk_chinodemanytomany_id` int(11) DEFAULT NULL,
  `fk_chivalue_id` int(11) DEFAULT NULL,
  `fk_chinode_id` int(11) DEFAULT NULL,
  `reference_type` varchar(255) DEFAULT NULL,
  `reference_value` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chinodemanytomany_id` (`fk_chinodemanytomany_id`),
  KEY `fk_chivalue_id` (`fk_chivalue_id`),
  KEY `fk_chinode_id` (`fk_chinode_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ChiView`
--

CREATE TABLE IF NOT EXISTS `ChiView` (
  `id` int(11) NOT NULL,
  `fk_chinodemanytomany_id` int(11) DEFAULT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_chinode_id` int(11) DEFAULT NULL,
  `visibility` varchar(255) DEFAULT NULL,
  `isabstract` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chinodemanytomany_id` (`fk_chinodemanytomany_id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_chinode_id` (`fk_chinode_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ChiView`
--

INSERT INTO `ChiView` (`id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(234, NULL, 233, NULL, NULL, 'false', '350', 'Chi018View', '349', 'null', 'displayfailure', 'Displays a failure. Attached to FailureController.', 'null', 'null', 'admin', '2012-05-11 08:50:45', NULL, 234);
INSERT INTO `ChiView` (`id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(235, NULL, 233, NULL, NULL, 'false', '350', 'Chi019View', '349', 'null', 'displaynode', 'Displays the content of a Node. Attached to DisplayController.', 'null', 'null', 'admin', '2012-05-11 08:50:45', NULL, 235);
INSERT INTO `ChiView` (`id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(236, NULL, 233, NULL, NULL, 'false', '350', 'Chi020View', '349', 'null', 'elfinder', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:45', NULL, 236);
INSERT INTO `ChiView` (`id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(237, NULL, 233, NULL, NULL, 'false', '350', 'Chi021View', '349', 'null', 'frontend', 'Displays the content tree. Attached to TreeViewController.', 'null', 'null', 'admin', '2012-05-11 08:50:45', NULL, 237);
INSERT INTO `ChiView` (`id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(238, NULL, 233, NULL, NULL, 'false', '350', 'Chi022View', '349', 'null', 'login', 'Displays the login dialog. Attached to LoginController.', 'null', 'null', 'admin', '2012-05-11 08:50:46', NULL, 238);
INSERT INTO `ChiView` (`id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(239, NULL, 233, NULL, NULL, 'false', '350', 'Chi023View', '349', 'null', 'model', 'Displays the content tree. Attached to TreeViewController.', 'null', 'null', 'admin', '2012-05-11 08:50:46', NULL, 239);
INSERT INTO `ChiView` (`id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(240, NULL, 233, NULL, NULL, 'false', '350', 'Chi024View', '349', 'null', 'nodelist', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:46', NULL, 240);
INSERT INTO `ChiView` (`id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(241, NULL, 233, NULL, NULL, 'false', '350', 'Chi025View', '349', 'null', 'progressbar', 'Displays a progress bar. Attached to LongTaskController.', 'null', 'null', 'admin', '2012-05-11 08:50:46', NULL, 241);
INSERT INTO `ChiView` (`id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(242, NULL, 233, NULL, NULL, 'false', '350', 'Chi026View', '349', 'null', 'resourcetree', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:46', NULL, 242);
INSERT INTO `ChiView` (`id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(243, NULL, 233, NULL, NULL, 'false', '350', 'Chi027View', '349', 'null', 'treeview', 'Displays the content tree. Attached to TreeViewController.', 'null', 'null', 'admin', '2012-05-11 08:50:47', NULL, 243);
INSERT INTO `ChiView` (`id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(244, NULL, 233, NULL, NULL, 'false', '350', 'Chi028View', '349', 'null', 'user', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:47', NULL, 244);
INSERT INTO `ChiView` (`id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(246, NULL, 245, NULL, NULL, 'false', '350', 'Chi029View', '349', 'null', 'config', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:47', NULL, 246);
INSERT INTO `ChiView` (`id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(247, NULL, 245, NULL, NULL, 'false', '350', 'Chi030View', '349', 'null', 'overview', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:48', NULL, 247);
INSERT INTO `ChiView` (`id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(248, NULL, 245, NULL, NULL, 'false', '350', 'Chi031View', '349', 'null', 'rights', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:48', NULL, 248);
INSERT INTO `ChiView` (`id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(249, NULL, 245, NULL, NULL, 'false', '350', 'Chi032View', '349', 'null', 'role', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:48', NULL, 249);
INSERT INTO `ChiView` (`id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(250, NULL, 245, NULL, NULL, 'false', '350', 'Chi033View', '349', 'null', 'user', NULL, 'null', 'null', 'admin', '2012-05-11 08:50:48', NULL, 250);
INSERT INTO `ChiView` (`id`, `fk_chinodemanytomany_id`, `fk_package_id`, `fk_chinode_id`, `visibility`, `isabstract`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(252, NULL, 251, NULL, NULL, 'false', '350', 'Chi034View', '349', 'null', 'textilepreview', 'Displays a failure. Attached to FailureController.', 'null', 'null', 'admin', '2012-05-11 08:50:49', NULL, 252);

-- --------------------------------------------------------

--
-- Table structure for table `ChiWorker`
--

CREATE TABLE IF NOT EXISTS `ChiWorker` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ChiWorkerExternal`
--

CREATE TABLE IF NOT EXISTS `ChiWorkerExternal` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_chiworkerexternal_id` int(11) DEFAULT NULL,
  `is_offlineuser` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_chiworkerexternal_id` (`fk_chiworkerexternal_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ChiWorkerInternal`
--

CREATE TABLE IF NOT EXISTS `ChiWorkerInternal` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_chiworkerinternal_id` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_chiworkerinternal_id` (`fk_chiworkerinternal_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ControlFlow`
--

CREATE TABLE IF NOT EXISTS `ControlFlow` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fk_activityfinal_id` int(11) DEFAULT NULL,
  `fk_activityinitial_id` int(11) DEFAULT NULL,
  `fk_ascontrolflowsource_id` int(11) DEFAULT NULL,
  `fk_ascontrolflowtarget_id` int(11) DEFAULT NULL,
  `fk_arcontrolflowsource_id` int(11) DEFAULT NULL,
  `fk_arcontrolflowtarget_id` int(11) DEFAULT NULL,
  `fk_adcontrolflowtarget_id` int(11) DEFAULT NULL,
  `fk_adcontrolflowsource_id` int(11) DEFAULT NULL,
  `fk_acontrolflowsource_id` int(11) DEFAULT NULL,
  `fk_acontrolflowtarget_id` int(11) DEFAULT NULL,
  `guard` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_activityfinal_id` (`fk_activityfinal_id`),
  KEY `fk_activityinitial_id` (`fk_activityinitial_id`),
  KEY `fk_ascontrolflowsource_id` (`fk_ascontrolflowsource_id`),
  KEY `fk_ascontrolflowtarget_id` (`fk_ascontrolflowtarget_id`),
  KEY `fk_arcontrolflowsource_id` (`fk_arcontrolflowsource_id`),
  KEY `fk_arcontrolflowtarget_id` (`fk_arcontrolflowtarget_id`),
  KEY `fk_adcontrolflowtarget_id` (`fk_adcontrolflowtarget_id`),
  KEY `fk_adcontrolflowsource_id` (`fk_adcontrolflowsource_id`),
  KEY `fk_acontrolflowsource_id` (`fk_acontrolflowsource_id`),
  KEY `fk_acontrolflowtarget_id` (`fk_acontrolflowtarget_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `Counter`
--

CREATE TABLE IF NOT EXISTS `Counter` (
  `id` int(11) NOT NULL,
  `activity` varchar(255) DEFAULT NULL,
  `activitydecision` varchar(255) DEFAULT NULL,
  `activityfinal` varchar(255) DEFAULT NULL,
  `activityinitial` varchar(255) DEFAULT NULL,
  `activityreceive` varchar(255) DEFAULT NULL,
  `activitysend` varchar(255) DEFAULT NULL,
  `chibusinesspartner` varchar(255) DEFAULT NULL,
  `chibusinesspartneractive` varchar(255) DEFAULT NULL,
  `chibusinesspartnerpassive` varchar(255) DEFAULT NULL,
  `chibusinessprocess` varchar(255) DEFAULT NULL,
  `chibusinessusecase` varchar(255) DEFAULT NULL,
  `chibusinessusecasecore` varchar(255) DEFAULT NULL,
  `chicontroller` varchar(255) DEFAULT NULL,
  `chifeature` varchar(255) DEFAULT NULL,
  `chigoal` varchar(255) DEFAULT NULL,
  `chiissue` varchar(255) DEFAULT NULL,
  `chinode` varchar(255) DEFAULT NULL,
  `chirequirement` varchar(255) DEFAULT NULL,
  `chisystem` varchar(255) DEFAULT NULL,
  `chivalue` varchar(255) DEFAULT NULL,
  `chiview` varchar(255) DEFAULT NULL,
  `chiworker` varchar(255) DEFAULT NULL,
  `chiworkerexternal` varchar(255) DEFAULT NULL,
  `chiworkerinternal` varchar(255) DEFAULT NULL,
  `operation` varchar(255) DEFAULT NULL,
  `diagram` varchar(255) DEFAULT NULL,
  `activityset` varchar(255) DEFAULT NULL,
  `productionruleset` varchar(255) DEFAULT NULL,
  `productionrule` varchar(255) DEFAULT NULL,
  `rulesetvariable` varchar(255) DEFAULT NULL,
  `rulevariable` varchar(255) DEFAULT NULL,
  `rulecondition` varchar(255) DEFAULT NULL,
  `ruleaction` varchar(255) DEFAULT NULL,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Counter`
--

INSERT INTO `Counter` (`id`, `activity`, `activitydecision`, `activityfinal`, `activityinitial`, `activityreceive`, `activitysend`, `chibusinesspartner`, `chibusinesspartneractive`, `chibusinesspartnerpassive`, `chibusinessprocess`, `chibusinessusecase`, `chibusinessusecasecore`, `chicontroller`, `chifeature`, `chigoal`, `chiissue`, `chinode`, `chirequirement`, `chisystem`, `chivalue`, `chiview`, `chiworker`, `chiworkerexternal`, `chiworkerinternal`, `operation`, `diagram`, `activityset`, `productionruleset`, `productionrule`, `rulesetvariable`, `rulevariable`, `rulecondition`, `ruleaction`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '84', NULL, NULL, NULL, '217', NULL, '112', '215', '34', NULL, NULL, NULL, NULL, '2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'admin', '2012-05-11 08:51:46', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `dbupdate`
--

CREATE TABLE IF NOT EXISTS `dbupdate` (
  `table_id` varchar(100) NOT NULL,
  `column_id` varchar(100) NOT NULL,
  `type` varchar(100) NOT NULL,
  `table` varchar(255) DEFAULT NULL,
  `column` varchar(255) DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`table_id`,`column_id`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Diagram`
--

CREATE TABLE IF NOT EXISTS `Diagram` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `width` varchar(255) DEFAULT NULL,
  `height` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Diagram`
--

INSERT INTO `Diagram` (`id`, `fk_package_id`, `width`, `height`, `status`, `alias`, `author`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`, `sortkey`) VALUES(586, 8, NULL, NULL, NULL, 'Chi002Dia', NULL, '1.0', 'config.ini', NULL, NULL, NULL, 'admin', '2012-05-11 08:51:46', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `DisplayType`
--

CREATE TABLE IF NOT EXISTS `DisplayType` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Figure`
--

CREATE TABLE IF NOT EXISTS `Figure` (
  `id` int(11) NOT NULL,
  `fk_chiobject_id` int(11) DEFAULT NULL,
  `fk_activity_id` int(11) DEFAULT NULL,
  `fk_activitydecision_id` int(11) DEFAULT NULL,
  `fk_activityreceive_id` int(11) DEFAULT NULL,
  `fk_activitysend_id` int(11) DEFAULT NULL,
  `fk_activityinitial_id` int(11) DEFAULT NULL,
  `fk_activityfinal_id` int(11) DEFAULT NULL,
  `fk_chisystem_id` int(11) DEFAULT NULL,
  `fk_productionrule_id` int(11) DEFAULT NULL,
  `fk_productionruleset_id` int(11) DEFAULT NULL,
  `fk_ruleaction_id` int(11) DEFAULT NULL,
  `fk_rulecondition_id` int(11) DEFAULT NULL,
  `fk_rulesetvariable_id` int(11) DEFAULT NULL,
  `fk_rulevariable_id` int(11) DEFAULT NULL,
  `fk_chiworkerexternal_id` int(11) DEFAULT NULL,
  `fk_chiworkerinternal_id` int(11) DEFAULT NULL,
  `fk_chiworker_id` int(11) DEFAULT NULL,
  `fk_chibusinesspartneractive_id` int(11) DEFAULT NULL,
  `fk_chibusinesspartnerpassive_id` int(11) DEFAULT NULL,
  `fk_chibusinesspartner_id` int(11) DEFAULT NULL,
  `fk_actor_id` int(11) DEFAULT NULL,
  `fk_chibusinessprocess_id` int(11) DEFAULT NULL,
  `fk_chibusinessusecasecore_id` int(11) DEFAULT NULL,
  `fk_chibusinessusecase_id` int(11) DEFAULT NULL,
  `fk_chigoal_id` int(11) DEFAULT NULL,
  `fk_chirequirement_id` int(11) DEFAULT NULL,
  `fk_chifeature_id` int(11) DEFAULT NULL,
  `fk_chiissue_id` int(11) DEFAULT NULL,
  `fk_operation_id` int(11) DEFAULT NULL,
  `fk_chinodemanytomany_id` int(11) DEFAULT NULL,
  `fk_chinode_id` int(11) DEFAULT NULL,
  `fk_chicontroller_id` int(11) DEFAULT NULL,
  `fk_chiview_id` int(11) DEFAULT NULL,
  `fk_chiclass_id` int(11) DEFAULT NULL,
  `fk_feature_id` int(11) DEFAULT NULL,
  `fk_chivalue_id` int(11) DEFAULT NULL,
  `fk_property_id` int(11) DEFAULT NULL,
  `fk_glossary_id` int(11) DEFAULT NULL,
  `fk_diagram_id` int(11) DEFAULT NULL,
  `fk_chibase_id` int(11) DEFAULT NULL,
  `fk_activityset_id` int(11) DEFAULT NULL,
  `backgroundcolor` varchar(255) DEFAULT NULL,
  `foregroundcolor` varchar(255) DEFAULT NULL,
  `gid` varchar(255) DEFAULT NULL,
  `height` varchar(255) DEFAULT NULL,
  `positionx` varchar(255) DEFAULT NULL,
  `positiony` varchar(255) DEFAULT NULL,
  `showinheritedattributes` varchar(255) DEFAULT NULL,
  `width` varchar(255) DEFAULT NULL,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chiobject_id` (`fk_chiobject_id`),
  KEY `fk_activity_id` (`fk_activity_id`),
  KEY `fk_activitydecision_id` (`fk_activitydecision_id`),
  KEY `fk_activityreceive_id` (`fk_activityreceive_id`),
  KEY `fk_activitysend_id` (`fk_activitysend_id`),
  KEY `fk_activityinitial_id` (`fk_activityinitial_id`),
  KEY `fk_activityfinal_id` (`fk_activityfinal_id`),
  KEY `fk_chisystem_id` (`fk_chisystem_id`),
  KEY `fk_productionrule_id` (`fk_productionrule_id`),
  KEY `fk_productionruleset_id` (`fk_productionruleset_id`),
  KEY `fk_ruleaction_id` (`fk_ruleaction_id`),
  KEY `fk_rulecondition_id` (`fk_rulecondition_id`),
  KEY `fk_rulesetvariable_id` (`fk_rulesetvariable_id`),
  KEY `fk_rulevariable_id` (`fk_rulevariable_id`),
  KEY `fk_chiworkerexternal_id` (`fk_chiworkerexternal_id`),
  KEY `fk_chiworkerinternal_id` (`fk_chiworkerinternal_id`),
  KEY `fk_chiworker_id` (`fk_chiworker_id`),
  KEY `fk_chibusinesspartneractive_id` (`fk_chibusinesspartneractive_id`),
  KEY `fk_chibusinesspartnerpassive_id` (`fk_chibusinesspartnerpassive_id`),
  KEY `fk_chibusinesspartner_id` (`fk_chibusinesspartner_id`),
  KEY `fk_actor_id` (`fk_actor_id`),
  KEY `fk_chibusinessprocess_id` (`fk_chibusinessprocess_id`),
  KEY `fk_chibusinessusecasecore_id` (`fk_chibusinessusecasecore_id`),
  KEY `fk_chibusinessusecase_id` (`fk_chibusinessusecase_id`),
  KEY `fk_chigoal_id` (`fk_chigoal_id`),
  KEY `fk_chirequirement_id` (`fk_chirequirement_id`),
  KEY `fk_chifeature_id` (`fk_chifeature_id`),
  KEY `fk_chiissue_id` (`fk_chiissue_id`),
  KEY `fk_operation_id` (`fk_operation_id`),
  KEY `fk_chinodemanytomany_id` (`fk_chinodemanytomany_id`),
  KEY `fk_chinode_id` (`fk_chinode_id`),
  KEY `fk_chicontroller_id` (`fk_chicontroller_id`),
  KEY `fk_chiview_id` (`fk_chiview_id`),
  KEY `fk_chiclass_id` (`fk_chiclass_id`),
  KEY `fk_feature_id` (`fk_feature_id`),
  KEY `fk_chivalue_id` (`fk_chivalue_id`),
  KEY `fk_property_id` (`fk_property_id`),
  KEY `fk_glossary_id` (`fk_glossary_id`),
  KEY `fk_diagram_id` (`fk_diagram_id`),
  KEY `fk_chibase_id` (`fk_chibase_id`),
  KEY `fk_activityset_id` (`fk_activityset_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Figure`
--

INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(587, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 9, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 586, NULL, NULL, NULL, NULL, NULL, '50', '5025', '5022', NULL, '50', NULL, NULL, 'admin', '2012-05-11 08:52:00', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(588, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 11, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 586, NULL, NULL, NULL, NULL, NULL, '50', '5193', '5021', NULL, '50', NULL, NULL, 'admin', '2012-05-11 08:52:03', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(589, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 13, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 586, NULL, NULL, NULL, NULL, NULL, '50', '5364', '5022', NULL, '50', NULL, NULL, 'admin', '2012-05-11 08:52:06', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(590, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 14, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 586, NULL, NULL, NULL, NULL, NULL, '50', '5363', '5101', NULL, '50', NULL, NULL, 'admin', '2012-05-11 08:52:10', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(591, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 15, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 586, NULL, NULL, NULL, NULL, NULL, '50', '5359', '5181', NULL, '50', NULL, NULL, 'admin', '2012-05-11 08:52:16', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(592, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 23, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 586, NULL, NULL, NULL, NULL, NULL, '50', '5360', '5371', NULL, '50', NULL, NULL, 'admin', '2012-05-11 08:52:28', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(593, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 25, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 586, NULL, NULL, NULL, NULL, NULL, '50', '5750', '5050', NULL, '50', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(594, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 27, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 586, NULL, NULL, NULL, NULL, NULL, '50', '5850', '5050', NULL, '50', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(595, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 28, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 586, NULL, NULL, NULL, NULL, NULL, '50', '5950', '5050', NULL, '50', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(596, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 586, NULL, NULL, NULL, NULL, NULL, '50', '5361', '5466', NULL, '50', NULL, NULL, 'admin', '2012-05-11 08:52:35', NULL);
INSERT INTO `Figure` (`id`, `fk_chiobject_id`, `fk_activity_id`, `fk_activitydecision_id`, `fk_activityreceive_id`, `fk_activitysend_id`, `fk_activityinitial_id`, `fk_activityfinal_id`, `fk_chisystem_id`, `fk_productionrule_id`, `fk_productionruleset_id`, `fk_ruleaction_id`, `fk_rulecondition_id`, `fk_rulesetvariable_id`, `fk_rulevariable_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibusinessprocess_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_chifeature_id`, `fk_chiissue_id`, `fk_operation_id`, `fk_chinodemanytomany_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chiview_id`, `fk_chiclass_id`, `fk_feature_id`, `fk_chivalue_id`, `fk_property_id`, `fk_glossary_id`, `fk_diagram_id`, `fk_chibase_id`, `fk_activityset_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `height`, `positionx`, `positiony`, `showinheritedattributes`, `width`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(597, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 36, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 586, NULL, NULL, NULL, NULL, NULL, '50', '5050', '5222', NULL, '50', NULL, NULL, 'admin', '2012-05-11 08:51:57', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Glossary`
--

CREATE TABLE IF NOT EXISTS `Glossary` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `entrytype` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `History`
--

CREATE TABLE IF NOT EXISTS `History` (
  `id` int(11) NOT NULL,
  `data` text,
  `duplicate` tinyint(1) DEFAULT NULL,
  `eventtype` enum('create','delete','changeProperty','associate','disassociate') DEFAULT NULL,
  `affectedoid` varchar(255) DEFAULT NULL,
  `otheroid` varchar(255) DEFAULT NULL,
  `timestamp` bigint(20) DEFAULT NULL,
  `user` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `History`
--

INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(614, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5050";s:8:"newValue";s:4:"5049";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5150";s:8:"newValue";s:4:"5334";}}}', NULL, 'changeProperty', 'Figure:596', NULL, 1336719114681653, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(615, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";N;s:8:"newValue";s:1:"?";}}}', NULL, 'changeProperty', 'ChiSystem:34', NULL, 1336719115998237, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(618, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5150";s:8:"newValue";s:4:"5050";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5150";s:8:"newValue";s:4:"5222";}}}', NULL, 'changeProperty', 'Figure:597', NULL, 1336719117905064, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(619, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";N;s:8:"newValue";s:1:"?";}}}', NULL, 'changeProperty', 'ChiSystem:36', NULL, 1336719118860813, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(622, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5150";s:8:"newValue";s:4:"5025";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5050";s:8:"newValue";s:4:"5022";}}}', NULL, 'changeProperty', 'Figure:587', NULL, 1336719120788991, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(623, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";N;s:8:"newValue";s:1:"?";}}}', NULL, 'changeProperty', 'ChiSystem:9', NULL, 1336719122057277, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(626, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5250";s:8:"newValue";s:4:"5193";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5050";s:8:"newValue";s:4:"5021";}}}', NULL, 'changeProperty', 'Figure:588', NULL, 1336719123539374, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(627, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";N;s:8:"newValue";s:1:"?";}}}', NULL, 'changeProperty', 'ChiSystem:11', NULL, 1336719124588682, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(630, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5350";s:8:"newValue";s:4:"5364";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5050";s:8:"newValue";s:4:"5022";}}}', NULL, 'changeProperty', 'Figure:589', NULL, 1336719126802018, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(631, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";N;s:8:"newValue";s:1:"?";}}}', NULL, 'changeProperty', 'ChiSystem:13', NULL, 1336719128172211, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(634, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5450";s:8:"newValue";s:4:"5363";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5050";s:8:"newValue";s:4:"5101";}}}', NULL, 'changeProperty', 'Figure:590', NULL, 1336719130940047, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(635, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";N;s:8:"newValue";s:1:"?";}}}', NULL, 'changeProperty', 'ChiSystem:14', NULL, 1336719133842428, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(638, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5550";s:8:"newValue";s:4:"5359";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5050";s:8:"newValue";s:4:"5181";}}}', NULL, 'changeProperty', 'Figure:591', NULL, 1336719136382189, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(639, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";N;s:8:"newValue";s:1:"?";}}}', NULL, 'changeProperty', 'ChiSystem:15', NULL, 1336719137227625, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(642, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5650";s:8:"newValue";s:4:"5361";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5050";s:8:"newValue";s:4:"5373";}}}', NULL, 'changeProperty', 'Figure:592', NULL, 1336719142797520, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(643, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5361";s:8:"newValue";s:4:"5360";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5373";s:8:"newValue";s:4:"5371";}}}', NULL, 'changeProperty', 'Figure:592', NULL, 1336719148449737, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(644, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";N;s:8:"newValue";s:1:"?";}}}', NULL, 'changeProperty', 'ChiSystem:23', NULL, 1336719151256968, 'admin');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES(647, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5049";s:8:"newValue";s:4:"5361";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5334";s:8:"newValue";s:4:"5466";}}}', NULL, 'changeProperty', 'Figure:596', NULL, 1336719155226684, 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `InputType`
--

CREATE TABLE IF NOT EXISTS `InputType` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Language`
--

CREATE TABLE IF NOT EXISTS `Language` (
  `id` int(11) NOT NULL,
  `code` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Language`
--

INSERT INTO `Language` (`id`, `code`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(1, 'en', 'English', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Language` (`id`, `code`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(2, 'de', 'Deutsch', NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `locktable`
--

CREATE TABLE IF NOT EXISTS `locktable` (
  `id` int(11) NOT NULL,
  `fk_user_id` int(11) DEFAULT NULL,
  `objectid` varchar(255) DEFAULT NULL,
  `sessionid` varchar(255) DEFAULT NULL,
  `since` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_user_id` (`fk_user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `locktable`
--

INSERT INTO `locktable` (`id`, `fk_user_id`, `objectid`, `sessionid`, `since`) VALUES(646, 2, 'ChiSystem:34', '7gj9ded9g5lrnp0omit1kvc456', '2012-05-11 08:52:31');

-- --------------------------------------------------------

--
-- Table structure for table `Model`
--

CREATE TABLE IF NOT EXISTS `Model` (
  `id` int(11) NOT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Model`
--

INSERT INTO `Model` (`id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(3, NULL, 'Imported Model', NULL, '2012-05-11 08:48:45', 'admin', 'admin', '2012-05-11 08:48:45', 3);

-- --------------------------------------------------------

--
-- Table structure for table `NMChiControllerActionKeyChiController`
--

CREATE TABLE IF NOT EXISTS `NMChiControllerActionKeyChiController` (
  `id` int(11) NOT NULL,
  `fk_chicontrolleractionkeysource_id` int(11) DEFAULT NULL,
  `fk_chicontrolleractionkeytarget_id` int(11) DEFAULT NULL,
  `action` varchar(255) DEFAULT NULL,
  `config` varchar(255) DEFAULT NULL,
  `context` varchar(255) DEFAULT NULL,
  `sourcename` varchar(255) DEFAULT NULL,
  `sourcemultiplicity` varchar(255) DEFAULT NULL,
  `sourcenavigability` varchar(255) DEFAULT NULL,
  `targetname` varchar(255) DEFAULT NULL,
  `targetmultiplicity` varchar(255) DEFAULT NULL,
  `targetnavigability` varchar(255) DEFAULT NULL,
  `relationtype` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chicontrolleractionkeysource_id` (`fk_chicontrolleractionkeysource_id`),
  KEY `fk_chicontrolleractionkeytarget_id` (`fk_chicontrolleractionkeytarget_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `NMChiControllerActionKeyChiView`
--

CREATE TABLE IF NOT EXISTS `NMChiControllerActionKeyChiView` (
  `id` int(11) NOT NULL,
  `fk_chiview_id` int(11) DEFAULT NULL,
  `fk_chicontroller_id` int(11) DEFAULT NULL,
  `action` varchar(255) DEFAULT NULL,
  `config` varchar(255) DEFAULT NULL,
  `context` varchar(255) DEFAULT NULL,
  `sourcename` varchar(255) DEFAULT NULL,
  `sourcemultiplicity` varchar(255) DEFAULT NULL,
  `sourcenavigability` varchar(255) DEFAULT NULL,
  `targetname` varchar(255) DEFAULT NULL,
  `targetmultiplicity` varchar(255) DEFAULT NULL,
  `targetnavigability` varchar(255) DEFAULT NULL,
  `relationtype` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chiview_id` (`fk_chiview_id`),
  KEY `fk_chicontroller_id` (`fk_chicontroller_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `NMChiControllerActionKeyChiView`
--

INSERT INTO `NMChiControllerActionKeyChiView` (`id`, `fk_chiview_id`, `fk_chicontroller_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(470, NULL, 257, NULL, 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Generalization', NULL, NULL, '2012-05-11 08:50:28', 'admin', 'admin', '2012-05-11 08:50:28', NULL);
INSERT INTO `NMChiControllerActionKeyChiView` (`id`, `fk_chiview_id`, `fk_chicontroller_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(471, NULL, 257, NULL, 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Generalization', NULL, NULL, '2012-05-11 08:50:29', 'admin', 'admin', '2012-05-11 08:50:29', NULL);
INSERT INTO `NMChiControllerActionKeyChiView` (`id`, `fk_chiview_id`, `fk_chicontroller_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(472, NULL, 207, NULL, 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Generalization', NULL, NULL, '2012-05-11 08:50:29', 'admin', 'admin', '2012-05-11 08:50:29', NULL);
INSERT INTO `NMChiControllerActionKeyChiView` (`id`, `fk_chiview_id`, `fk_chicontroller_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(473, NULL, 193, NULL, 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Generalization', NULL, NULL, '2012-05-11 08:50:30', 'admin', 'admin', '2012-05-11 08:50:30', NULL);
INSERT INTO `NMChiControllerActionKeyChiView` (`id`, `fk_chiview_id`, `fk_chicontroller_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(474, NULL, 257, NULL, 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Generalization', NULL, NULL, '2012-05-11 08:50:30', 'admin', 'admin', '2012-05-11 08:50:30', NULL);
INSERT INTO `NMChiControllerActionKeyChiView` (`id`, `fk_chiview_id`, `fk_chicontroller_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(475, NULL, 257, NULL, 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Generalization', NULL, NULL, '2012-05-11 08:50:30', 'admin', 'admin', '2012-05-11 08:50:30', NULL);
INSERT INTO `NMChiControllerActionKeyChiView` (`id`, `fk_chiview_id`, `fk_chicontroller_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(476, NULL, 257, NULL, 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Generalization', NULL, NULL, '2012-05-11 08:50:31', 'admin', 'admin', '2012-05-11 08:50:31', NULL);
INSERT INTO `NMChiControllerActionKeyChiView` (`id`, `fk_chiview_id`, `fk_chicontroller_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(477, NULL, 257, NULL, 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Generalization', NULL, NULL, '2012-05-11 08:50:31', 'admin', 'admin', '2012-05-11 08:50:31', NULL);
INSERT INTO `NMChiControllerActionKeyChiView` (`id`, `fk_chiview_id`, `fk_chicontroller_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(478, NULL, 257, NULL, 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Generalization', NULL, NULL, '2012-05-11 08:50:32', 'admin', 'admin', '2012-05-11 08:50:32', NULL);
INSERT INTO `NMChiControllerActionKeyChiView` (`id`, `fk_chiview_id`, `fk_chicontroller_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(479, NULL, 257, NULL, 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Generalization', NULL, NULL, '2012-05-11 08:50:32', 'admin', 'admin', '2012-05-11 08:50:32', NULL);
INSERT INTO `NMChiControllerActionKeyChiView` (`id`, `fk_chiview_id`, `fk_chicontroller_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(480, NULL, 257, NULL, 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Generalization', NULL, NULL, '2012-05-11 08:50:32', 'admin', 'admin', '2012-05-11 08:50:32', NULL);
INSERT INTO `NMChiControllerActionKeyChiView` (`id`, `fk_chiview_id`, `fk_chicontroller_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(481, NULL, 257, NULL, 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Generalization', NULL, NULL, '2012-05-11 08:50:33', 'admin', 'admin', '2012-05-11 08:50:33', NULL);
INSERT INTO `NMChiControllerActionKeyChiView` (`id`, `fk_chiview_id`, `fk_chicontroller_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(482, NULL, 257, NULL, 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Generalization', NULL, NULL, '2012-05-11 08:50:33', 'admin', 'admin', '2012-05-11 08:50:33', NULL);
INSERT INTO `NMChiControllerActionKeyChiView` (`id`, `fk_chiview_id`, `fk_chicontroller_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(483, NULL, 257, NULL, 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Generalization', NULL, NULL, '2012-05-11 08:50:33', 'admin', 'admin', '2012-05-11 08:50:33', NULL);
INSERT INTO `NMChiControllerActionKeyChiView` (`id`, `fk_chiview_id`, `fk_chicontroller_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(484, NULL, 257, NULL, 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Generalization', NULL, NULL, '2012-05-11 08:50:34', 'admin', 'admin', '2012-05-11 08:50:34', NULL);
INSERT INTO `NMChiControllerActionKeyChiView` (`id`, `fk_chiview_id`, `fk_chicontroller_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(485, NULL, 257, NULL, 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Generalization', NULL, NULL, '2012-05-11 08:50:34', 'admin', 'admin', '2012-05-11 08:50:34', NULL);
INSERT INTO `NMChiControllerActionKeyChiView` (`id`, `fk_chiview_id`, `fk_chicontroller_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(486, NULL, 257, NULL, 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Generalization', NULL, NULL, '2012-05-11 08:50:35', 'admin', 'admin', '2012-05-11 08:50:35', NULL);
INSERT INTO `NMChiControllerActionKeyChiView` (`id`, `fk_chiview_id`, `fk_chicontroller_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(487, NULL, 193, NULL, 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Generalization', NULL, NULL, '2012-05-11 08:50:35', 'admin', 'admin', '2012-05-11 08:50:35', NULL);
INSERT INTO `NMChiControllerActionKeyChiView` (`id`, `fk_chiview_id`, `fk_chicontroller_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(488, NULL, 257, NULL, 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Generalization', NULL, NULL, '2012-05-11 08:50:35', 'admin', 'admin', '2012-05-11 08:50:35', NULL);
INSERT INTO `NMChiControllerActionKeyChiView` (`id`, `fk_chiview_id`, `fk_chicontroller_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(489, NULL, 257, NULL, 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Generalization', NULL, NULL, '2012-05-11 08:50:36', 'admin', 'admin', '2012-05-11 08:50:36', NULL);
INSERT INTO `NMChiControllerActionKeyChiView` (`id`, `fk_chiview_id`, `fk_chicontroller_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(490, NULL, 257, NULL, 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Generalization', NULL, NULL, '2012-05-11 08:50:36', 'admin', 'admin', '2012-05-11 08:50:36', NULL);
INSERT INTO `NMChiControllerActionKeyChiView` (`id`, `fk_chiview_id`, `fk_chicontroller_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(491, NULL, 204, NULL, 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Generalization', NULL, NULL, '2012-05-11 08:50:36', 'admin', 'admin', '2012-05-11 08:50:36', NULL);
INSERT INTO `NMChiControllerActionKeyChiView` (`id`, `fk_chiview_id`, `fk_chicontroller_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(492, NULL, 193, NULL, 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Generalization', NULL, NULL, '2012-05-11 08:50:37', 'admin', 'admin', '2012-05-11 08:50:37', NULL);
INSERT INTO `NMChiControllerActionKeyChiView` (`id`, `fk_chiview_id`, `fk_chicontroller_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(493, NULL, 207, NULL, 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Generalization', NULL, NULL, '2012-05-11 08:50:37', 'admin', 'admin', '2012-05-11 08:50:37', NULL);
INSERT INTO `NMChiControllerActionKeyChiView` (`id`, `fk_chiview_id`, `fk_chicontroller_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(494, NULL, 257, NULL, 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Generalization', NULL, NULL, '2012-05-11 08:50:38', 'admin', 'admin', '2012-05-11 08:50:38', NULL);
INSERT INTO `NMChiControllerActionKeyChiView` (`id`, `fk_chiview_id`, `fk_chicontroller_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(495, NULL, 257, NULL, 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Generalization', NULL, NULL, '2012-05-11 08:50:38', 'admin', 'admin', '2012-05-11 08:50:38', NULL);
INSERT INTO `NMChiControllerActionKeyChiView` (`id`, `fk_chiview_id`, `fk_chicontroller_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(496, NULL, 257, NULL, 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Generalization', NULL, NULL, '2012-05-11 08:50:38', 'admin', 'admin', '2012-05-11 08:50:38', NULL);
INSERT INTO `NMChiControllerActionKeyChiView` (`id`, `fk_chiview_id`, `fk_chicontroller_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(497, NULL, 257, NULL, 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Generalization', NULL, NULL, '2012-05-11 08:50:39', 'admin', 'admin', '2012-05-11 08:50:39', NULL);
INSERT INTO `NMChiControllerActionKeyChiView` (`id`, `fk_chiview_id`, `fk_chicontroller_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(498, NULL, 257, NULL, 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Generalization', NULL, NULL, '2012-05-11 08:50:39', 'admin', 'admin', '2012-05-11 08:50:39', NULL);
INSERT INTO `NMChiControllerActionKeyChiView` (`id`, `fk_chiview_id`, `fk_chicontroller_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(499, NULL, 257, NULL, 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Generalization', NULL, NULL, '2012-05-11 08:50:40', 'admin', 'admin', '2012-05-11 08:50:40', NULL);
INSERT INTO `NMChiControllerActionKeyChiView` (`id`, `fk_chiview_id`, `fk_chicontroller_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(500, NULL, 257, NULL, 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Generalization', NULL, NULL, '2012-05-11 08:50:40', 'admin', 'admin', '2012-05-11 08:50:40', NULL);
INSERT INTO `NMChiControllerActionKeyChiView` (`id`, `fk_chiview_id`, `fk_chicontroller_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(501, NULL, 257, NULL, 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Generalization', NULL, NULL, '2012-05-11 08:50:40', 'admin', 'admin', '2012-05-11 08:50:41', NULL);
INSERT INTO `NMChiControllerActionKeyChiView` (`id`, `fk_chiview_id`, `fk_chicontroller_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(502, NULL, 193, NULL, 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Generalization', NULL, NULL, '2012-05-11 08:50:41', 'admin', 'admin', '2012-05-11 08:50:41', NULL);
INSERT INTO `NMChiControllerActionKeyChiView` (`id`, `fk_chiview_id`, `fk_chicontroller_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(503, NULL, 257, NULL, 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Generalization', NULL, NULL, '2012-05-11 08:50:42', 'admin', 'admin', '2012-05-11 08:50:42', NULL);
INSERT INTO `NMChiControllerActionKeyChiView` (`id`, `fk_chiview_id`, `fk_chicontroller_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(504, NULL, 257, NULL, 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Generalization', NULL, NULL, '2012-05-11 08:50:42', 'admin', 'admin', '2012-05-11 08:50:42', NULL);
INSERT INTO `NMChiControllerActionKeyChiView` (`id`, `fk_chiview_id`, `fk_chicontroller_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(505, NULL, 257, NULL, 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Generalization', NULL, NULL, '2012-05-11 08:50:42', 'admin', 'admin', '2012-05-11 08:50:42', NULL);
INSERT INTO `NMChiControllerActionKeyChiView` (`id`, `fk_chiview_id`, `fk_chicontroller_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(506, NULL, 257, NULL, 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Generalization', NULL, NULL, '2012-05-11 08:50:43', 'admin', 'admin', '2012-05-11 08:50:43', NULL);
INSERT INTO `NMChiControllerActionKeyChiView` (`id`, `fk_chiview_id`, `fk_chicontroller_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(507, NULL, 257, NULL, 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Generalization', NULL, NULL, '2012-05-11 08:50:43', 'admin', 'admin', '2012-05-11 08:50:43', NULL);
INSERT INTO `NMChiControllerActionKeyChiView` (`id`, `fk_chiview_id`, `fk_chicontroller_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(508, NULL, 226, NULL, 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Generalization', NULL, NULL, '2012-05-11 08:50:44', 'admin', 'admin', '2012-05-11 08:50:44', NULL);
INSERT INTO `NMChiControllerActionKeyChiView` (`id`, `fk_chiview_id`, `fk_chicontroller_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(509, NULL, 257, NULL, 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Generalization', NULL, NULL, '2012-05-11 08:50:44', 'admin', 'admin', '2012-05-11 08:50:44', NULL);
INSERT INTO `NMChiControllerActionKeyChiView` (`id`, `fk_chiview_id`, `fk_chicontroller_id`, `action`, `config`, `context`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(510, NULL, 257, NULL, 'config.ini', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Generalization', NULL, NULL, '2012-05-11 08:50:44', 'admin', 'admin', '2012-05-11 08:50:44', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `NMChiControllerChiController`
--

CREATE TABLE IF NOT EXISTS `NMChiControllerChiController` (
  `id` int(11) NOT NULL,
  `fk_chicontrollersource_id` int(11) DEFAULT NULL,
  `fk_chicontrollertarget_id` int(11) DEFAULT NULL,
  `sourcename` varchar(255) DEFAULT NULL,
  `sourcemultiplicity` varchar(255) DEFAULT NULL,
  `sourcenavigability` varchar(255) DEFAULT NULL,
  `targetname` varchar(255) DEFAULT NULL,
  `targetmultiplicity` varchar(255) DEFAULT NULL,
  `targetnavigability` varchar(255) DEFAULT NULL,
  `relationtype` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chicontrollersource_id` (`fk_chicontrollersource_id`),
  KEY `fk_chicontrollertarget_id` (`fk_chicontrollertarget_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `NMChiNodeChiMany2Many`
--

CREATE TABLE IF NOT EXISTS `NMChiNodeChiMany2Many` (
  `id` int(11) NOT NULL,
  `fk_chinode_id` int(11) DEFAULT NULL,
  `fk_chinodemanytomany_id` int(11) DEFAULT NULL,
  `sourcename` varchar(255) DEFAULT NULL,
  `sourcemultiplicity` varchar(255) DEFAULT NULL,
  `sourcenavigability` varchar(255) DEFAULT NULL,
  `targetname` varchar(255) DEFAULT NULL,
  `targetmultiplicity` varchar(255) DEFAULT NULL,
  `targetnavigability` varchar(255) DEFAULT NULL,
  `relationtype` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chinode_id` (`fk_chinode_id`),
  KEY `fk_chinodemanytomany_id` (`fk_chinodemanytomany_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `NMChiNodeChiMany2Many`
--

INSERT INTO `NMChiNodeChiMany2Many` (`id`, `fk_chinode_id`, `fk_chinodemanytomany_id`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(552, 292, 302, NULL, '513', 'Navigable', NULL, '522', 'Navigable', 'aggregation', NULL, NULL, '2012-05-11 08:51:05', 'admin', 'admin', '2012-05-11 08:51:05', NULL);
INSERT INTO `NMChiNodeChiMany2Many` (`id`, `fk_chinode_id`, `fk_chinodemanytomany_id`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(553, 271, 302, NULL, '513', 'Navigable', NULL, '522', 'Navigable', 'aggregation', NULL, NULL, '2012-05-11 08:51:05', 'admin', 'admin', '2012-05-11 08:51:05', NULL);
INSERT INTO `NMChiNodeChiMany2Many` (`id`, `fk_chinode_id`, `fk_chinodemanytomany_id`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(584, 323, 344, NULL, '513', 'Navigable', NULL, '522', 'Navigable', 'composition', NULL, NULL, '2012-05-11 08:51:19', 'admin', 'admin', '2012-05-11 08:51:19', NULL);
INSERT INTO `NMChiNodeChiMany2Many` (`id`, `fk_chinode_id`, `fk_chinodemanytomany_id`, `sourcename`, `sourcemultiplicity`, `sourcenavigability`, `targetname`, `targetmultiplicity`, `targetnavigability`, `relationtype`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(585, 337, 344, NULL, '513', 'Navigable', NULL, '522', 'Navigable', 'composition', NULL, NULL, '2012-05-11 08:51:19', 'admin', 'admin', '2012-05-11 08:51:19', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `NMChiUseCaseChiUseCase`
--

CREATE TABLE IF NOT EXISTS `NMChiUseCaseChiUseCase` (
  `id` int(11) NOT NULL,
  `fk_chiusecasecoresource_id` int(11) DEFAULT NULL,
  `fk_chiusecasecoretarget_id` int(11) DEFAULT NULL,
  `fk_chiusecasetarget_id` int(11) DEFAULT NULL,
  `fk_chiusecasesource_id` int(11) DEFAULT NULL,
  `sourcename` varchar(255) DEFAULT NULL,
  `sourcemultiplicity` varchar(255) DEFAULT NULL,
  `sourcenavigability` varchar(255) DEFAULT NULL,
  `targetname` varchar(255) DEFAULT NULL,
  `targetmultiplicity` varchar(255) DEFAULT NULL,
  `targetnavigability` varchar(255) DEFAULT NULL,
  `relationtype` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chiusecasecoresource_id` (`fk_chiusecasecoresource_id`),
  KEY `fk_chiusecasecoretarget_id` (`fk_chiusecasecoretarget_id`),
  KEY `fk_chiusecasetarget_id` (`fk_chiusecasetarget_id`),
  KEY `fk_chiusecasesource_id` (`fk_chiusecasesource_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `NMFeatureRequirements`
--

CREATE TABLE IF NOT EXISTS `NMFeatureRequirements` (
  `id` int(11) NOT NULL,
  `fk_chifeature_id` int(11) DEFAULT NULL,
  `fk_chirequirement_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chifeature_id` (`fk_chifeature_id`),
  KEY `fk_chirequirement_id` (`fk_chirequirement_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `NMFiguresDiagram`
--

CREATE TABLE IF NOT EXISTS `NMFiguresDiagram` (
  `id` int(11) NOT NULL,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `NMUCActor`
--

CREATE TABLE IF NOT EXISTS `NMUCActor` (
  `id` int(11) NOT NULL,
  `fk_chiworkerexternal_id` int(11) DEFAULT NULL,
  `fk_chiworkerinternal_id` int(11) DEFAULT NULL,
  `fk_chiworker_id` int(11) DEFAULT NULL,
  `fk_chibusinesspartneractive_id` int(11) DEFAULT NULL,
  `fk_chibusinesspartnerpassive_id` int(11) DEFAULT NULL,
  `fk_chibusinesspartner_id` int(11) DEFAULT NULL,
  `fk_chibusinessusecasecore_id` int(11) DEFAULT NULL,
  `fk_chibusinessusecase_id` int(11) DEFAULT NULL,
  `fk_actor_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chiworkerexternal_id` (`fk_chiworkerexternal_id`),
  KEY `fk_chiworkerinternal_id` (`fk_chiworkerinternal_id`),
  KEY `fk_chiworker_id` (`fk_chiworker_id`),
  KEY `fk_chibusinesspartneractive_id` (`fk_chibusinesspartneractive_id`),
  KEY `fk_chibusinesspartnerpassive_id` (`fk_chibusinesspartnerpassive_id`),
  KEY `fk_chibusinesspartner_id` (`fk_chibusinesspartner_id`),
  KEY `fk_chibusinessusecasecore_id` (`fk_chibusinessusecasecore_id`),
  KEY `fk_chibusinessusecase_id` (`fk_chibusinessusecase_id`),
  KEY `fk_actor_id` (`fk_actor_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `nm_user_role`
--

CREATE TABLE IF NOT EXISTS `nm_user_role` (
  `fk_user_id` int(11) NOT NULL DEFAULT '0',
  `fk_role_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`fk_user_id`,`fk_role_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `nm_user_role`
--

INSERT INTO `nm_user_role` (`fk_user_id`, `fk_role_id`) VALUES(2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `ObjectFlow`
--

CREATE TABLE IF NOT EXISTS `ObjectFlow` (
  `id` int(11) NOT NULL,
  `fk_aobjectflowtarget_id` int(11) DEFAULT NULL,
  `fk_aobjectflowsource_id` int(11) DEFAULT NULL,
  `fk_chiobjectobjectflowsource_id` int(11) DEFAULT NULL,
  `fk_chiobjectobjectflowtarget_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_aobjectflowtarget_id` (`fk_aobjectflowtarget_id`),
  KEY `fk_aobjectflowsource_id` (`fk_aobjectflowsource_id`),
  KEY `fk_chiobjectobjectflowsource_id` (`fk_chiobjectobjectflowsource_id`),
  KEY `fk_chiobjectobjectflowtarget_id` (`fk_chiobjectobjectflowtarget_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Operation`
--

CREATE TABLE IF NOT EXISTS `Operation` (
  `id` int(11) NOT NULL,
  `fk_chinodemanytomany_id` int(11) DEFAULT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_chicontroller_id` int(11) DEFAULT NULL,
  `fk_chinode_id` int(11) DEFAULT NULL,
  `parameters` varchar(255) DEFAULT NULL,
  `returntype` varchar(255) DEFAULT NULL,
  `visibility` varchar(255) DEFAULT NULL,
  `isabstract` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chinodemanytomany_id` (`fk_chinodemanytomany_id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_chicontroller_id` (`fk_chicontroller_id`),
  KEY `fk_chinode_id` (`fk_chinode_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Package`
--

CREATE TABLE IF NOT EXISTS `Package` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_model_id` int(11) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_model_id` (`fk_model_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Package`
--

INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(4, NULL, 3, NULL, 'PrimitiveTypes', NULL, '2012-05-11 08:48:45', 'admin', 'admin', '2012-05-11 08:49:35', 4);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(5, NULL, 3, NULL, 'newroles', NULL, '2012-05-11 08:48:45', 'admin', 'admin', '2012-05-11 08:49:36', 5);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(6, 5, NULL, NULL, 'configuration', NULL, '2012-05-11 08:48:45', 'admin', 'admin', '2012-05-11 08:49:36', 6);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(7, 6, NULL, NULL, 'default', NULL, '2012-05-11 08:48:46', 'admin', 'admin', '2012-05-11 08:49:36', 7);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(8, 7, NULL, NULL, 'config.ini', NULL, '2012-05-11 08:48:46', 'admin', 'admin', '2012-05-11 08:49:36', 8);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(39, 7, NULL, NULL, 'admin.ini', NULL, '2012-05-11 08:48:50', 'admin', 'admin', '2012-05-11 08:49:45', 39);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(42, 7, NULL, NULL, 'server.ini', NULL, '2012-05-11 08:48:50', 'admin', 'admin', '2012-05-11 08:49:46', 42);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(59, 7, NULL, NULL, 'persistence.ini', NULL, '2012-05-11 08:48:53', 'admin', 'admin', '2012-05-11 08:49:51', 59);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(74, 7, NULL, NULL, 'presentation.ini', NULL, '2012-05-11 08:48:55', 'admin', 'admin', '2012-05-11 08:49:55', 74);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(188, 5, NULL, NULL, 'wcmf', NULL, '2012-05-11 08:49:13', 'admin', 'admin', '2012-05-11 08:50:27', 188);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(189, 188, NULL, NULL, 'application', NULL, '2012-05-11 08:49:13', 'admin', 'admin', '2012-05-11 08:50:28', 189);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(190, 189, NULL, NULL, 'controller', NULL, '2012-05-11 08:49:14', 'admin', 'admin', '2012-05-11 08:50:28', 190);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(224, 190, NULL, NULL, 'admintool', NULL, '2012-05-11 08:49:18', 'admin', 'admin', '2012-05-11 08:50:41', 224);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(233, 189, NULL, NULL, 'views', NULL, '2012-05-11 08:49:19', 'admin', 'admin', '2012-05-11 08:50:45', 233);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(245, 233, NULL, NULL, 'admintool', NULL, '2012-05-11 08:49:21', 'admin', 'admin', '2012-05-11 08:50:47', 245);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(251, 233, NULL, NULL, 'forms', NULL, '2012-05-11 08:49:22', 'admin', 'admin', '2012-05-11 08:50:48', 251);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(253, 188, NULL, NULL, 'lib', NULL, '2012-05-11 08:49:22', 'admin', 'admin', '2012-05-11 08:50:49', 253);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(254, 253, NULL, NULL, 'model', NULL, '2012-05-11 08:49:22', 'admin', 'admin', '2012-05-11 08:50:49', 254);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(256, 253, NULL, NULL, 'presentation', NULL, '2012-05-11 08:49:22', 'admin', 'admin', '2012-05-11 08:50:50', 256);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(258, 253, NULL, NULL, 'security', NULL, '2012-05-11 08:49:22', 'admin', 'admin', '2012-05-11 08:50:50', 258);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(259, 5, NULL, NULL, 'new_roles', NULL, '2012-05-11 08:49:22', 'admin', 'admin', '2012-05-11 08:50:51', 259);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(260, 259, NULL, NULL, 'application', NULL, '2012-05-11 08:49:22', 'admin', 'admin', '2012-05-11 08:50:51', 260);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(261, 260, NULL, NULL, 'controller', NULL, '2012-05-11 08:49:23', 'admin', 'admin', '2012-05-11 08:50:51', 261);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(262, 260, NULL, NULL, 'views', NULL, '2012-05-11 08:49:23', 'admin', 'admin', '2012-05-11 08:50:51', 262);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(263, 260, NULL, NULL, 'model', NULL, '2012-05-11 08:49:23', 'admin', 'admin', '2012-05-11 08:50:52', 263);
INSERT INTO `Package` (`id`, `fk_package_id`, `fk_model_id`, `umi`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `sortkey`) VALUES(310, 263, NULL, NULL, 'wcmf', NULL, '2012-05-11 08:49:30', 'admin', 'admin', '2012-05-11 08:51:08', 310);

-- --------------------------------------------------------

--
-- Table structure for table `ProductionRule`
--

CREATE TABLE IF NOT EXISTS `ProductionRule` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_productionruleset_id` int(11) DEFAULT NULL,
  `priority` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_productionruleset_id` (`fk_productionruleset_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ProductionRuleSet`
--

CREATE TABLE IF NOT EXISTS `ProductionRuleSet` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_activityset_id` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_activityset_id` (`fk_activityset_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Property`
--

CREATE TABLE IF NOT EXISTS `Property` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_chicontroller_id` int(11) DEFAULT NULL,
  `fk_chisystem_id` int(11) DEFAULT NULL,
  `default` varchar(255) DEFAULT NULL,
  `propertytype` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_chicontroller_id` (`fk_chicontroller_id`),
  KEY `fk_chisystem_id` (`fk_chisystem_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Relation`
--

CREATE TABLE IF NOT EXISTS `Relation` (
  `id` int(11) NOT NULL,
  `sourcename` varchar(255) DEFAULT NULL,
  `sourcemultiplicity` varchar(255) DEFAULT NULL,
  `sourcenavigability` varchar(255) DEFAULT NULL,
  `targetname` varchar(255) DEFAULT NULL,
  `targetmultiplicity` varchar(255) DEFAULT NULL,
  `targetnavigability` varchar(255) DEFAULT NULL,
  `relationtype` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `RelationMultiplicity`
--

CREATE TABLE IF NOT EXISTS `RelationMultiplicity` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `RelationMultiplicity`
--

INSERT INTO `RelationMultiplicity` (`id`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(513, '1', NULL, '2012-05-11 08:50:52', 'admin', 'admin', '2012-05-11 08:50:52', NULL);
INSERT INTO `RelationMultiplicity` (`id`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(514, '1..*', NULL, '2012-05-11 08:50:52', 'admin', 'admin', '2012-05-11 08:50:52', NULL);
INSERT INTO `RelationMultiplicity` (`id`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(522, '*', NULL, '2012-05-11 08:50:55', 'admin', 'admin', '2012-05-11 08:50:55', NULL);
INSERT INTO `RelationMultiplicity` (`id`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(542, '0..1', NULL, '2012-05-11 08:51:02', 'admin', 'admin', '2012-05-11 08:51:02', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `RelationType`
--

CREATE TABLE IF NOT EXISTS `RelationType` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE IF NOT EXISTS `role` (
  `id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`id`, `name`) VALUES(1, 'administrators');

-- --------------------------------------------------------

--
-- Table structure for table `RuleAction`
--

CREATE TABLE IF NOT EXISTS `RuleAction` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_productionrule_id` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_productionrule_id` (`fk_productionrule_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `RuleCondition`
--

CREATE TABLE IF NOT EXISTS `RuleCondition` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_productionrule_id` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_productionrule_id` (`fk_productionrule_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `RuleSetVariable`
--

CREATE TABLE IF NOT EXISTS `RuleSetVariable` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_productionruleset_id` int(11) DEFAULT NULL,
  `context` varchar(255) DEFAULT NULL,
  `rulevalue` varchar(255) DEFAULT NULL,
  `variabletype` varchar(255) DEFAULT NULL,
  `iseditable` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_productionruleset_id` (`fk_productionruleset_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `RuleVariable`
--

CREATE TABLE IF NOT EXISTS `RuleVariable` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `fk_productionrule_id` int(11) DEFAULT NULL,
  `context` varchar(255) DEFAULT NULL,
  `rulevalue` varchar(255) DEFAULT NULL,
  `variabletype` varchar(255) DEFAULT NULL,
  `iseditable` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_productionrule_id` (`fk_productionrule_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Translation`
--

CREATE TABLE IF NOT EXISTS `Translation` (
  `id` int(11) NOT NULL,
  `objectid` varchar(255) DEFAULT NULL,
  `attribute` varchar(255) DEFAULT NULL,
  `translation` text,
  `language` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL,
  `login` varchar(50) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `firstname` varchar(50) DEFAULT NULL,
  `config` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `login`, `password`, `name`, `firstname`, `config`) VALUES(2, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'Administrator', NULL, 'admin.ini');

-- --------------------------------------------------------

--
-- Table structure for table `user_config`
--

CREATE TABLE IF NOT EXISTS `user_config` (
  `id` int(11) NOT NULL,
  `fk_user_id` int(11) DEFAULT NULL,
  `key` varchar(255) DEFAULT NULL,
  `val` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_user_id` (`fk_user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Visibility`
--

CREATE TABLE IF NOT EXISTS `Visibility` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Visibility`
--

INSERT INTO `Visibility` (`id`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `umi`) VALUES(511, 'public', NULL, '2012-05-11 08:50:49', 'admin', 'admin', '2012-05-11 08:50:49', NULL);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
